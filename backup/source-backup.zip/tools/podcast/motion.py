#!/usr/bin/env python3
"""
محرّك «الحركة المرسومة بالكود» لفيديوهات المسلسلات (الخيار ٢).

فوق خلفية كل مشهد (الصورة المائية) يرسم بالكود رسمًا شارحًا يختاره «مخطِّط» نصّي رخيص لكل مشهد من قائمة قوالب:
  points   نقاط تظهر واحدة بعد واحدة            compare  مقارنة بين عمودين
  sort     بطاقات تطير إلى سلال                  jars     دنانير تطير إلى جرار بعدّاد
  price    سلعة بسعر وشريط ادّخار حتى ✓          scale    ميزان يميل ثم يعتدل
  pyramid  هرم أولويات من القاعدة                story    بطاقات قصة متتابعة
  question سؤال كبير للتفكير                     big      أيقونة وعنوان
كل عنصر يظهر لحظة نطق كلمته (cue) في الحوار. والشخصيتان تدخلان وتتمايلان وتميلان أثناء الكلام وتقفز مريم فرحًا،
مع ذرّات ضوء وتحريك كاميرا، وترجمة على دفعات قصيرة. يُرسم كل مشهد في عملية مستقلة (٤ أنوية).

يُستدعى من make_series_video.py:  motion.render(ep, script, d, plan)
"""
import json, math, os, random, re, subprocess
from functools import lru_cache
from multiprocessing import Pool
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
import make_episode as m

W, H, FPS = 1920, 1080, 25
INTRO, GAP, OUTRO = 5.0, 0.35, 6.0
AR = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")
KW = dict(direction="rtl", language="ar")
CH = 470
GREEN, GOLD, INK = (31, 110, 82), (201, 146, 34), (40, 50, 70)
TEMPLATES = ["points", "compare", "sort", "jars", "price", "scale", "pyramid", "story", "question", "big"]

# ───────────────────────── المخطِّط ─────────────────────────
PLAN_RULES = """أنت مصمّم رسوم شارحة متحرّكة لفيديو تعليمي إسلامي للأطفال (٨–١٣ سنة) بالعربية.
لكل مشهد أدناه اختر قالبًا واحدًا يشرح فكرته بصريًا، وأعد JSON فقط: {"scenes": {"<رقم المشهد>": {...}}}.
القوالب وحقولها:
- points: {"template":"points","title":"…","items":[{"icon":"🍞","text":"…","cue":"…"}]}  (٢–٥ عناصر)
- compare: {"template":"compare","title":"…","left":{"icon":"…","title":"…","points":["…"]},"right":{…}}  (اليمين يُقرأ أولًا، ١–٣ نقاط لكل عمود؛ يمكن cue في كل عمود)
- sort: {"template":"sort","title":"…","bins":[{"icon":"…","label":"…"}],"items":[{"icon":"…","text":"…","bin":0,"cue":"…"}]}  (٢–٣ سلال، ٣–٦ عناصر)
- jars: {"template":"jars","title":"…","total":10,"jars":[{"label":"…","amount":4,"cue":"…"}]}  (٢–٤ جرار، مجموعها = total)
- price: {"template":"price","title":"…","item":{"icon":"🎮","label":"…"},"price":6,"have":2,"steps":[{"label":"…","add":2,"cue":"…"}]}
- scale: {"template":"scale","title":"…","right":{"icon":"…","label":"…"},"left":{"icon":"…","label":"…"},"middle":"…","cues":{"right":"…","left":"…","middle":"…"}}
- pyramid: {"template":"pyramid","title":"…","levels":[{"text":"…","cue":"…"}]}  (٣ مستويات من القاعدة إلى القمّة)
- story: {"template":"story","title":"…","cards":[{"icon":"…","title":"…","text":"…","cue":"…"}],"best":2}  (٢–٣ بطاقات)
- question: {"template":"question","title":"…","question":"…"}
- big: {"template":"big","icon":"…","title":"…","sub":"…"}  (للافتتاح والختام)
قواعد مهمّة:
- النصوص قصيرة جدًّا: العنوان ≤ ٦ كلمات، والعنصر ≤ ٤ كلمات، بلا تشكيل لكن بإملاء صحيح كامل (الهمزات أ إ ء آ، والتاء المربوطة)، والأرقام بالهندية (٠–٩).
- icon رمز تعبيري (emoji) واحد لأشياء أو حيوانات أو طبيعة أو رموز فقط؛ لا وجوه ولا أشخاص ولا أيدٍ.
- cue كلمة أو كلمتان منقولتان حرفيًا من كلام المشهد، تُنطق لحظة ظهور العنصر (وبترتيب ورودها).
- استعمل الأرقام الحقيقية من الحوار فقط، ولا تخترع معلومات. نوّع القوالب بين المشاهد.
- المشهد الذي فيه آية: big بأيقونة 📖 وعنوان قصير للمعنى.
- إذا انتقل الحوار داخل المشهد إلى فكرة جديدة، فأعد للمشهد قائمة من رسمين: {"parts":[{...},{..., "start":"كلمة يبدأ عندها الرسم الثاني"}]}.
"""


def plan(L, scenes, d):
    f = d / "motion-plan.json"
    if f.exists():
        return json.loads(f.read_text())
    need = [k for k, sc in enumerate(scenes) if "activity" not in sc]
    txt = "\n\n".join(f"مشهد {k}:\n" + "\n".join(f"- {l.get('t', '')}" for l in scenes[k]["lines"]
                                                   if l["s"] not in ("pause",)) for k in need)
    r = m.gemini_text(m.TEXT_MODEL, [{"role": "user", "parts": [{"text": PLAN_RULES + f"\nعنوان الحلقة: {L['title']}\n\n" + txt}]}],
                      {"responseMimeType": "application/json", "temperature": 0.4})
    p = json.loads(r).get("scenes", {})
    out = {}
    for k in need:
        s = p.get(str(k)) or {}
        parts = [x for x in (s.get("parts") or [s]) if isinstance(x, dict) and x.get("template") in TEMPLATES][:2]
        if not parts:
            parts = [{"template": "big", "icon": "⛵", "title": L["title"].split(":")[0]}]
        out[str(k)] = {"parts": parts}
    f.write_text(json.dumps(out, ensure_ascii=False, indent=1))
    return out

# ───────────────────────── أدوات الرسم ─────────────────────────
def F(size, wt="Bold"):
    f = ImageFont.truetype(str(HERE / "fonts" / "Cairo.ttf"), size); f.set_variation_by_name(wt); return f


def ease(x):
    x = max(0.0, min(1.0, x)); c = 1.4
    return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2


def smooth(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)


def ar(s):
    return str(s).translate(AR)


@lru_cache(maxsize=256)
def emoji(ch, size=96):
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf", 109)
        im = Image.new("RGBA", (160, 160), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((10, 10), ch, font=f, embedded_color=True)
        bb = im.getbbox()
        if bb:
            im = im.crop(bb); sc = size / max(im.size)
            return im.resize((max(1, int(im.width * sc)), max(1, int(im.height * sc))), Image.LANCZOS)
    except Exception:
        pass
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse((0, 0, size - 1, size - 1), fill=GOLD)
    return im


@lru_cache(maxsize=512)
def chip(text, size=36, fg=INK, bg=(255, 250, 238, 238), maxw=1100):
    f = F(size); dr = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    kw = dict(direction="ltr") if text[:1] in "+-" else KW
    while dr.textlength(text, font=f, **kw) > maxw and size > 20:
        size -= 2; f = F(size)
    tw = dr.textlength(text, font=f, **kw); th = int(size * 1.55)
    im = Image.new("RGBA", (int(tw + 48), th + 14), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, im.width - 1, im.height - 1), im.height // 2, fill=bg)
    d.text((im.width / 2, im.height / 2), text, font=f, fill=fg, anchor="mm", **kw)
    return im


def title_chip(text):
    return chip(text, 40, (255, 255, 255), GREEN + (238,))


def wrap_lines(text, f, width):
    dr = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    return m._wrap(dr, text, f, width, KW)


@lru_cache(maxsize=256)
def card(icon, title, text="", w=330, h=None, bg=(255, 252, 242, 242), accent=GOLD):
    ft, fb = F(40 if w >= 400 else 34), F(32 if w >= 400 else 28, "SemiBold")
    tl = wrap_lines(title, ft, w - 40)[:2] if title else []
    bl = wrap_lines(text, fb, w - 40)[:3] if text else []
    hh = h or (130 + 50 * len(tl) + 42 * len(bl))
    im = Image.new("RGBA", (w, hh), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, hh - 1), 28, fill=bg, outline=accent, width=5)
    if icon:
        e = emoji(icon, 86); im.alpha_composite(e, ((w - e.width) // 2, 18))
    y = 118
    for ln in tl:
        d.text((w / 2, y), ln, font=ft, fill=INK, anchor="mt", **KW); y += 50
    for ln in bl:
        d.text((w / 2, y), ln, font=fb, fill=(90, 90, 100), anchor="mt", **KW); y += 42
    return im


@lru_cache(maxsize=256)
def row(icon, text, w=760):
    f = F(38); im = Image.new("RGBA", (w, 96), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, 95), 30, fill=(255, 252, 242, 242), outline=(220, 190, 130), width=3)
    e = emoji(icon or "⭐", 64); im.alpha_composite(e, (w - e.width - 22, (96 - e.height) // 2))
    d.text((w - 110, 48), text, font=f, fill=INK, anchor="rm", **KW)
    return im


@lru_cache(maxsize=1)
def coin():
    r, s = 34, 4; im = Image.new("RGBA", (r * 2 * s, r * 2 * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse((0, 0, r * 2 * s - 1, r * 2 * s - 1), fill=(201, 146, 34))
    d.ellipse((5 * s, 5 * s, (r * 2 - 5) * s, (r * 2 - 5) * s), fill=(244, 196, 64))
    d.ellipse((11 * s, 11 * s, (r * 2 - 11) * s, (r * 2 - 11) * s), outline=(214, 158, 40), width=3 * s)
    d.ellipse((14 * s, 9 * s, 28 * s, 19 * s), fill=(255, 236, 160))
    return im.resize((r * 2, r * 2), Image.LANCZOS)


@lru_cache(maxsize=1)
def jar():
    w, h, s = 190, 230, 3; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((8 * s, 34 * s, (w - 8) * s, (h - 4) * s), 34 * s, fill=(225, 240, 250, 140), outline=(120, 160, 190), width=4 * s)
    d.rounded_rectangle((30 * s, 6 * s, (w - 30) * s, 38 * s), 10 * s, fill=(170, 120, 70), outline=(120, 80, 40), width=3 * s)
    d.rounded_rectangle((26 * s, 60 * s, 40 * s, (h - 40) * s), 7 * s, fill=(255, 255, 255, 130))
    return im.resize((w, h), Image.LANCZOS)


@lru_cache(maxsize=1)
def basket():
    w, h, s = 300, 170, 3; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.polygon([(10 * s, 30 * s), (290 * s, 30 * s), (255 * s, 165 * s), (45 * s, 165 * s)], fill=(196, 140, 80), outline=(130, 85, 40))
    for k in range(1, 6):
        d.line(((10 + k * 47) * s, 30 * s, (45 + k * 35) * s, 165 * s), fill=(150, 100, 50), width=3 * s)
    d.rounded_rectangle((0, 18 * s, w * s - 1, 42 * s), 12 * s, fill=(170, 115, 60))
    return im.resize((w, h), Image.LANCZOS)


@lru_cache(maxsize=1)
def check():
    r, s = 60, 4; im = Image.new("RGBA", (r * 2 * s, r * 2 * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse((0, 0, r * 2 * s - 1, r * 2 * s - 1), fill=(46, 170, 90))
    d.line([(r * .55 * s, r * 1.05 * s), (r * .9 * s, r * 1.4 * s), (r * 1.5 * s, r * .65 * s)], fill="white", width=int(r * .25 * s), joint="curve")
    return im.resize((r * 2, r * 2), Image.LANCZOS)


def paste(base, sp, cx, cy, scale=1.0, alpha=1.0, rot=0.0):
    if scale <= 0.02 or alpha <= 0.02:
        return
    im = sp
    if abs(scale - 1) > 0.01:
        im = im.resize((max(1, int(sp.width * scale)), max(1, int(sp.height * scale))), Image.BILINEAR)
    if abs(rot) > 0.2:
        im = im.rotate(rot, resample=Image.BICUBIC, expand=True)
    if alpha < 0.99:
        a = im.getchannel("A").point(lambda v: int(v * alpha)); im = im.copy(); im.putalpha(a)
    base.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2)))


def confetti(fr, x0, y0, g, seed=11):
    if g < 0 or g > 2.4:
        return
    random.seed(seed); d = ImageDraw.Draw(fr)
    for q in range(28):
        ang = random.uniform(0, 6.28); sp = random.uniform(160, 420)
        x = x0 + math.cos(ang) * sp * min(g, 1.6); y = y0 + math.sin(ang) * sp * min(g, 1.6) + 120 * g * g
        col = random.choice([(250, 90, 90), (90, 200, 120), (250, 210, 70), (110, 170, 250)])
        a = int(255 * max(0, 1 - g / 2.3))
        d.ellipse((x - 9, y - 9, x + 9, y + 9), fill=col + (a,))

# ───────────────────────── القوالب ─────────────────────────
# كل قالب: draw(fr, t, P, T) — t الزمن داخل المشهد، T أزمنة العناصر (cues) داخل المشهد، و T["end"] طول المشهد.
CX, TOP = 960, 112


def t_points(fr, t, P, T):
    items = P.get("items", [])[:5]; n = len(items)
    y0 = 230 if n <= 3 else 200; gap = 108 if n <= 4 else 96
    for k, it in enumerate(items):
        u = ease((t - T["i"][k]) / 0.55)
        paste(fr, row(it.get("icon", "⭐"), it.get("text", "")), CX + (1 - u) * 400, y0 + k * gap, 1.0, min(1, u * 1.4))


def t_compare(fr, t, P, T):
    for k, side in enumerate(("right", "left")):
        c = P.get(side) or {}; u = ease((t - T["i"][k]) / 0.6)
        im = card(c.get("icon", ""), c.get("title", ""), " · ".join(c.get("points", [])[:3]), 540,
                  accent=(46, 140, 200) if k else GOLD)
        paste(fr, im, CX + (300 if side == "right" else -300), 410, u, min(1, u * 1.3))
    u = ease((t - T["i"][1]) / 0.4)
    paste(fr, chip("أم", 40, (255, 255, 255), (200, 90, 60, 240)), CX, 400, u)


def t_sort(fr, t, P, T):
    bins = P.get("bins", [])[:3]; items = P.get("items", [])[:6]; nb = max(1, len(bins))
    bx = [CX + (nb - 1) * 230 - j * 460 for j in range(nb)]; by = 560
    for j, b in enumerate(bins):
        u = ease((t - 0.2 - j * 0.2) / 0.6)
        paste(fr, basket(), bx[j], by, 0.9 * u)
        paste(fr, chip(f"{b.get('label', '')}", 32), bx[j], by + 92, u)
        e = emoji(b.get("icon", "🧺"), 56); paste(fr, e, bx[j], by - 90, u)
    ni = len(items); ix = [CX + (ni - 1) * 135 - k * 270 for k in range(ni)]
    count = [0] * nb
    for k, it in enumerate(items):
        appear = 0.4 + k * 0.25; fly = T["i"][k]
        b = min(max(int(it.get("bin", 0)), 0), nb - 1)
        u = smooth((t - fly) / 0.8)
        sx, sy = ix[k], 250; ex, ey = bx[b] + (count[b] - 1) * 40, by - 30 - count[b] * 12; count[b] += 1
        x = sx + (ex - sx) * u; y = sy + (ey - sy) * u - 200 * math.sin(math.pi * u)
        im = card(it.get("icon", "⭐"), it.get("text", ""), "", 230, 200)
        paste(fr, im, x, y, (1 - 0.45 * u) * ease((t - appear) / 0.5))


def t_jars(fr, t, P, T):
    jars_ = P.get("jars", [])[:4]; nj = max(1, len(jars_))
    amounts = [max(0, int(j.get("amount", 1))) for j in jars_]; tot = max(1, sum(amounts))
    ncoin = min(12, tot); per = [round(a * ncoin / tot) for a in amounts]
    jx = [CX + (nj - 1) * 165 - k * 330 for k in range(nj)]; jy = 430
    pile = [(CX + (k % 6 - 2.5) * 62, 640 - (k // 6) * 34) for k in range(sum(per))]
    dest = [j for j, c in enumerate(per) for _ in range(c)]
    slot = [sum(1 for q in range(k) if dest[q] == dest[k]) for k in range(len(dest))]
    for j, jj in enumerate(jars_):
        u = ease((t - 0.3 - j * 0.2) / 0.6)
        paste(fr, jar(), jx[j], jy, u)
        paste(fr, chip(jj.get("label", ""), 28, maxw=300), jx[j], jy + 150, u)
        if t >= T["i"][j] + 0.9:
            pop = 1 + 0.35 * math.exp(-(t - T["i"][j] - 0.9) * 6)
            paste(fr, chip(ar(jj.get("amount", "")), 52, (255, 255, 255), GOLD + (245,)), jx[j], jy - 150, pop)
    for k in range(len(dest)):
        ta = 0.6 + k * 0.18
        if t < ta:
            continue
        j = dest[k]; tf = T["i"][j] + slot[k] * 0.15; u = smooth((t - tf) / 0.7)
        sx, sy = pile[k]
        if u <= 0:
            v = (t - ta) / 0.45
            y = sy - 380 * (1 - v) ** 2 if v < 1 else sy - abs(math.sin((t - ta - .45) * 9)) * 22 * math.exp(-(t - ta - .45) * 5)
            paste(fr, coin(), sx, y)
        else:
            ex, ey = jx[j], jy + 60 - slot[k] * 20
            paste(fr, coin(), sx + (ex - sx) * u, sy + (ey - sy) * u - 240 * math.sin(math.pi * u), 1 - .25 * u, rot=360 * u)
    if P.get("total"):
        paste(fr, chip(f"المجموع: {ar(P['total'])}", 34), CX, 210, ease((t - 0.2) / 0.5))


def t_price(fr, t, P, T):
    it = P.get("item", {}); price = max(1, int(P.get("price", 1) or 1)); steps = P.get("steps", [])[:4]
    u = ease(t / 0.7); b = abs(math.sin(t * 6)) * 28 * math.exp(-t * 2.5)
    have = int(P.get("have", 0) or 0)
    done_t = (T["i"][len(steps) - 1] + 0.8) if steps else None
    big = 1.12 if (done_t and t >= done_t) else 1.0
    paste(fr, emoji(it.get("icon", "🎁"), 170), CX + 330, 330 - b, u * big)
    paste(fr, chip(it.get("label", ""), 34), CX + 330, 460, u)
    paste(fr, chip(f"السعر: {ar(price)}", 40, (90, 50, 0), (255, 214, 90, 245)), CX + 330, 210 - b, u, rot=6 * math.sin(t * 3))
    bx0, bx1, by = CX - 560, CX + 120, 520
    got = have + sum(int(s.get("add", 0) or 0) * smooth((t - T["i"][k]) / 0.8) for k, s in enumerate(steps))
    fill = min(1.0, got / price)
    bar = Image.new("RGBA", (bx1 - bx0, 70), (0, 0, 0, 0)); d = ImageDraw.Draw(bar)
    d.rounded_rectangle((0, 0, bar.width - 1, 69), 35, fill=(255, 255, 255, 225), outline=(150, 170, 190), width=4)
    if fill > 0:
        wf = int((bar.width - 12) * fill); d.rounded_rectangle((bar.width - 6 - wf, 6, bar.width - 7, 63), 29, fill=(244, 196, 64))
    ub = ease((t - 0.6) / 0.6)
    paste(fr, bar, (bx0 + bx1) / 2, by, ub)
    paste(fr, chip(f"معي: {ar(int(round(got)))} من {ar(price)}", 34), (bx0 + bx1) / 2, by - 80, ub)
    for k, s in enumerate(steps):
        x = bx1 - 90 - k * ((bx1 - bx0 - 120) / max(1, len(steps) - 1 if len(steps) > 1 else 1))
        paste(fr, chip(s.get("label", ""), 26, maxw=200), x, by + 70, ease((t - T["i"][k] + 0.4) / 0.5))
        if t >= T["i"][k]:
            paste(fr, chip("+" + ar(s.get("add", "")), 32, (255, 255, 255), GOLD + (245,)), x, by - 150,
                  1 + 0.4 * math.exp(-(t - T["i"][k]) * 6))
    if done_t and t >= done_t:
        g = t - done_t; paste(fr, check(), CX + 470, 250, ease(g / 0.5)); confetti(fr, CX + 330, 330, g)


def t_scale(fr, t, P, T):
    tr, tl, tm = T["i"][0], T["i"][1], T["i"][2]
    ang = 0.0
    if t >= tr: ang = 9 * smooth((t - tr) / 0.8)
    if t >= tl: ang = 9 - 18 * smooth((t - tl) / 0.8)
    if t >= tm: ang = -9 + 9 * smooth((t - tm) / 0.8)
    a = math.radians(ang); cx, cy, L = CX, 300, 380
    d = ImageDraw.Draw(fr); u = ease(t / 0.6)
    if u > 0.05:
        d.polygon([(cx - 70, 620), (cx + 70, 620), (cx + 14, cy), (cx - 14, cy)], fill=(176, 130, 60, 255))
        x1, y1 = cx + L * math.cos(a), cy + L * math.sin(a); x2, y2 = cx - L * math.cos(a), cy - L * math.sin(a)
        d.line((x2, y2, x1, y1), fill=(150, 105, 40, 255), width=14); d.ellipse((cx - 22, cy - 22, cx + 22, cy + 22), fill=(220, 170, 70, 255))
        for (px, py), side in (((x1, y1), "right"), ((x2, y2), "left")):
            d.line((px, py, px - 70, py + 120), fill=(150, 105, 40, 255), width=4); d.line((px, py, px + 70, py + 120), fill=(150, 105, 40, 255), width=4)
            d.chord((px - 110, py + 70, px + 110, py + 170), 0, 180, fill=(220, 170, 70, 255))
            c = P.get(side) or {}
            paste(fr, emoji(c.get("icon", "⚖️"), 80), px, py + 70, u)
            paste(fr, chip(c.get("label", ""), 30, maxw=300), px, py + 210, u)
    if t >= tm and P.get("middle"):
        paste(fr, chip(P["middle"], 40, (255, 255, 255), GREEN + (240,)), cx, 200 + 0, ease((t - tm) / 0.5))


def t_pyramid(fr, t, P, T):
    levels = P.get("levels", [])[:3]; d = ImageDraw.Draw(fr)
    cols = [(46, 140, 90), (230, 170, 60), (220, 110, 90)]
    for k, lv in enumerate(levels):
        u = ease((t - T["i"][k]) / 0.6)
        if u <= 0.02: continue
        y1 = 640 - k * 140; y0 = y1 - 125; half1 = 420 - k * 130; half0 = half1 - 130
        dy = (1 - u) * -300
        d.polygon([(CX - half1, y1 + dy), (CX + half1, y1 + dy), (CX + half0, y0 + dy), (CX - half0, y0 + dy)], fill=cols[k] + (int(240 * min(1, u)),))
        paste(fr, chip(lv.get("text", ""), 32, (255, 255, 255), (0, 0, 0, 0), maxw=2 * half0 + 60), CX, (y0 + y1) / 2 + dy, 1.0, min(1, u))


def t_story(fr, t, P, T):
    cards = P.get("cards", [])[:3]; n = len(cards); best = P.get("best")
    xs = [CX + (n - 1) * 200 - k * 400 for k in range(n)]
    for k, c in enumerate(cards):
        u = ease((t - T["i"][k]) / 0.6)
        hi = best is not None and int(best) == k and t >= T["end"] - 3
        im = card(c.get("icon", "⭐"), c.get("title", ""), c.get("text", ""), 360, accent=(46, 170, 90) if hi else GOLD)
        paste(fr, im, xs[k], 380, u * (1.08 if hi else 1.0))
        if hi:
            paste(fr, check(), xs[k] + 150, 200, ease((t - (T["end"] - 3)) / 0.5))


def t_question(fr, t, P, T):
    u = ease(t / 0.6); pulse = 1 + 0.06 * math.sin(t * 4)
    paste(fr, emoji("❓", 170), CX, 280, u * pulse)
    f = F(46); lines = wrap_lines(P.get("question", ""), f, 1000)[:3]
    for k, ln in enumerate(lines):
        paste(fr, chip(ln, 42), CX, 450 + k * 80, ease((t - 0.4 - k * 0.2) / 0.5))


def t_big(fr, t, P, T):
    u = ease(t / 0.7); fl = math.sin(t * 1.5) * 10
    paste(fr, emoji(P.get("icon", "⭐"), 200), CX, 320 + fl, u)
    if P.get("sub"):
        paste(fr, chip(P["sub"], 36), CX, 500, ease((t - 0.5) / 0.6))


DRAW = {"points": t_points, "compare": t_compare, "sort": t_sort, "jars": t_jars, "price": t_price, "scale": t_scale,
        "pyramid": t_pyramid, "story": t_story, "question": t_question, "big": t_big}


def cue_list(P):
    tp = P.get("template")
    if tp == "points": return [i.get("cue") for i in P.get("items", [])[:5]]
    if tp == "compare": return [(P.get("right") or {}).get("cue"), (P.get("left") or {}).get("cue")]
    if tp == "sort": return [i.get("cue") for i in P.get("items", [])[:6]]
    if tp == "jars": return [j.get("cue") for j in P.get("jars", [])[:4]]
    if tp == "price": return [s.get("cue") for s in P.get("steps", [])[:4]]
    if tp == "scale": c = P.get("cues") or {}; return [c.get("right"), c.get("left"), c.get("middle")]
    if tp == "pyramid": return [l.get("cue") for l in P.get("levels", [])[:3]]
    if tp == "story": return [c.get("cue") for c in P.get("cards", [])[:3]]
    return []

# ───────────────────────── رسم مشهد ─────────────────────────
def _norm_map(text):
    """نصّ بلا تشكيل + خريطة من موضع كل حرف فيه إلى موضعه في النص الأصلي."""
    out, idx = [], []
    for i, ch in enumerate(text):
        c = m._norm(ch)
        for x in c:
            out.append(x); idx.append(i)
    return "".join(out), idx


def cue_times(P, lines, dur):
    """زمن كل عنصر داخل المشهد: لحظة نطق كلمته، وإلا توزيع منتظم."""
    cues = cue_list(P); n = len(cues); res, last = [], 0.4
    for k, c in enumerate(cues):
        tt = None
        if c:
            q = m._norm(c)
            for l in lines:
                if l["s"] in ("pause", "quran") or not q: continue
                nt, idx = _norm_map(l["t"]); p = nt.find(q)
                if p >= 0:
                    tt = l["a"] + (l["b"] - l["a"]) * (idx[p] / max(1, len(l["t"]))) * 0.97
                    break
        if tt is None or tt < last - 0.05:
            tt = max(last + 0.6, dur * (k + 1) / (n + 1.5))
        res.append(min(tt, dur - 0.8)); last = res[-1]
    return res


def _chars():
    out = {}
    for cid in list(m.HOSTS):
        out[cid] = {}
        for v in ("open", "closed", "blink"):
            sp = Image.open(HERE / "characters" / f"{cid}_{v}.png"); sp = sp.crop(sp.getbbox())
            out[cid][v] = sp.resize((round(sp.width * CH / sp.height), CH), Image.LANCZOS)
    return out


def _blink(t, seed):
    random.seed(int(t / 3.1) * 7 + seed); at = random.uniform(0.3, 2.6)
    return at <= (t % 3.1) < at + 0.14


def render_scene(job):
    (k, sc, P, lines, st, en, d, hosts, out, first) = job
    m.HOSTS = hosts
    dur = en - st; nfr = round(en * FPS) - round(st * FPS)
    bgp = d / "img" / f"{k:02d}.png"
    if "activity" in sc:
        bg = Image.open(bgp).convert("RGB").resize((W, H), Image.LANCZOS); move = False
    else:
        bg = Image.open(bgp).convert("RGB").resize((int(W * 1.12), int(H * 1.12)), Image.LANCZOS); move = True
    chars = _chars(); ids = list(hosts)
    # الترجمة على دفعات قصيرة
    subs = []
    tmp = d / "motion" / f"s{k:02d}"; tmp.mkdir(parents=True, exist_ok=True)
    for q, l in enumerate(lines):
        if l["s"] == "pause": continue
        if l["s"] == "quran":
            p = tmp / f"q{q}.png"; m.sub_png(p, "quran", l); subs.append((l["a"], l["b"], Image.open(p).convert("RGBA"))); continue
        words, chunks, cur = l["t"].split(), [], []
        for w_ in words:
            cur.append(w_)
            if len(cur) >= 12 or (len(cur) >= 6 and w_[-1] in "،.:!؟"):
                chunks.append(" ".join(cur)); cur = []
        if cur: chunks.append(" ".join(cur))
        tot = sum(len(c) for c in chunks); a = l["a"]
        for z, c in enumerate(chunks):
            b = a + (l["b"] - l["a"]) * len(c) / tot
            p = tmp / f"l{q}_{z}.png"; m.sub_png(p, l["s"], {"t": c}); subs.append((a, b, Image.open(p).convert("RGBA"))); a = b
    parts = (P or {}).get("parts") or ([P] if P else [])
    starts = [0.0]
    if len(parts) > 1:
        s2 = cue_times({"template": "points", "items": [{"cue": parts[1].get("start")}]}, lines, dur)[0]
        starts.append(s2 if parts[1].get("start") else dur / 2)
    PT = []
    for q, pp in enumerate(parts):
        a0 = starts[q]; a1 = starts[q + 1] if q + 1 < len(parts) else dur
        sub_lines = [l for l in lines if l["b"] > a0 and l["a"] < a1]
        ti = [max(x - a0, 0.5) for x in cue_times(pp, lines, dur)]
        ti = [x if x < a1 - a0 - 0.3 else (a1 - a0) * (k + 1) / (len(ti) + 1.5) for k, x in enumerate(ti)]
        PT.append((pp, a0, a1, {"i": ti, "end": a1 - a0}))
    P = parts[0] if parts else None
    random.seed(k)
    motes = [(random.uniform(0, W), random.uniform(0, H * .75), random.uniform(2, 5), random.uniform(0, 6.28)) for _ in range(34)]
    veil = Image.new("RGBA", (W, H), (255, 250, 238, 72 if P and P.get("template") != "big" else 30))
    envs = [(l, m._envelope(l["wav"])) for l in lines if l["s"] in ids]
    hp = [x for x in PT if x[0].get("template") in ("price", "story", "jars") and x[3]["i"]]
    happy_t = (hp[-1][1] + hp[-1][3]["i"][-1] + 0.8) if hp else None
    proc = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                             "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-preset", "medium", "-crf", "21",
                             "-pix_fmt", "yuv420p", "-r", str(FPS), str(out)], stdin=subprocess.PIPE)
    for fi in range(nfr):
        t = fi / FPS; ta = st + t
        if move:
            ox = int((bg.width - W) * (0.5 + 0.45 * math.sin(ta * 0.06 + k))); oy = int((bg.height - H) * (0.5 + 0.4 * math.cos(ta * 0.05 + k)))
            fr = bg.crop((ox, oy, ox + W, oy + H)).convert("RGBA")
        else:
            fr = bg.convert("RGBA")
        if P:
            fr.alpha_composite(veil)
            dr = ImageDraw.Draw(fr)
            for x, y, r, ph in motes:
                yy = (y - ta * 14 * r) % (H * .78); xx = x + 18 * math.sin(ta * .6 + ph)
                dr.ellipse((xx - r, yy - r, xx + r, yy + r), fill=(255, 240, 190, int(90 + 60 * math.sin(ta * 2 + ph))))
            for pp, a0, a1, TT in PT:
                if not (a0 - 0.01 <= t < a1 + 0.01):
                    continue
                lt = t - a0
                lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
                if pp.get("title"):
                    paste(lay, title_chip(pp["title"]), CX, TOP + (20 if pp.get("template") == "big" else 0), ease((lt - 0.1) / 0.6))
                try:
                    DRAW[pp["template"]](lay, lt, pp, TT)
                except Exception as e:
                    if fi == 0: print(f"  ⚠ scene {k} template {pp.get('template')}: {e}")
                fade = min(1.0, (a1 - t) / 0.5) if a1 < dur - 0.01 else 1.0
                if fade < 0.99:
                    lay.putalpha(lay.getchannel("A").point(lambda v, f_=fade: int(v * max(0, f_))))
                fr.alpha_composite(lay)
        else:
            pul = 1 + 0.08 * math.sin(t * 4)                  # بطاقة النشاط: رمز إيقاف نابض
            paste(fr, chip("أوقِف الفيديو الآن", 34, (255, 255, 255), (200, 70, 60, 235)), 200, 230, pul)
        # الشخصيتان
        ent = ease((ta - (INTRO - 0.3)) / 0.9) if first else 1.0
        for ci, cid in enumerate(ids):
            talking = op = False
            for l, env in envs:
                if l["s"] == cid and l["a"] <= t < l["b"]:
                    talking = True; z = int((t - l["a"]) / m.STEP); op = z < len(env) and env[z] > 0.35; break
            v = "blink" if _blink(ta, ci * 4 + 1) else ("open" if op else "closed")
            sp = chars[cid][v]; right = ci == 0
            bob = math.sin(ta * 7.5 + ci) * 7 if talking else math.sin(ta * 1.6 + ci) * 3
            lean = (-3 if right else 3) * (1 if talking else 0.3)
            jump = 0
            if happy_t and not right and t >= happy_t:
                g = t - happy_t; jump = max(0, math.sin(g * 6)) * 45 * math.exp(-g * 1.2)
            x = (W - sp.width / 2 - 30 + (1 - ent) * 500) if right else (sp.width / 2 + 30 - (1 - ent) * 500)
            paste(fr, sp, x, H - CH / 2 + 12 - bob - jump, 1.0 + (0.03 if talking else 0), rot=lean)
        for a, b, im in subs:
            if a <= t < b:
                fr.alpha_composite(im); break
        if fi < 8:
            fr = Image.blend(Image.new("RGBA", (W, H), (0, 0, 0, 255)), fr, 0.5 + fi / 16) if not first else fr
        proc.stdin.write(fr.convert("RGB").tobytes())
    proc.stdin.close(); proc.wait()
    return k


def render(ep, script, d, P):
    """يبني episode.mp4 بالحركة المرسومة. الصوت والصور جاهزان مسبقًا (make_audio / make_images)."""
    out = d / "episode.mp4"
    if out.exists():
        return out
    tmp = d / "motion"; tmp.mkdir(exist_ok=True)
    sub = ep.get("subtitle", "")
    m.card(tmp / "intro.png", script["title"], sub, d / "img" / "00.png")
    m.card(tmp / "outro.png", m.OUTRO_TEXT, "إن شاء الله · " + m.SHOW, d / "img" / f"{len(script['scenes']) - 1:02d}.png")
    m.card(d / "thumb.jpg", script["title"], sub, d / "img" / "00.png")
    sil = lambda s, p: subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                                       f"anullsrc=r=24000:cl=mono:d={s}", str(p)], check=True)
    sil(GAP, tmp / "gap.wav"); sil(INTRO, tmp / "in.wav"); sil(OUTRO, tmp / "out.wav")
    seq, t, jobs = [tmp / "in.wav"], INTRO, []
    for i, sc in enumerate(script["scenes"]):
        st, ls = t, []
        for j, l in enumerate(sc["lines"]):
            w = d / "audio" / f"{i:02d}_{j:02d}.wav"; du = m.wav_dur(w)
            ls.append({**l, "a": t, "b": t + du, "wav": w}); seq += [w, tmp / "gap.wav"]; t += du + GAP
        jobs.append([i, sc, P.get(str(i)), ls, st, t, d, m.HOSTS, tmp / f"scene{i:02d}.mp4", i == 0])
    seq.append(tmp / "out.wav"); total = t + OUTRO
    for j in jobs:      # أزمنة السطور نسبةً إلى بداية المشهد
        st = j[4]; j[3] = [{**l, "a": l["a"] - st, "b": l["b"] - st} for l in j[3]]
    (tmp / "audio.txt").write_text("".join(f"file '{p}'\n" for p in seq))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(tmp / "audio.txt"),
                    "-c:a", "pcm_s16le", str(tmp / "voice.wav")], check=True)
    todo = [tuple(j) for j in jobs if not Path(j[8]).exists()]
    with Pool(min(4, os.cpu_count() or 2)) as pool:
        for k in pool.imap_unordered(render_scene, todo):
            print(f"  ✓ scene {k}")
    # المقدّمة والخاتمة بتلاشٍ ناعم
    for name, du in (("intro", INTRO), ("outro", OUTRO)):
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-framerate", str(FPS), "-i", str(tmp / f"{name}.png"),
                        "-t", f"{round(du * FPS) / FPS:.3f}", "-vf", f"scale={W}:{H},format=yuv420p,fade=t=in:st=0:d=0.6,fade=t=out:st={du - 0.6}:d=0.6",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "21", "-r", str(FPS), str(tmp / f"{name}.mp4")], check=True)
    parts = [tmp / "intro.mp4"] + [Path(j[8]) for j in jobs] + [tmp / "outro.mp4"]
    (tmp / "video.txt").write_text("".join(f"file '{p}'\n" for p in parts))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(tmp / "video.txt"),
                    "-i", str(tmp / "voice.wav"), "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
                    "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-shortest", "-movflags", "+faststart", str(out)], check=True)
    for sc, j in zip(script["scenes"], jobs):    # المدد لورقة المعلّم وبيانات يوتيوب
        for l, x in zip(sc["lines"], j[3]):
            l["dur"] = x["b"] - x["a"]
    print(f"  ✓ motion video: {total:.0f}s → {out}")
    return out
