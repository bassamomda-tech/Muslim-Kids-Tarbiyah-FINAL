#!/usr/bin/env python3
"""
عيّنة «الخيار ٢»: دقيقة من الحلقة ٦ (رائد الأعمال الصغير) بحركة مرسومة بالكود فوق الخلفيات المائية نفسها.
لا تستعمل أي نموذج ذكاء اصطناعي جديد: الصوت والخلفيات من بناء الحلقة ٦، وكل الحركة تُرسم بالكود:
  - الكابتن سالم ومريم يدخلان، ويتمايلان ويقفزان ويميلان أثناء الكلام، مع رمش وحركة فم على الصوت.
  - رسوم تشرح الفكرة: دفتر الميزانية يُكتب، عشرة دنانير تسقط، ثم تطير إلى أربع جرار بعدّاد،
    ولعبة بسعر ٦ تقفز، ثم ادّخار ثلاثة أسابيع بشريط تقدّم واحتفال.
  - حركة محيطة: تحريك الكاميرا (بارالاكس)، وذرّات ضوء عائمة، وانتقال ناعم بين المشهدين.
الاستخدام: python3 tools/podcast/motion_sample.py [out.mp4]
"""
import json, math, random, subprocess, sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_episode as m

EP = HERE / "out-series" / "money-curriculum" / "ep06"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else EP / "motion-sample.mp4"
W, H, FPS = 1920, 1080, 25
AR = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")
KW = dict(direction="rtl", language="ar")
m.SHOW = "رائد الأعمال الصغير"
m.HOSTS = {"salim": {"name": "القبطان سالم", "rgb": (140, 210, 255)}, "maryam": {"name": "مريم", "rgb": (255, 205, 120)}}

S = json.loads((EP / "script.json").read_text())
SEG = [(4, 2), (4, 3), (5, 0), (5, 1)]          # (مشهد، سطر) من نص الحلقة ٦
INTRO, GAP, OUTRO = 2.6, 0.35, 2.4


def F(size, wt="Bold"):
    f = ImageFont.truetype(str(HERE / "fonts" / "Cairo.ttf"), size); f.set_variation_by_name(wt); return f


def ease(x):  # ease-out-back قليلًا
    x = max(0.0, min(1.0, x)); c = 1.4
    return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2


def smooth(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)


# ───────────── الصوت والتوقيت ─────────────
def build_audio(tmp):
    seq, t, lines = [], INTRO, []
    sil = lambda s, p: subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                                       f"anullsrc=r=24000:cl=mono:d={s}", str(p)], check=True)
    sil(INTRO, tmp / "in.wav"); sil(GAP, tmp / "gap.wav"); sil(OUTRO, tmp / "out.wav")
    seq.append(tmp / "in.wav")
    for i, j in SEG:
        w = EP / "audio" / f"{i:02d}_{j:02d}.wav"; d = m.wav_dur(w); l = S["scenes"][i]["lines"][j]
        lines.append({"s": l["s"], "t": l["t"], "a": t, "b": t + d, "env": m._envelope(w)})
        seq += [w, tmp / "gap.wav"]; t += d + GAP
    seq.append(tmp / "out.wav"); total = t + OUTRO
    (tmp / "a.txt").write_text("".join(f"file '{p}'\n" for p in seq))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(tmp / "a.txt"),
                    "-c:a", "pcm_s16le", str(tmp / "voice.wav")], check=True)
    return lines, total


def word_time(line, needle, nth=0):
    """زمن تقريبي لكلمة داخل السطر (بنسبة موضعها في النص)."""
    txt, pos = line["t"], -1
    for _ in range(nth + 1):
        pos = txt.find(needle, pos + 1)
    pos = max(pos, 0)
    return line["a"] + (line["b"] - line["a"]) * (pos / len(txt)) * 0.97


# ───────────── عناصر مرسومة (مسبقًا وبتنعيم ×٤) ─────────────
def coin_sprite(r=34):
    s = 4; im = Image.new("RGBA", (r * 2 * s, r * 2 * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse((0, 0, r * 2 * s - 1, r * 2 * s - 1), fill=(201, 146, 34))
    d.ellipse((5 * s, 5 * s, (r * 2 - 5) * s, (r * 2 - 5) * s), fill=(244, 196, 64))
    d.ellipse((11 * s, 11 * s, (r * 2 - 11) * s, (r * 2 - 11) * s), outline=(214, 158, 40), width=3 * s)
    d.ellipse((14 * s, 9 * s, 28 * s, 19 * s), fill=(255, 236, 160))          # لمعة
    return im.resize((r * 2, r * 2), Image.LANCZOS)


def jar_sprite(w=190, h=230):
    s = 3; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((8 * s, 34 * s, (w - 8) * s, (h - 4) * s), 34 * s, fill=(225, 240, 250, 120),
                        outline=(120, 160, 190, 255), width=4 * s)
    d.rounded_rectangle((30 * s, 6 * s, (w - 30) * s, 38 * s), 10 * s, fill=(170, 120, 70), outline=(120, 80, 40), width=3 * s)
    d.rounded_rectangle((26 * s, 60 * s, 40 * s, (h - 40) * s), 7 * s, fill=(255, 255, 255, 120))
    return im.resize((w, h), Image.LANCZOS)


def label(text, size=36, fg=(40, 50, 70), bg=(255, 250, 238, 235), pad=(22, 8)):
    f = F(size); tmp = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    tw = tmp.textlength(text, font=f, **KW); th = int(size * 1.5)
    im = Image.new("RGBA", (int(tw + pad[0] * 2), th + pad[1] * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, im.width - 1, im.height - 1), im.height // 2, fill=bg)
    d.text((im.width / 2, im.height / 2), text, font=f, fill=fg, anchor="mm", **KW)
    return im


def toy_sprite():
    s = 3; w, h = 230, 190; im = Image.new("RGBA", (w * s, h * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((10 * s, 40 * s, 220 * s, 180 * s), 26 * s, fill=(90, 120, 210), outline=(50, 70, 150), width=4 * s)
    d.rectangle((40 * s, 95 * s, 90 * s, 115 * s), fill=(240, 240, 255)); d.rectangle((55 * s, 80 * s, 75 * s, 130 * s), fill=(240, 240, 255))
    for cx, cy, col in ((160, 90, (250, 90, 90)), (185, 115, (90, 220, 120)), (135, 115, (250, 210, 70)), (160, 140, (120, 190, 255))):
        d.ellipse(((cx - 12) * s, (cy - 12) * s, (cx + 12) * s, (cy + 12) * s), fill=col)
    d.rounded_rectangle((95 * s, 8 * s, 135 * s, 44 * s), 8 * s, fill=(70, 95, 180))
    return im.resize((w, h), Image.LANCZOS)


def tag_sprite(text):
    f = F(46); im = Image.new("RGBA", (150, 92), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.polygon([(0, 46), (32, 0), (150, 0), (150, 92), (32, 92)], fill=(255, 214, 90), outline=(170, 120, 20))
    d.ellipse((18, 38, 34, 54), fill=(170, 120, 20))
    d.text((95, 44), text, font=f, fill=(90, 50, 0), anchor="mm", **KW)
    return im


def check_sprite(r=60):
    s = 4; im = Image.new("RGBA", (r * 2 * s, r * 2 * s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse((0, 0, r * 2 * s - 1, r * 2 * s - 1), fill=(46, 170, 90))
    d.line([(r * 0.55 * s, r * 1.05 * s), (r * 0.9 * s, r * 1.4 * s), (r * 1.5 * s, r * 0.65 * s)], fill="white", width=int(r * 0.25 * s), joint="curve")
    return im.resize((r * 2, r * 2), Image.LANCZOS)


def paste(base, sp, cx, cy, scale=1.0, alpha=1.0, rot=0.0):
    if scale <= 0.01 or alpha <= 0.01:
        return
    im = sp
    if abs(scale - 1) > 0.01:
        im = im.resize((max(1, int(sp.width * scale)), max(1, int(sp.height * scale))), Image.BILINEAR)
    if abs(rot) > 0.2:
        im = im.rotate(rot, resample=Image.BICUBIC, expand=True)
    if alpha < 0.99:
        a = im.getchannel("A").point(lambda v: int(v * alpha)); im = im.copy(); im.putalpha(a)
    base.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2)))


# ───────────── الشخصيات ─────────────
CH = 470
def load_char(cid):
    out = {}
    for v in ("open", "closed", "blink"):
        sp = Image.open(HERE / "characters" / f"{cid}_{v}.png"); sp = sp.crop(sp.getbbox())
        out[v] = sp.resize((round(sp.width * CH / sp.height), CH), Image.LANCZOS)
    return out


def mouth(lines, who, t):
    for l in lines:
        if l["s"] == who and l["a"] <= t < l["b"]:
            k = int((t - l["a"]) / m.STEP)
            return k < len(l["env"]) and l["env"][k] > 0.35, True
    return False, False


def blinking(t, seed):
    random.seed(int(t / 3.1) * 7 + seed); at = random.uniform(0.3, 2.6)
    return at <= (t % 3.1) < at + 0.14


# ───────────── المشهد ─────────────
def main():
    tmp = EP / "motion-build"; tmp.mkdir(exist_ok=True)
    lines, total = build_audio(tmp)
    L = {(i, j): lines[k] for k, (i, j) in enumerate(SEG)}
    A, B, C, D = (L[x] for x in SEG)
    # أوقات الأحداث المتزامنة مع الكلام
    t_jar = [word_time(B, "أَرْبَعَةٌ"), word_time(B, "اثْنَانِ"), word_time(B, "اثْنَانِ", 1), word_time(B, "دِينَارَانِ")]
    t_weeks = [D["a"] + (D["b"] - D["a"]) * f for f in (0.45, 0.62, 0.79)]

    bg1 = Image.open(EP / "img" / "04.png").convert("RGB").resize((int(W * 1.12), int(H * 1.12)), Image.LANCZOS)
    bg2 = Image.open(EP / "img" / "05.png").convert("RGB").resize((int(W * 1.12), int(H * 1.12)), Image.LANCZOS)
    chars = {"salim": load_char("salim"), "maryam": load_char("maryam")}
    coin, jar, toy, chk = coin_sprite(), jar_sprite(), toy_sprite(), check_sprite()
    JN = [("أدوات المدرسة", 4), ("احتياط", 2), ("ادّخار لمشروعي", 2), ("رغبة صغيرة", 2)]
    jlab = [label(n, 30) for n, _ in JN]
    title_b = label("مصروف الأسبوع: ١٠ دنانير", 40, fg=(255, 255, 255), bg=(31, 110, 82, 235))
    title_a = label("الميزانية = خطّة نكتبها قبل أن ننفق", 40, fg=(255, 255, 255), bg=(31, 110, 82, 235))
    title_d = label("أجمع ثمنها في ثلاثة أسابيع", 40, fg=(255, 255, 255), bg=(31, 110, 82, 235))
    tag6 = tag_sprite("٦")
    weeks = [label(f"الأسبوع {str(k + 1).translate(AR)}", 28) for k in range(3)]
    # الترجمة على دفعات قصيرة (سطران على الأكثر) موقوتة بنسبة طولها، حتى لا تغطّي الرسوم
    subs = []
    for k, l in enumerate(lines):
        words, chunks, cur = l["t"].split(), [], []
        for w_ in words:
            cur.append(w_)
            if len(cur) >= 12 or (len(cur) >= 6 and w_[-1] in "،.:!؟"):
                chunks.append(" ".join(cur)); cur = []
        if cur: chunks.append(" ".join(cur))
        tot = sum(len(c) for c in chunks); a = l["a"]
        for q, c in enumerate(chunks):
            b = a + (l["b"] - l["a"]) * len(c) / tot
            p = tmp / f"sub{k}_{q}.png"; m.sub_png(p, l["s"], {"t": c})
            subs.append((a, b, Image.open(p).convert("RGBA"))); a = b
    card_in = Image.new("RGBA", (W, H)); m.card(tmp / "intro.png", "عيّنة: حركة مرسومة بالكود", "رائد الأعمال الصغير · الحلقة ٦ · دقيقة واحدة", EP / "img" / "04.png")
    intro = Image.open(tmp / "intro.png").convert("RGBA").resize((W, H))
    random.seed(3)
    motes = [(random.uniform(0, W), random.uniform(0, H * 0.75), random.uniform(2, 5), random.uniform(0, 6.28)) for _ in range(40)]
    jx = [1480 - k * 330 for k in range(4)]; jy = 470               # مواضع الجرار (من اليمين)
    pile = [(960 + (k % 5 - 2) * 62 + (k // 5) * 30, 600 - (k // 5) * 30) for k in range(10)]
    # أيّ دينار يذهب إلى أيّ جرّة
    dest = [0] * 4 + [1] * 2 + [2] * 2 + [3] * 2
    slot = [sum(1 for q in range(k) if dest[q] == dest[k]) for k in range(10)]

    proc = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                             "-r", str(FPS), "-i", "-", "-i", str(tmp / "voice.wav"), "-c:v", "libx264", "-preset", "medium",
                             "-crf", "21", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-shortest",
                             "-movflags", "+faststart", str(OUT)], stdin=subprocess.PIPE)
    n = int(total * FPS)
    for fi in range(n):
        t = fi / FPS
        if t < INTRO - 0.5:
            fr = intro.copy()
            proc.stdin.write(fr.convert("RGB").tobytes()); continue
        # ── الخلفية: تحريك كاميرا بطيء + انتقال بين المشهدين
        sw = smooth((t - (C["a"] - 0.6)) / 1.2)
        ox = int((bg1.width - W) * (0.5 + 0.45 * math.sin(t * 0.07))); oy = int((bg1.height - H) * (0.5 + 0.4 * math.cos(t * 0.05)))
        fr = bg1.crop((ox, oy, ox + W, oy + H))
        if sw > 0:
            fr = Image.blend(fr, bg2.crop((ox, oy, ox + W, oy + H)), sw)
        fr = fr.convert("RGBA")
        veil = Image.new("RGBA", (W, H), (255, 250, 238, 70)); fr.alpha_composite(veil)    # تهدئة الخلفية خلف الرسوم
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
        for x, y, r, ph in motes:                                                       # ذرّات ضوء عائمة
            yy = (y - t * 14 * r) % (H * 0.78); xx = x + 18 * math.sin(t * 0.6 + ph)
            d.ellipse((xx - r, yy - r, xx + r, yy + r), fill=(255, 240, 190, int(90 + 60 * math.sin(t * 2 + ph))))
        fr.alpha_composite(ov)

        # ── المقطع A: دفتر الميزانية يُكتب، والدنانير تسقط
        if A["a"] - 0.3 <= t < C["a"] + 0.4:
            fade = 1 - smooth((t - (C["a"] - 0.4)) / 0.8)
            if t < B["a"]:
                paste(fr, title_a, 960, 120, ease((t - A["a"]) / 0.6), fade)
                pa = smooth((t - A["a"] - 0.4) / 1.0)
                if pa > 0:   # دفتر مفتوح تُكتب سطوره
                    nb = Image.new("RGBA", (520, 340), (0, 0, 0, 0)); nd = ImageDraw.Draw(nb)
                    nd.rounded_rectangle((0, 0, 519, 339), 22, fill=(255, 252, 240, 245), outline=(190, 160, 110), width=4)
                    nd.line((260, 16, 260, 324), fill=(210, 190, 150), width=3)
                    for r_ in range(6):
                        nd.line((30, 60 + r_ * 45, 240, 60 + r_ * 45), fill=(200, 210, 230), width=2)
                        nd.line((280, 60 + r_ * 45, 490, 60 + r_ * 45), fill=(200, 210, 230), width=2)
                        prog = smooth((t - A["a"] - 1.5 - r_ * 1.4) / 1.2)
                        if prog > 0:
                            x0 = 240 if r_ < 3 else 490
                            yy = 48 + (r_ % 3) * 90 + (0 if r_ < 3 else 0)
                            nd.line((x0, yy + 4, x0 - 200 * prog, yy + 4), fill=(60, 80, 140), width=5)
                    paste(fr, nb, 960, 330, 0.6 + 0.4 * pa, pa * fade)
            for k in range(10):                                                   # سقوط الدنانير
                ta = A["a"] + 6 + k * 0.45
                if t < ta: continue
                if t < t_jar[0] - 0.2 or dest[k] is None:
                    yb = pile[k][1]; u = (t - ta) / 0.5
                    y = yb - 420 * (1 - u) ** 2 if u < 1 else yb - abs(math.sin((t - ta - 0.5) * 9)) * 26 * math.exp(-(t - ta - 0.5) * 5)
                    paste(fr, coin, pile[k][0], y, 1.0, fade)
                else:   # طيران الدينار إلى جرّته عند ذكر رقمها
                    j = dest[k]; tf = t_jar[j] + slot[k] * 0.18; u = smooth((t - tf) / 0.7)
                    sx, sy = pile[k]; ex, ey = jx[j], jy + 70 - slot[k] * 22
                    x = sx + (ex - sx) * u; y = sy + (ey - sy) * u - 260 * math.sin(math.pi * u)
                    paste(fr, coin, x, y, 1.0 - 0.25 * u, fade, rot=360 * u)
            if t >= B["a"] - 0.3:                                                # الجرار والعدّادات
                paste(fr, title_b, 960, 120, ease((t - B["a"] + 0.3) / 0.6), fade)
                for j in range(4):
                    a_ = ease((t - B["a"] - j * 0.25) / 0.6)
                    paste(fr, jar, jx[j], jy, a_, fade)
                    paste(fr, jlab[j], jx[j], jy + 160, a_, fade)
                    got = sum(1 for k in range(10) if dest[k] == j and t >= t_jar[j] + slot[k] * 0.18 + 0.7)
                    if got:
                        pop = 1 + 0.35 * math.exp(-(t - (t_jar[j] + (got - 1) * 0.18 + 0.7)) * 6)
                        paste(fr, label(str(got).translate(AR), 54, fg=(255, 255, 255), bg=(201, 146, 34, 245)), jx[j], jy - 150, pop, fade)

        # ── المقطع C/D: اللعبة بسعر ٦، ثم ادّخار ثلاثة أسابيع
        if t >= C["a"] - 0.2:
            u = ease((t - C["a"]) / 0.7)
            bounce = abs(math.sin((t - C["a"]) * 6)) * 30 * math.exp(-(t - C["a"]) * 2.5)
            done = t >= t_weeks[2] + 0.6
            paste(fr, toy, 960 if t < D["a"] else 960 - 330 * smooth((t - D["a"]) / 0.8), 330 - bounce, u * (1.15 if done else 1.0))
            paste(fr, tag6, (1090 if t < D["a"] else 1090 - 330 * smooth((t - D["a"]) / 0.8)), 250 - bounce, u, rot=8 * math.sin(t * 3))
            if t < D["a"]:   # جرّة الرغبة فيها ٢ فقط
                paste(fr, jar, 1380, 470, 0.8 * u); paste(fr, label("رغبة صغيرة: ٢", 28), 1380, 600, u)
                paste(fr, label("٢ أقلّ من ٦", 40, fg=(255, 255, 255), bg=(200, 70, 60, 240)), 1380, 360, ease((t - C["a"] - 1.4) / 0.5))
            else:
                paste(fr, title_d, 960, 120, ease((t - D["a"]) / 0.6))
                bx0, bx1, by = 900, 1520, 470                                     # شريط التقدّم (يُملأ من اليمين)
                bar = Image.new("RGBA", (bx1 - bx0 + 20, 70), (0, 0, 0, 0)); bd = ImageDraw.Draw(bar)
                bd.rounded_rectangle((0, 0, bar.width - 1, 69), 35, fill=(255, 255, 255, 220), outline=(150, 170, 190), width=4)
                filled = sum(smooth((t - tw) / 0.8) for tw in t_weeks) / 3
                if filled > 0:
                    wfill = int((bar.width - 12) * filled)
                    bd.rounded_rectangle((bar.width - 6 - wfill, 6, bar.width - 7, 63), 29, fill=(244, 196, 64))
                paste(fr, bar, (bx0 + bx1) / 2, by, ease((t - D["a"] - 0.3) / 0.6))
                for k in range(3):
                    wx = bx1 - 100 - k * 210
                    paste(fr, weeks[k], wx, by + 75, ease((t - D["a"] - 0.5 - k * 0.15) / 0.5))
                    if t >= t_weeks[k]:
                        pop = 1 + 0.4 * math.exp(-(t - t_weeks[k]) * 6)
                        paste(fr, label("+٢", 34, fg=(255, 255, 255), bg=(201, 146, 34, 245)), wx, by - 70, pop)
                if done:
                    g = t - (t_weeks[2] + 0.6)
                    paste(fr, chk, 700, 250, ease(g / 0.5))
                    random.seed(11)
                    for q in range(26):   # احتفال: نجوم وقصاصات تتطاير
                        ang = random.uniform(0, 6.28); sp_ = random.uniform(160, 420)
                        x = 640 + math.cos(ang) * sp_ * min(g, 1.6); y = 330 + math.sin(ang) * sp_ * min(g, 1.6) + 120 * g * g
                        col = random.choice([(250, 90, 90), (90, 200, 120), (250, 210, 70), (110, 170, 250)])
                        al = max(0.0, 1 - g / 2.2)
                        if al > 0:
                            ImageDraw.Draw(fr).ellipse((x - 9, y - 9, x + 9, y + 9), fill=col + (int(255 * al),))

        # ── الشخصيتان: دخول، تمايل أثناء الكلام، ميل نحو الشرح، قفزة الفرح
        ent = ease((t - (INTRO - 0.5)) / 0.9)
        for cid, side in (("salim", "right"), ("maryam", "left")):
            op, talking = mouth(lines, cid, t)
            v = "blink" if blinking(t, 1 if cid == "salim" else 5) else ("open" if op else "closed")
            sp = chars[cid][v]
            bob = math.sin(t * 7.5) * 7 if talking else math.sin(t * 1.6) * 3
            lean = (-3 if side == "right" else 3) * (1 if talking else 0.3)
            jump = 0
            if cid == "maryam" and t >= t_weeks[2] + 0.6:
                g = t - (t_weeks[2] + 0.6); jump = max(0, math.sin(g * 6)) * 50 * math.exp(-g * 1.2)
            sc = 1.0 + (0.03 if talking else 0)
            x = (W - sp.width / 2 - 30 + (1 - ent) * 500) if side == "right" else (sp.width / 2 + 30 - (1 - ent) * 500)
            paste(fr, sp, x, H - CH / 2 + 12 - bob - jump, sc, rot=lean)
        for a, b, im in subs:                                                    # الترجمة
            if a <= t < b:
                fr.alpha_composite(im); break
        if t > total - OUTRO:
            k = smooth((t - (total - OUTRO)) / 1.2)
            fr = Image.blend(fr, intro, k)
        proc.stdin.write(fr.convert("RGB").tobytes())
    proc.stdin.close(); proc.wait()
    print(f"✓ {OUT} ({total:.0f}s)")


if __name__ == "__main__":
    main()
