#!/usr/bin/env python3
"""
عيّنة دقيقة واحدة برسوم متحركة مرسومة بالكود بالكامل (Cairo)، دون أي نموذج صور.
- النص مكتوب ومشكول يدويًا (لا نموذج نصوص).
- الصوت: Google Cloud TTS (Chirp3-HD).
- الشخصيات: الكابتن سالم ومريم، برمش وحركة شفاه مع الصوت وإيماءات وتمايل.
- مشهدان: سطح «سفينة الأمانة» في البحر، ثم سوق جزيرة المقايضة (خروف، دجاجة، نخيل، تمر).

الاستخدام: python3 tools/podcast/vector_sample.py [out_dir]
"""
import base64, json, math, random, subprocess, sys, urllib.request, wave
from pathlib import Path

import cairo
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
FONTS = HERE / "fonts"
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "out-vector" / "sample"
OUT.mkdir(parents=True, exist_ok=True)
W, H, FPS, SR = 1280, 720, 25, 24000

VOICES = {"salim": ("ar-XA-Chirp3-HD-Iapetus", 1.0), "maryam": ("ar-XA-Chirp3-HD-Aoede", 1.08)}
NAMES = {"salim": ("الكابتن سالم", (140, 210, 255)), "maryam": ("مريم", (255, 205, 120))}

LINES = [
    ("salim", "السَّلَامُ عَلَيْكُمْ يَا رُوَّادَ الْأَعْمَالِ! أَهْلًا بِكُمْ عَلَى سَفِينَةِ الْأَمَانَةِ."),
    ("maryam", "وَعَلَيْكُمُ السَّلَامُ يَا قُبْطَانُ سَالِمُ! إِلَى أَيْنَ نُبْحِرُ الْيَوْمَ؟"),
    ("salim", "إِلَى جَزِيرَةٍ قَدِيمَةٍ، لَا يَعْرِفُ أَهْلُهَا النُّقُودَ أَبَدًا!"),
    ("maryam", "لَا نُقُودَ؟ فَكَيْفَ يَشْتَرُونَ مَا يَحْتَاجُونَ؟"),
    ("salim", "بِالْمُقَايَضَةِ: يُبَادِلُونَ شَيْئًا بِشَيْءٍ. صَاحِبُ الْخَرُوفِ يُرِيدُ تَمْرًا، "
              "فَيُعْطِي خَرُوفَهُ، وَيَأْخُذُ التَّمْرَ."),
    ("maryam", "وَلَكِنْ، مَاذَا لَوْ كَانَ صَاحِبُ التَّمْرِ لَا يُرِيدُ خَرُوفًا؟"),
    ("salim", "سُؤَالٌ ذَكِيٌّ يَا مَرْيَمُ! وَمَاذَا لَوْ أَرَادَ قَلِيلًا مِنَ التَّمْرِ فَقَطْ؟ "
              "هَلْ يَقْسِمُ الْخَرُوفَ نِصْفَيْنِ؟"),
    ("maryam", "لَا طَبْعًا! مِسْكِينٌ هَذَا الْخَرُوفُ!"),
    ("salim", "لِهَذَا اخْتَرَعَ النَّاسُ النُّقُودَ. وَفِي الدَّرْسِ الْقَادِمِ نَعْرِفُ كَيْفَ، إِنْ شَاءَ اللَّهُ."),
]
SCENE2_AT_LINE = 3        # يبدأ مشهد الجزيرة مع هذا السطر
SHEEP_IN_LINE = 4         # يدخل الخروف
SHEEP_SHAKE_LINE = 6      # يرتجف الخروف خوفًا من «نصفين»
INTRO, OUTRO, GAP = 2.5, 3.0, 0.35

# ───────────────────────── الصوت ─────────────────────────

def tts(text, voice, pitch, path):
    if path.exists():
        return
    body = {"input": {"text": text}, "voice": {"languageCode": "ar-XA", "name": voice},
            "audioConfig": {"audioEncoding": "LINEAR16", "sampleRateHertz": SR}}
    req = urllib.request.Request("https://texttospeech.googleapis.com/v1/text:synthesize",
                                 json.dumps(body).encode(), {"Content-Type": "application/json"})
    raw = path.with_suffix(".raw.wav")
    with urllib.request.urlopen(req, timeout=120) as r:
        raw.write_bytes(base64.b64decode(json.load(r)["audioContent"]))
    af = f"asetrate={SR}*{pitch},aresample={SR},atempo={1/pitch:.4f}," if pitch != 1 else ""
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-af",
                    af + "silenceremove=start_periods=1:start_threshold=-45dB,areverse,"
                    "silenceremove=start_periods=1:start_threshold=-45dB,areverse",
                    "-ar", str(SR), "-ac", "1", str(path)], check=True)
    raw.unlink()


def read_wav(p):
    with wave.open(str(p)) as w:
        return np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768


def build_audio():
    a = OUT / "audio"; a.mkdir(exist_ok=True)
    total = [np.zeros(int(INTRO * SR), np.float32)]
    timeline, t = [], INTRO
    for i, (sp, text) in enumerate(LINES):
        p = a / f"{i:02d}.wav"
        tts(text, *VOICES[sp], p)
        x = read_wav(p)
        timeline.append({"i": i, "s": sp, "t": text, "start": t, "end": t + len(x) / SR, "x": x})
        total += [x, np.zeros(int(GAP * SR), np.float32)]
        t += len(x) / SR + GAP
    total.append(np.zeros(int(OUTRO * SR), np.float32))
    y = np.concatenate(total)
    with wave.open(str(OUT / "voice.wav"), "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(y, -1, 1) * 32767).astype(np.int16).tobytes())
    return timeline, len(y) / SR


def mouth_open(timeline, sp, t):
    """فتحة الفم (٠–١) من طاقة الصوت حول اللحظة t للمتكلّم sp."""
    for L in timeline:
        if L["s"] == sp and L["start"] <= t < L["end"]:
            k = int((t - L["start"]) * SR); win = L["x"][max(0, k - 600):k + 600]
            if not len(win):
                return 0
            return float(min(1, np.sqrt(np.mean(win ** 2)) * 7))
    return 0


def speaking(timeline, sp, t):
    return any(L["s"] == sp and L["start"] <= t < L["end"] for L in timeline)

# ───────────────────────── أدوات الرسم ─────────────────────────

def rgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def fill(c, col, a=1):
    c.set_source_rgba(*rgb(col), a); c.fill()


def ellipse(c, x, y, rx, ry):
    c.save(); c.translate(x, y); c.scale(rx, max(ry, 0.01)); c.arc(0, 0, 1, 0, 2 * math.pi); c.restore()


def rrect(c, x, y, w, h, r):
    r = min(r, w / 2, h / 2)
    c.new_sub_path()
    c.arc(x + w - r, y + r, r, -math.pi / 2, 0); c.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    c.arc(x + r, y + h - r, r, math.pi / 2, math.pi); c.arc(x + r, y + r, r, math.pi, 1.5 * math.pi)
    c.close_path()


def outline(c, col="#3a2a20", w=3):
    c.set_source_rgba(*rgb(col), 1); c.set_line_width(w); c.stroke_preserve()

# ───────────────────────── الشخصيات ─────────────────────────

def blink(t, seed):
    """يرمش لمدة ١٢٠ مللي ثانية كل ٢٫٥–٤٫٥ ثانية."""
    rnd = random.Random(seed); s = 0.8
    while s < t:
        if s <= t < s + 0.12:
            return True
        s += rnd.uniform(2.5, 4.5)
    return False


def draw_eyes(c, cx, cy, gap, r, look, closed, lashes=False):
    for sx in (-1, 1):
        x = cx + sx * gap
        if closed:
            c.move_to(x - r, cy); c.curve_to(x - r / 2, cy + r * .5, x + r / 2, cy + r * .5, x + r, cy)
            c.set_source_rgb(*rgb("#2a1a12")); c.set_line_width(3); c.stroke(); continue
        ellipse(c, x, cy, r, r * 1.15); fill(c, "#ffffff"); ellipse(c, x, cy, r, r * 1.15)
        c.set_source_rgb(*rgb("#2a1a12")); c.set_line_width(2); c.stroke()
        ellipse(c, x + look * r * .35, cy + 1, r * .6, r * .68); fill(c, "#3b2416")
        ellipse(c, x + look * r * .35 - r * .2, cy - r * .25, r * .2, r * .2); fill(c, "#ffffff")
        if lashes:
            for k in (-1, 0, 1):
                c.move_to(x + k * r * .55, cy - r * 1.05); c.line_to(x + k * r * .75, cy - r * 1.45)
            c.set_source_rgb(*rgb("#2a1a12")); c.set_line_width(2.2); c.stroke()


def draw_mouth(c, x, y, o, w=15, beard=False):
    if o < 0.08:
        c.move_to(x - w, y); c.curve_to(x - w / 2, y + 8, x + w / 2, y + 8, x + w, y)
        c.set_source_rgb(*rgb("#5a1f1a")); c.set_line_width(3.5); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
        return
    h = 4 + 15 * o
    ellipse(c, x, y + h / 3, w * (0.75 + .25 * o), h); fill(c, "#6b1f1f")
    ellipse(c, x, y + h * .9, w * .5, h * .35); fill(c, "#d9666a")
    if not beard:
        rrect(c, x - w * .55, y + h / 3 - h + 1, w * 1.1, 5, 2); fill(c, "#ffffff")


def arm(c, sx, sy, ang, length, width, sleeve, skin, hold=None):
    c.save(); c.translate(sx, sy); c.rotate(ang)
    rrect(c, -width / 2, 0, width, length, width / 2); fill(c, sleeve)
    rrect(c, -width / 2, 0, width, length, width / 2); outline(c, "#2b2b3a", 2); c.new_path()
    ellipse(c, 0, length, width * .55, width * .55); fill(c, skin)
    if hold:
        hold(c, length)
    c.restore()


def draw_salim(c, x, y, t, o, talk, look, sc=1.0):
    c.save(); c.translate(x, y); c.scale(sc, sc)
    breathe = 1 + 0.012 * math.sin(t * 2.2)
    bob = -abs(math.sin(t * 6)) * 3 if talk else 0
    c.translate(0, bob)
    skin, navy = "#c98e62", "#22325a"
    # الساقان والحذاء
    for sx in (-1, 1):
        rrect(c, sx * 22 - 15, -125, 30, 120, 10); fill(c, "#1d2742")
        ellipse(c, sx * 26, -6, 24, 10); fill(c, "#111111")
    c.save(); c.scale(1, breathe)
    # الذراع البعيدة (اليسرى للشخصية) ثابتة تقريبًا
    arm(c, 66, -262, -0.12 + .03 * math.sin(t * 1.7), 118, 30, "#f4f4f4", skin)
    # الجذع: قميص أبيض وسترة كحلية
    rrect(c, -70, -275, 140, 160, 26); fill(c, "#f4f4f4")
    c.move_to(-70, -250); c.line_to(-14, -272); c.line_to(0, -205); c.line_to(14, -272); c.line_to(70, -250)
    c.line_to(70, -125); c.curve_to(70, -112, -70, -112, -70, -125); c.close_path(); fill(c, navy)
    for k in range(3):
        ellipse(c, 0, -190 + k * 24, 4.5, 4.5); fill(c, "#e7b84a")
    rrect(c, -70, -275, 140, 160, 26); outline(c, "#1b2238", 2.5); c.new_path()
    # الذراع القريبة: تومئ أثناء الكلام
    g = (0.75 + 0.35 * math.sin(t * 3.1)) if talk else 0.12 + .03 * math.sin(t * 1.3)
    arm(c, -66, -262, g, 118, 30, "#f4f4f4", skin)          # تومئ نحو مريم (يسار الشاشة)
    c.restore()
    # الرقبة والرأس
    hy = -330 + (2 * math.sin(t * 2.2))
    tilt = (0.05 * math.sin(t * 2.6)) if talk else 0.02 * math.sin(t * .9)
    c.save(); c.translate(0, hy); c.rotate(tilt)
    rrect(c, -15, 30, 30, 34, 6); fill(c, skin)
    for sx in (-1, 1):
        ellipse(c, sx * 49, 2, 9, 14); fill(c, skin)
    ellipse(c, 0, 0, 48, 56); fill(c, skin); ellipse(c, 0, 0, 48, 56); outline(c, "#7a4a2c", 2); c.new_path()
    # اللحية
    c.move_to(-48, -2); c.curve_to(-50, 50, -25, 74, 0, 74); c.curve_to(25, 74, 50, 50, 48, -2)
    c.curve_to(40, 18, 30, 26, 18, 22); c.curve_to(8, 18, -8, 18, -18, 22); c.curve_to(-30, 26, -40, 18, -48, -2)
    c.close_path(); fill(c, "#2b1d14")
    # الشارب
    c.move_to(-20, 16); c.curve_to(-10, 8, 10, 8, 20, 16); c.curve_to(10, 13, -10, 13, -20, 16)
    c.set_source_rgb(*rgb("#2b1d14")); c.set_line_width(6); c.stroke()
    draw_mouth(c, 0, 26, o, 14, beard=True)
    # الحاجبان
    for sx in (-1, 1):
        c.move_to(sx * 10, -27 - (4 if talk and o > .5 else 0)); c.line_to(sx * 32, -22)
        c.set_source_rgb(*rgb("#2b1d14")); c.set_line_width(5); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
    draw_eyes(c, 0, -6, 20, 9, look, blink(t, 11))
    ellipse(c, 0, 8, 6, 5); fill(c, "#b57a50")
    # قبّعة القبطان
    c.move_to(-50, -30); c.curve_to(-58, -82, 58, -82, 50, -30); c.close_path(); fill(c, navy)
    rrect(c, -50, -40, 100, 14, 5); fill(c, "#f4f4f4")
    ellipse(c, 0, -27, 54, 9); fill(c, "#111111")
    ellipse(c, 0, -58, 9, 9); fill(c, "#e7b84a")
    c.move_to(0, -64); c.line_to(0, -52); c.set_source_rgb(*rgb(navy)); c.set_line_width(2.5); c.stroke()
    c.restore(); c.restore()


def draw_maryam(c, x, y, t, o, talk, look, sc=1.0):
    c.save(); c.translate(x, y); c.scale(sc, sc)
    bob = -abs(math.sin(t * 6.5)) * 3 if talk else 0
    c.translate(0, bob)
    skin, dress, hijab = "#d9a07a", "#e0a530", "#2a3d6b"
    for sx in (-1, 1):
        rrect(c, sx * 16 - 11, -40, 22, 36, 8); fill(c, "#e9d2b4")
        ellipse(c, sx * 18, -5, 18, 8); fill(c, "#7a3b20")
    breathe = 1 + 0.014 * math.sin(t * 2.4 + 1)
    c.save(); c.scale(1, breathe)
    arm(c, 52, -195, -((0.7 + 0.3 * math.sin(t * 3.3)) if talk else 0.10 + .03 * math.sin(t * 1.9)), 92, 26, dress, skin)
    # الثوب
    c.move_to(-48, -205); c.curve_to(-62, -150, -78, -80, -80, -38); c.line_to(80, -38)
    c.curve_to(78, -80, 62, -150, 48, -205); c.close_path(); fill(c, dress)
    c.move_to(-48, -205); c.curve_to(-62, -150, -78, -80, -80, -38); c.line_to(80, -38)
    c.curve_to(78, -80, 62, -150, 48, -205); c.close_path(); outline(c, "#8a5a10", 2.5); c.new_path()
    # الذراع القريبة تحمل الدفتر
    def notebook(cc, L):
        rrect(cc, -26, L - 34, 46, 58, 5); fill(cc, "#3b73c4")
        rrect(cc, -20, L - 28, 34, 46, 3); fill(cc, "#e9f0fb")
    arm(c, -50, -195, 0.45, 86, 26, dress, skin, hold=notebook)
    c.restore()
    hy = -255 + 2 * math.sin(t * 2.4)
    tilt = (0.06 * math.sin(t * 2.9)) if talk else 0.03 * math.sin(t * 1.1)
    c.save(); c.translate(0, hy); c.rotate(tilt)
    # الحجاب: إطار حول الوجه مع انسدال على الكتفين
    c.move_to(-60, 0); c.curve_to(-64, -78, 64, -78, 60, 0); c.curve_to(62, 40, 70, 58, 62, 62)
    c.line_to(-62, 62); c.curve_to(-70, 58, -62, 40, -60, 0); c.close_path(); fill(c, hijab)
    ellipse(c, 0, 4, 40, 46); fill(c, skin)
    c.move_to(-60, 0); c.curve_to(-64, -78, 64, -78, 60, 0)
    c.set_source_rgb(*rgb("#1a2848")); c.set_line_width(2.5); c.stroke()
    # الخدّان
    for sx in (-1, 1):
        ellipse(c, sx * 24, 18, 8, 5); fill(c, "#f08a8a", .45)
    draw_eyes(c, 0, -2, 17, 9.5, look, blink(t, 23), lashes=True)
    for sx in (-1, 1):
        c.move_to(sx * 8, -24 - (3 if talk and o > .5 else 0)); c.curve_to(sx * 14, -28, sx * 22, -27, sx * 26, -21)
        c.set_source_rgb(*rgb("#3b2416")); c.set_line_width(3.5); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()
    ellipse(c, 0, 12, 4, 3); fill(c, "#b87a58")
    draw_mouth(c, 0, 26, o, 12)
    c.restore(); c.restore()

# ───────────────────────── الحيوانات والعناصر ─────────────────────────

def draw_sheep(c, x, y, t, walking, shake, sc=1.0):
    c.save(); c.translate(x + (math.sin(t * 45) * 4 if shake else 0), y); c.scale(sc, sc)
    ph = t * 9 if walking else 0
    for k, lx in enumerate((-38, -16, 18, 40)):
        off = math.sin(ph + k * math.pi) * 7 if walking else 0
        c.save(); c.translate(lx, -36); c.rotate(off * .03)
        rrect(c, -6, 0, 12, 38, 5); fill(c, "#3a3a3a"); c.restore()
    by = -62 + (abs(math.sin(ph)) * -3 if walking else 0)
    for dx, dy, r in [(-40, 0, 26), (-15, -14, 30), (15, -14, 30), (40, 0, 26), (-25, 12, 26), (25, 12, 26), (0, 6, 30)]:
        ellipse(c, dx, by + dy, r, r); fill(c, "#f7f2e6")
    for dx, dy, r in [(-40, 0, 26), (-15, -14, 30), (15, -14, 30), (40, 0, 26)]:
        c.arc(dx, by + dy, r, math.pi * 1.05, math.pi * 1.95); c.set_source_rgb(*rgb("#d8cdb6")); c.set_line_width(2); c.stroke()
    hx, hy = -64, by - 18
    c.save(); c.translate(hx, hy); c.rotate(-0.15 + (0.05 * math.sin(t * 3)))
    for s in (-1, 1):
        c.save(); c.translate(s * 18, -10); c.rotate(s * 0.8); ellipse(c, 0, 0, 14, 7); fill(c, "#3a3a3a"); c.restore()
    ellipse(c, 0, 0, 20, 26); fill(c, "#3d3d3d")
    ellipse(c, 0, -22, 18, 10); fill(c, "#f7f2e6")
    for s in (-1, 1):
        r = 6.5 if shake else 5
        ellipse(c, s * 8, -4, r, r); fill(c, "#ffffff")
        ellipse(c, s * 8, -3, 2.6, 2.6); fill(c, "#111111")
    if shake:                                   # قطرات عرق
        for k, (dx, dy) in enumerate([(26, -20), (-28, -14)]):
            yy = dy + (t * 40 + k * 10) % 16
            c.move_to(dx, yy - 8); c.curve_to(dx + 5, yy, dx + 5, yy + 6, dx, yy + 6)
            c.curve_to(dx - 5, yy + 6, dx - 5, yy, dx, yy - 8); fill(c, "#7cc4f2")
    c.restore(); c.restore()


def draw_chicken(c, x, y, t, sc=1.0):
    c.save(); c.translate(x, y); c.scale(sc, sc)
    peck = max(0, math.sin(t * 2.3)) ** 6
    for s in (-1, 1):
        c.move_to(s * 8, -18); c.line_to(s * 10, 0); c.set_source_rgb(*rgb("#e0a020")); c.set_line_width(4); c.stroke()
    ellipse(c, 0, -38, 32, 24); fill(c, "#b86b3a")
    c.move_to(22, -50); c.curve_to(46, -74, 52, -44, 30, -34); fill(c, "#8a4a26")      # الذيل
    ellipse(c, 4, -36, 16, 10); fill(c, "#9a5630")                                       # الجناح
    hx, hy = -30 + peck * -6, -60 + peck * 34
    ellipse(c, hx, hy, 13, 13); fill(c, "#c47a44")
    for k in range(3):
        ellipse(c, hx - 4 + k * 5, hy - 13, 4, 5); fill(c, "#d8322e")
    c.move_to(hx - 12, hy - 2); c.line_to(hx - 24, hy + 2); c.line_to(hx - 12, hy + 5); fill(c, "#f0b020")
    ellipse(c, hx - 4, hy - 3, 2.5, 2.5); fill(c, "#111111")
    c.restore()


def draw_dates_basket(c, x, y, sc=1.0):
    c.save(); c.translate(x, y); c.scale(sc, sc)
    for k in range(9):
        ellipse(c, -40 + k * 10, -52 - (k % 3) * 6, 9, 6); fill(c, "#5b2a12" if k % 2 else "#73361a")
    c.move_to(-55, -48); c.line_to(55, -48); c.line_to(42, 0); c.line_to(-42, 0); c.close_path(); fill(c, "#b07a3a")
    for k in range(4):
        c.move_to(-52 + k * 1.5, -38 + k * 10); c.line_to(52 - k * 1.5, -38 + k * 10)
    c.set_source_rgb(*rgb("#8a5a24")); c.set_line_width(2); c.stroke()
    c.restore()


def palm(c, x, y, t, h=260, sc=1.0):
    c.save(); c.translate(x, y); c.scale(sc, sc)
    sway = 0.04 * math.sin(t * 1.2 + x)
    c.move_to(-9, 0); c.curve_to(-6, -h * .5, 10, -h * .8, 14 + sway * 200, -h)
    c.line_to(24 + sway * 200, -h); c.curve_to(22, -h * .8, 8, -h * .5, 9, 0); c.close_path(); fill(c, "#8a6038")
    c.translate(18 + sway * 200, -h)
    for k in range(7):
        a = -math.pi + k * math.pi / 6 + sway * 2
        c.save(); c.rotate(a + math.pi / 2)
        c.move_to(0, 0); c.curve_to(25, -30, 70, -20, 100, 22); c.curve_to(60, -2, 25, -4, 0, 0); fill(c, "#3e8a3e")
        c.restore()
    for k in range(3):
        ellipse(c, -6 + k * 7, 8, 6, 8); fill(c, "#7a3a14")
    c.restore()


def cloud(c, x, y, s):
    for dx, dy, r in [(0, 0, 30), (30, -12, 36), (64, 0, 30), (32, 10, 30)]:
        ellipse(c, x + dx * s, y + dy * s, r * s, r * s); fill(c, "#ffffff", .92)


def gull(c, x, y, t, s=1):
    f = math.sin(t * 7) * 10 * s
    c.move_to(x - 22 * s, y - f); c.curve_to(x - 10 * s, y - 8 * s, x - 4 * s, y - 6 * s, x, y)
    c.curve_to(x + 4 * s, y - 6 * s, x + 10 * s, y - 8 * s, x + 22 * s, y - f)
    c.set_source_rgb(*rgb("#4a4a5a")); c.set_line_width(3 * s); c.set_line_cap(cairo.LINE_CAP_ROUND); c.stroke()

# ───────────────────────── المشاهد ─────────────────────────

def sky(c, top, bottom):
    g = cairo.LinearGradient(0, 0, 0, H); g.add_color_stop_rgb(0, *rgb(top)); g.add_color_stop_rgb(1, *rgb(bottom))
    c.rectangle(0, 0, W, H); c.set_source(g); c.fill()


def scene_ship(c, t):
    sky(c, "#7cc3f0", "#e8f6ff")
    for k in range(10):
        c.arc(1040, 120, 60 + k * 6, 0, 2 * math.pi); c.set_source_rgba(1, .9, .5, .05); c.fill()
    ellipse(c, 1040, 120, 58, 58); fill(c, "#ffd95a")
    for i, (cx, cy, s, v) in enumerate([(200, 110, 1.1, 10), (620, 70, .8, 6), (900, 210, .7, 8)]):
        cloud(c, (cx + t * v) % (W + 300) - 150, cy, s)
    for i, (gx, gy, s) in enumerate([(300, 200, 1), (380, 170, .7), (760, 150, .8)]):
        gull(c, (gx + t * 30 * s) % (W + 100) - 50, gy + 8 * math.sin(t + i), t + i, s)
    c.save()
    c.translate(W / 2, H); c.rotate(0.012 * math.sin(t * .9)); c.translate(-W / 2, -H)
    for k, (col, base, amp, sp) in enumerate([("#2f7fc4", 330, 8, 1.2), ("#2a6fb0", 350, 10, -1.6), ("#245f9c", 375, 12, 2.0)]):
        c.move_to(-20, H)
        for xx in range(-20, W + 40, 20):
            c.line_to(xx, base + amp * math.sin(xx / 70 + t * sp + k))
        c.line_to(W + 20, H); c.close_path(); fill(c, col)
    # الصاري والشراع
    rrect(c, 615, 20, 18, 420, 6); fill(c, "#7a5230")
    bulge = 20 + 6 * math.sin(t * 1.3)
    c.move_to(640, 50); c.curve_to(760 + bulge, 120, 760 + bulge, 260, 640, 330); c.close_path(); fill(c, "#fbf6ea")
    c.move_to(640, 50); c.curve_to(760 + bulge, 120, 760 + bulge, 260, 640, 330); c.close_path(); outline(c, "#cbbf9f", 2); c.new_path()
    # سطح السفينة
    c.rectangle(-40, 440, W + 80, H); fill(c, "#a8743f")
    for k in range(7):
        c.move_to(-40, 470 + k * 42); c.line_to(W + 40, 470 + k * 42)
    c.set_source_rgb(*rgb("#8a5a2c")); c.set_line_width(3); c.stroke()
    rrect(c, -40, 395, W + 80, 18, 6); fill(c, "#7a4f28")
    for xx in range(0, W + 1, 80):
        rrect(c, xx - 6, 400, 12, 48, 4); fill(c, "#7a4f28")
    # برميل وحبل
    rrect(c, 1120, 430, 70, 90, 18); fill(c, "#8a5a2c")
    for yy in (450, 500):
        c.rectangle(1120, yy, 70, 7); fill(c, "#4a4a4a")
    c.restore()


def scene_island(c, t):
    sky(c, "#8fd0f5", "#fff2d6")
    ellipse(c, 1110, 95, 46, 46); fill(c, "#ffe27a")
    for cx, cy, s, v in [(150, 90, .9, 7), (700, 60, .7, 5)]:
        cloud(c, (cx + t * v) % (W + 300) - 150, cy, s)
    c.move_to(0, 300)
    for xx in range(0, W + 1, 20):
        c.line_to(xx, 300 + 4 * math.sin(xx / 60 + t * 1.5))
    c.line_to(W, 340); c.line_to(0, 340); c.close_path(); fill(c, "#4aa3d8")
    # بيوت طينية بقباب
    for hx, hw, hh, dome in [(70, 170, 150, True), (260, 130, 120, False), (880, 150, 140, True), (1060, 190, 165, False)]:
        rrect(c, hx, 340 - hh, hw, hh + 20, 6); fill(c, "#e3c28f")
        if dome:
            c.arc(hx + hw / 2, 340 - hh, hw * .3, math.pi, 2 * math.pi); fill(c, "#f0d6a8")
        c.move_to(hx + hw / 2 - 18, 360); c.line_to(hx + hw / 2 - 18, 320); c.arc(hx + hw / 2, 320, 18, math.pi, 2 * math.pi)
        c.line_to(hx + hw / 2 + 18, 360); c.close_path(); fill(c, "#7a5232")
        for wx in (hx + 22, hx + hw - 42):
            c.move_to(wx, 300 - hh * .3); c.line_to(wx, 284 - hh * .3); c.arc(wx + 10, 284 - hh * .3, 10, math.pi, 2 * math.pi)
            c.line_to(wx + 20, 300 - hh * .3); c.close_path(); fill(c, "#6a4a2c")
    # الأرض الرملية
    c.move_to(0, 350); c.curve_to(400, 330, 800, 365, W, 345); c.line_to(W, H); c.line_to(0, H); c.close_path(); fill(c, "#ecd09a")
    for k in range(40):
        rnd = random.Random(k); ellipse(c, rnd.uniform(0, W), rnd.uniform(400, H), 3, 1.6); fill(c, "#d4b47a")
    palm(c, 520, 380, t, 250); palm(c, 1230, 420, t, 300, .9); palm(c, 30, 430, t, 280, .85)
    # كشك السوق بمظلّة مخطّطة
    rrect(c, 560, 300, 12, 200, 3); fill(c, "#7a5232"); rrect(c, 840, 300, 12, 200, 3); fill(c, "#7a5232")
    for k in range(7):
        c.move_to(548 + k * 44, 300); c.line_to(592 + k * 44, 300); c.line_to(592 + k * 44, 330)
        c.curve_to(585 + k * 44, 345, 555 + k * 44, 345, 548 + k * 44, 330); c.close_path()
        fill(c, "#d8433a" if k % 2 else "#fbf3e0")
    rrect(c, 570, 420, 270, 70, 6); fill(c, "#9a6a3a")
    draw_dates_basket(c, 650, 422, .9)
    for k, col in enumerate(["#e8b23a", "#c85a2a", "#7a9a3a"]):                # أكياس توابل
        c.move_to(730 + k * 34, 420); c.curve_to(722 + k * 34, 390, 758 + k * 34, 390, 750 + k * 34, 420); fill(c, col)
    # جرار فخارية
    for jx in (440, 470):
        ellipse(c, jx, 560, 22, 28); fill(c, "#b4643a"); rrect(c, jx - 10, 528, 20, 10, 3); fill(c, "#9a5230")

# ───────────────────────── النصوص (Pillow + raqm) ─────────────────────────

def font(size, wt="Bold"):
    f = ImageFont.truetype(str(FONTS / "Cairo.ttf"), size)
    try:
        f.set_variation_by_name(wt)
    except Exception:
        pass
    return f


def wrap(dr, text, f, width, kw):
    out, cur = [], ""
    for w_ in text.split():
        t = (cur + " " + w_).strip()
        if dr.textlength(t, font=f, **kw) > width and cur:
            out.append(cur); cur = w_
        else:
            cur = t
    return out + [cur]


def to_surface(im):
    a = np.array(im.convert("RGBA")).astype(np.float32)
    a[..., :3] *= a[..., 3:4] / 255
    bgra = a[..., [2, 1, 0, 3]].astype(np.uint8).copy()
    return cairo.ImageSurface.create_for_data(memoryview(bgra), cairo.FORMAT_ARGB32, im.width, im.height), bgra


def subtitle(sp, text):
    kw = dict(direction="rtl", language="ar")
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
    f = font(30, "SemiBold"); name, col = NAMES[sp]
    x0, x1 = 300, W - 300
    lines = wrap(dr, f"{name}: {text}", f, x1 - x0 - 40, kw)
    lh = 46; h = lh * len(lines) + 26; y0 = H - 28 - h
    dr.rounded_rectangle((x0, y0, x1, H - 28), 16, fill=(25, 30, 40, 200))
    y = y0 + 12
    for k, ln in enumerate(lines):
        if k == 0 and ln.startswith(name):
            rest = ln[len(name):]
            wn = dr.textlength(name, font=f, **kw)
            dr.text((x1 - 20, y), name, font=f, fill=col, anchor="ra", **kw)
            dr.text((x1 - 20 - wn, y), rest, font=f, fill="white", anchor="ra", **kw)
        else:
            dr.text((x1 - 20, y), ln, font=f, fill="white", anchor="ra", **kw)
        y += lh
    return to_surface(im)


def title_card(title, sub):
    kw = dict(direction="rtl", language="ar")
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
    dr.rounded_rectangle((260, 230, W - 260, 470), 30, fill=(20, 45, 80, 215))
    dr.text((W / 2, 320), title, font=font(70), fill=(255, 225, 140), anchor="mm", **kw)
    dr.text((W / 2, 405), sub, font=font(34, "SemiBold"), fill="white", anchor="mm", **kw)
    return to_surface(im)

# ───────────────────────── التركيب ─────────────────────────

def main():
    timeline, dur = build_audio()
    subs = {L["i"]: subtitle(L["s"], L["t"]) for L in timeline}
    intro = title_card("رائد الأعمال الصغير", "عيّنة · الكابتن سالم ومريم · ٨–١٣ سنة")
    outro = title_card("نلقاكم في الدرس القادم", "إن شاء الله")
    t_scene2 = timeline[SCENE2_AT_LINE]["start"] - GAP / 2
    t_sheep = timeline[SHEEP_IN_LINE]["start"] + 1.2
    sh = timeline[SHEEP_SHAKE_LINE]
    n = int(dur * FPS)
    surf = cairo.ImageSurface(cairo.FORMAT_RGB24, W, H)
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgra",
                           "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-i", str(OUT / "voice.wav"),
                           "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
                           "-c:a", "aac", "-b:a", "160k", "-ar", "44100", "-ac", "2", "-shortest", "-movflags", "+faststart",
                           str(OUT / "sample.mp4")], stdin=subprocess.PIPE)
    for fi in range(n):
        t = fi / FPS
        c = cairo.Context(surf)
        island = t >= t_scene2
        (scene_island if island else scene_ship)(c, t)
        if island:
            # الخروف يدخل من اليسار ويقف قرب الكشك، والدجاجة تنقر
            if t >= t_sheep:
                p = min(1, (t - t_sheep) / 3.0)
                sx = -120 + p * 520
                draw_sheep(c, sx, 610, t, walking=p < 1, shake=sh["start"] + 2.0 <= t < sh["end"] + 1.5, sc=1.0)
            draw_chicken(c, 860, 585, t, 1.0)
        floor = 690
        o_s = mouth_open(timeline, "salim", t); o_m = mouth_open(timeline, "maryam", t)
        draw_salim(c, 1090, floor, t, o_s, speaking(timeline, "salim", t), look=-1, sc=1.0)
        draw_maryam(c, 190, floor, t, o_m, speaking(timeline, "maryam", t), look=1, sc=1.0)
        # انتقال بين المشهدين: وميض أبيض قصير
        dt = abs(t - t_scene2)
        if dt < 0.35:
            c.rectangle(0, 0, W, H); c.set_source_rgba(1, 1, 1, 1 - dt / 0.35); c.fill()
        for L in timeline:
            if L["start"] <= t < L["end"] + GAP:
                c.set_source_surface(subs[L["i"]][0], 0, 0); c.paint(); break
        if t < INTRO:
            c.set_source_surface(intro[0], 0, 0); c.paint_with_alpha(min(1, (INTRO - t) / 0.5))
        if t > dur - OUTRO:
            c.set_source_surface(outro[0], 0, 0); c.paint_with_alpha(min(1, (t - (dur - OUTRO)) / 0.5))
        surf.flush()
        ff.stdin.write(bytes(surf.get_data()))
    ff.stdin.close(); ff.wait()
    print(f"✓ {dur:.1f}s → {OUT / 'sample.mp4'}")


if __name__ == "__main__":
    main()
