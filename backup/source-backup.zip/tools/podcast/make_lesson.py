#!/usr/bin/env python3
"""
فيديوهات دروس منهج «المال وريادة الأعمال» — درس لكل أسبوع (٣٦ درسًا).
الافتراضي: نسخة واحدة موحّدة لأعمار ٨–١٣:
  m  ٨–١٣   «رائد الأعمال الصغير»   الكابتن سالم ومريم — فريق «سفينة الأمانة»
ونسخ اختيارية حسب الفئة:
  a  ٧–٩    «التاجر الصغير»         العمّ أمين وسلمى (من رحلة الموقع)
  b  ١٠–١٢  «رائد الأعمال الصغير»   الكابتن سالم ومريم — فريق «سفينة الأمانة»
  c  ١٣+    «رائد الأعمال الأمين»   الأستاذ خالد وعمر — «مجلس الشورى الشبابي»

يقرأ المنهج من notes/money-curriculum/منهج-المال-ورائد-الأعمال.md ويُنتج لكل درس:
  out-lessons/<band>/<id>/episode.mp4  — فيديو الشرح مع بطاقات أنشطة وتوقّفات للمعلّم
  out-lessons/<band>/<id>/teacher.md   — ورقة المعلّم: الأهداف، الأنشطة ودقيقة كلٍّ منها، الإشراف، الإجابات، التحدّي المنزلي
  out-lessons/<band>/<id>/meta.json    — بيانات النشر

الاستخدام:
  python3 tools/podcast/make_lesson.py --next        # أول درس لم يُنتَج (الفئة الموحّدة ٨–١٣)
  python3 tools/podcast/make_lesson.py a --list      # خطة دروس الفئة
  python3 tools/podcast/make_lesson.py a u1-l1       # درس واحد
  python3 tools/podcast/make_lesson.py b --next      # أول درس لم يُنتَج في الفئة
"""
import json, os, re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_episode as m

CASES_FILE = HERE.parent.parent / "notes" / "money-curriculum" / "cases.json"
SERIES = json.loads(CASES_FILE.read_text()) if CASES_FILE.exists() else {"cases": []}
CASES = {c["week"]: c for c in SERIES["cases"]}

ROOT = HERE.parent.parent
CURRICULUM = ROOT / "notes" / "money-curriculum" / "منهج-المال-ورائد-الأعمال.md"
OUT_ROOT = Path(os.environ.get("LESSONS_OUT", HERE / "out-lessons"))
AR = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")

BANDS = {
    # الفئة الموحّدة (الافتراضية): فيديو واحد لكل درس لأعمار ٨–١٣
    "m": {
        "ages": "٨–١٣", "series": "رائد الأعمال الصغير",
        "hosts": {
            "salim": {"name": "الكابتن سالم", "voice": "Iapetus", "rgb": (140, 210, 255),
                      "style": "In an energetic, friendly young ship-captain voice, encouraging and clear."},
            "maryam": {"name": "مريم", "voice": "Aoede", "rgb": (255, 205, 120),
                       "style": "In the smart, confident, enthusiastic voice of an eleven-year-old girl."}},
        "cast": "«الكابتن سالم» (قائد «سفينة الأمانة» التي تبحر بين جزر الأعمال، id=salim) و«مريم» (عضوة ذكية في "
                "فريق السفينة في الحادية عشرة، تدوّن في دفترها، id=maryam)",
        "setting": "رحلة «سفينة الأمانة» بين جزر الأعمال (ميناء، سوق جزيرة، خريطة كنز)",
        "level": "جمهور مختلط من ٨ إلى ١٣ سنة: فصحى سهلة واضحة، جمل قصيرة إلى متوسطة، مغامرة وقصص وتحدّيات، "
                 "تُفهم لابن الثامنة ولا تبدو طفولية لابن الثالثة عشرة. اعتمد أساسًا على محتوى فئة ١٠–١٢ في نص الوحدة، "
                 "وبسّط بأمثلة فئة ٧–٩، وأضف لمسة تفكير من فئة ١٣+ في سؤال «تحدّي الكبار» واحد. حسابات بسيطة "
                 "(جمع وطرح، ١٠٪ و٥٠٪، التكلفة والربح) محسوبة خطوة بخطوة. استخدم الأرقام العربية (٠–٩).",
        "activities": "تحدّيات فرق مختلطة الأعمار (الكبير يساعد الصغير)، تمثيل أدوار، فرز بطاقات، جداول ميزانية "
                      "بسيطة، حساب تكلفة وربح، لعبة جزر الأعمال، رسم وتصميم",
        "minutes": "١٠–١٢", "words": (900, 1300), "lead": "salim",
        "image_style": None,
    },
    "a": {
        "ages": "٧–٩", "series": "التاجر الصغير",
        "hosts": {
            "amin": {"name": "العمّ أمين", "voice": "Algenib", "rgb": (255, 214, 120),
                     "style": "In a warm, wise, friendly grandfather-like storyteller voice, clear and calm, for children."},
            "salma": {"name": "سلمى", "voice": "Leda", "rgb": (255, 170, 160),
                      "style": "In the cheerful, curious, energetic voice of an eight-year-old girl."}},
        "cast": "«العمّ أمين» (تاجر حكيم أمين في السوق منذ ثلاثين سنة، id=amin) و«سلمى» (طفلة نشيطة فضولية في الثامنة، id=salma)",
        "setting": "سوق العمّ أمين ودكّانه",
        "level": "فصحى سهلة جدًا، جمل قصيرة جدًا، أمثلة من حياة الطفل (المصروف، الدكّان، الحصّالة، الحلوى)، "
                 "قصص قصيرة ومرح ودفء، وتكرار الفكرة الأساسية. لا أرقام معقّدة (عدّ حتى ٢٠ وجمع بسيط فقط).",
        "activities": "ألعاب حركية، تمثيل أدوار (دكّان الصف)، فرز بطاقات، رسم وتلوين، عدّ عملات",
        "minutes": "٨–١٠", "words": (800, 1100), "lead": "amin",
        "image_style": None,
    },
    "b": {
        "ages": "١٠–١٢", "series": "رائد الأعمال الصغير",
        "hosts": {
            "salim": {"name": "الكابتن سالم", "voice": "Iapetus", "rgb": (140, 210, 255),
                      "style": "In an energetic, friendly young ship-captain voice, encouraging and clear."},
            "maryam": {"name": "مريم", "voice": "Aoede", "rgb": (255, 205, 120),
                       "style": "In the smart, confident, enthusiastic voice of an eleven-year-old girl."}},
        "cast": "«الكابتن سالم» (قائد «سفينة الأمانة» التي تبحر بين جزر الأعمال، id=salim) و«مريم» (عضوة ذكية في "
                "فريق السفينة في الحادية عشرة، تدوّن في دفترها، id=maryam)",
        "setting": "رحلة «سفينة الأمانة» بين جزر الأعمال (ميناء، سوق جزيرة، خريطة كنز)",
        "level": "فصحى سهلة واضحة، جمل متوسطة، مغامرة وتحدّيات. حسابات بسيطة حقيقية (نسب مئوية سهلة مثل ١٠٪ "
                 "و٥٠٪، التكلفة والربح، ميزانية أسبوعية) مع أمثلة محسوبة خطوة بخطوة.",
        "activities": "تحدّيات فرق، جداول ميزانية، حساب تكلفة وربح، خرائط ذهنية، لعبة جزر الأعمال، تصميم إعلان",
        "minutes": "١٠–١٢", "words": (900, 1300), "lead": "salim",
        "image_style": None,
    },
    "c": {
        "ages": "١٣+", "series": "رائد الأعمال الأمين",
        "hosts": {
            "khalid": {"name": "الأستاذ خالد", "voice": "Charon", "rgb": (180, 220, 170),
                       "style": "In a calm, thoughtful, articulate teacher's voice, warm and respectful."},
            "omar": {"name": "عمر", "voice": "Puck", "rgb": (255, 200, 140),
                     "style": "In the curious, lively voice of a fifteen-year-old teenage boy asking smart questions."}},
        "cast": "«الأستاذ خالد» (معلّم اقتصاد يدير «مجلس الشورى الشبابي»، id=khalid) و«عمر» (شابّ في الخامسة عشرة، "
                "يسأل ويناقش ويعترض بأدب، id=omar)",
        "setting": "«مجلس الشورى الشبابي»: قاعة نقاش، سوق حقيقي، مكتب مشروع ناشئ",
        "level": "فصحى معاصرة واضحة تخاطب المراهق باحترام، بلا طفولية. الأحكام مع أدلّتها من نص الوحدة، "
                 "ومفاهيم اقتصادية بأمثلة واقعية وأرقام، ودراسات حالة، وأسئلة نقدية «ماذا تفعل لو…؟».",
        "activities": "نقاش مجلس شورى، دراسة حالة، مناظرة قصيرة، حساب زكاة، نموذج عمل، تحليل إعلان",
        "minutes": "١٢", "words": (1000, 1500), "lead": "khalid",
        "image_style": ("Clean modern flat editorial illustration for a teen educational explainer, refined, "
                        "not childish, muted sophisticated palette, 16:9 composition, set in the modern or traditional Arab / "
                        "Islamic world. STRICT RULES: absolutely no "
                        "people, no human faces or figures, no text, no letters, no numbers, no logos, no crosses "
                        "or idols. Scene: "),
    },
}


def configure(band):
    b = BANDS[band]
    m.HOSTS = b["hosts"]
    m.SHOW = b["series"]
    m.OUTRO_TEXT = "نلقاكم في الدرس القادم"
    if b["image_style"]:
        m.STYLE = b["image_style"]
    return b

# ───────────────────────── خطة الدروس ─────────────────────────

def units():
    """يقسم المنهج إلى وحدات: {n, title, weeks:[...], text}."""
    md = CURRICULUM.read_text()
    tr = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
    plan = {}
    for row in re.finditer(r"^\|\s*(\d+)(?:–(\d+))?\s*\|\s*و(\S+)\s*\|", md, re.M):
        a, b, u = int(row.group(1)), int(row.group(2) or row.group(1)), int(row.group(3).translate(tr))
        plan[u] = list(range(a, b + 1))
    out = []
    for sec in re.split(r"^### الوحدة ", md, flags=re.M)[1:]:
        head, _, body = sec.partition("\n")
        n = int(re.match(r"(\S+?):", head).group(1).translate(tr))
        body = re.split(r"^## ", body, flags=re.M)[0]
        if n == 12:                                   # المشروع الختامي: نصّه في القسم ٥
            body += "\n" + re.search(r"^## ٥\..*?(?=^## ٦\.)", md, re.M | re.S).group(0)
        out.append({"n": n, "title": head.split(":", 1)[1].strip(), "weeks": plan.get(n, [0]), "text": body})
    return out


PLAN_PROMPT = """أنت مصمّم تعليمي. هذه وحدة من منهج «المال وريادة الأعمال» لأبناء أكاديمية إسلامية.
قسّم الوحدة إلى {k} دروس أسبوعية متتابعة للفئة {ages} سنة (استخدم نواتج التعلّم والأنشطة الخاصة بهذه الفئة في الوحدة).
كل درس فيديو شرح نحو {minutes} دقيقة يتخلّله نشاطان أو ثلاثة يشرف عليها المعلّم، من نوع: {activities}.
التزم بمحتوى الوحدة وأهدافها وجلستها المباشرة وأنشطتها.
أعد JSON فقط: {{"lessons": [{{"title": "...", "objectives": ["...","..."], "focus": "ما يغطّيه الدرس من الوحدة بالتفصيل",
"activities": ["اسم نشاط من الوحدة", "..."]}}]}}
"""


def lesson_plan(band):
    b = BANDS[band]
    f = HERE / f"lessons_{band}.json"
    lessons = json.loads(f.read_text()) if f.exists() else []
    done = {l["unit"] for l in lessons}
    for u in units():
        if u["n"] in done:
            continue
        k = len(u["weeks"])
        txt = m.gemini_text(m.TEXT_MODEL, [{"role": "user", "parts": [
            {"text": PLAN_PROMPT.format(k=k, ages=b["ages"], minutes=b["minutes"], activities=b["activities"])},
            {"text": f"الوحدة {u['n']}: {u['title']}\n\n{u['text']}"}]}],
            {"responseMimeType": "application/json", "temperature": 0.4})
        for i, l in enumerate(json.loads(txt)["lessons"][:k]):
            lessons.append({"id": f"u{u['n']}-l{i+1}", "unit": u["n"], "unit_title": u["title"],
                            "week": u["weeks"][i] if i < len(u["weeks"]) else None, **l})
        lessons.sort(key=lambda l: (l["unit"], l["id"]))
        f.write_text(json.dumps(lessons, ensure_ascii=False, indent=1))      # حفظ تدريجي
        print(f"  [{band}] unit {u['n']}: {k} lessons")
    return lessons

# ───────────────────────── سيناريو الدرس ─────────────────────────

LESSON_RULES = """
أنت كاتب فيديوهات تعليمية إسلامية لسلسلة «{series}» للفئة {ages} سنة.
المذيعان: {cast}.
المكان: {setting}.
الفيديو يُعرض في جلسة يديرها معلّم مع مجموعة طلاب (حضوريًا أو أونلاين).

اكتب درس الأسبوع {week}: «{title}» (من الوحدة {unit}: {unit_title}).
أهداف الدرس: {objectives}
ما يغطّيه: {focus}
المصدر الوحيد هو نص الوحدة المرفق (استخدم ما يخصّ الفئة {ages}). لا أرقام أو أحكام أو قصص من خارجه.

القواعد:
- مستوى اللغة والأسلوب: {level}
- شكّل النص تشكيلًا كاملًا صحيحًا.
- الآيات: لا تُكتب داخل كلام المذيعين أبدًا. يمهّد لها {lead_name} ثم سطر مستقل
  {{"s": "quran", "ref": "سورة:آية", "t": "نص الآية كما في المصدر"}} (يُتلى بصوت الحصري). آية أو آيتان فقط من آيات الوحدة.
- الأحاديث: فقط ما ورد في الوحدة، مع ذكر من رواه كما هو مذكور (مثل: رواه البخاري).
- لا تذكر أي حديث موسوم في المصدر بأنه ضعيف أو مختلف في صحته.

هيكل الدرس (مشاهد scenes، بين ١٠ و١٤ مشهدًا):
1. افتتاح: السلام + «بسم الله» + سؤال مشوّق يربط بالدرس.
2. مرساة شرعية: آية/حديث من الوحدة وشرح يناسب الفئة.
3. الشرح: المفهوم بقصة أو موقف في المكان المذكور، مع أسئلة {other_name}.
4. نشاطان أو ثلاثة موزّعة بين الشرح، من نوع: {activities}. كل نشاط مشهد خاص بهذا الشكل:
   {{"activity": {{"title": "اسم النشاط", "minutes": 5-15, "materials": ["..."], "steps": ["خطوة قصيرة", "..."(٣–٥)],
     "teacher": "إرشاد للمعلّم: كيف يدير النشاط ويشرف عليه، وما الذي يلاحظه، وكيف يكيّفه للأونلاين"}},
     "lines": [سطران أو ثلاثة يشرح فيها {lead_name} النشاط، وآخرها بالضبط:
       {{"s":"{lead}","t":"يَا مُعَلِّمَنَا الْكَرِيمَ، أَوْقِفِ الْفِيدْيُو الْآنَ، وَنَلْتَقِي بَعْدَ النَّشَاطِ إِنْ شَاءَ اللهُ."}},
       {{"s":"pause","sec":6}}]}}
   والمشهد التالي للنشاط يبدأ بترحيب بالعودة وسؤال عمّا فعله الطلاب.
{case_block}
5. «سؤال وجواب» سريع: ٣ أسئلة يطرحها {other_name} مع مهلة تفكير، ثم الإجابة.
6. ختام: خلاصة بثلاث نقاط + تقديم «ملفّ القضية الجديدة» (هو التحدّي المنزلي) + دعاء كفّارة المجلس.

المشاهد العادية: {{"image": "وصف إنجليزي لرسمة تناسب المكان والفكرة، بلا بشر ولا كتابة", "lines": [...]}}
السطر: {{"s": "{ids}", "t": "..."}} ولا يتجاوز ٣٥ كلمة. مجموع كلام المذيعين بين {wmin} و{wmax} كلمة.

أعد JSON فقط:
{{"title": "عنوان الدرس", "description": "وصف للأهل من سطرين", "takeaways": ["…","…","…"],
  "quiz": [{{"q": "...", "a": "..."}}], "home_challenge": "...", "teacher_intro": "تهيئة للمعلّم قبل العرض (٣ أسطر)",
  "scenes": [...]}}
"""


def case_block(week):
    """تعليمات مسلسل «ملفّات المحقّق التجاري»: كشف قضية الأسبوع الماضي + مختبر القرار + القضية الجديدة."""
    c, prev = CASES.get(week), CASES.get(week - 1)
    if not c:
        return ""
    out = ["مسلسل «ملفّات المحقّق التجاري» (قصة مستمرّة طوال السنة):"]
    if prev:
        out.append(f"- بعد الافتتاح مباشرة مشهد «كشف قضية الأسبوع الماضي: {prev['title']}» (٣–٥ أسطر): "
                   f"ماذا حدث؟ {prev['reveal']} امدح اختلاف الحلول، وذكّر بأن المهمّ هو الأدلّة وطريقة التفكير، "
                   "لا اختيار أ أو ب أو ج فقط.")
    out.append("- أحد الأنشطة «مختبر القرار»: موقف قصير من الدرس فيه ٣ قرارات (أ، ب، ج)، يصوّت عليها الطلاب "
               "أثناء التوقّف، وبعد العودة يعرض المذيعان نتيجة كل قرار.")
    if "عميل غامض" in c.get("tags", []):
        out.append("- يظهر في الدرس «عميل غامض» بشخصية مميّزة (متردّد أو غاضب أو باحث عن الأرخص أو يريد استرجاع منتج)، "
                   "ويقرّر الطلاب كيف يتعاملون معه بأمانة وذكاء.")
    if "صدمة السوق" in c.get("tags", []):
        out.append("- «بطاقة صدمة السوق»: حدث مفاجئ يغيّر الخطة، ويراجع الطلاب حساباتهم واحتياطيهم.")
    out.append(f"- في الختام يقدّم {{lead_name}} «ملفّ القضية الجديدة: {c['title']}» بإيجاز: {c['story']} "
               "ثم يقول إن الأدلّة والقرارات في ملفّ القضية مع المعلّم، والحلّ في البيت، والكشف في الدرس القادم. "
               "لا تكشف الحلّ.")
    return "\n".join(out)


def make_lesson_script(b, ls, unit_text, d):
    f = d / "script.json"
    if f.exists():
        return json.loads(f.read_text())
    ids = list(b["hosts"]); lead = b["lead"]; other = [i for i in ids if i != lead][0]
    rules = LESSON_RULES.replace("{case_block}", case_block(ls["week"]).replace("{", "{{").replace("}", "}}")
                                  .replace("{{lead_name}}", "{lead_name}"))
    prompt = rules.format(
        series=b["series"], ages=b["ages"], cast=b["cast"], setting=b["setting"], level=b["level"],
        activities=b["activities"], lead=lead, lead_name=b["hosts"][lead]["name"],
        other_name=b["hosts"][other]["name"], ids='" أو "'.join(ids), wmin=b["words"][0], wmax=b["words"][1],
        week=str(ls["week"]).translate(AR), title=ls["title"], unit=str(ls["unit"]).translate(AR),
        unit_title=ls["unit_title"], objectives="؛ ".join(ls["objectives"]), focus=ls["focus"])
    ok_speakers = set(ids) | {"quran", "pause"}
    for attempt in range(5):
        try:
            convo = [{"role": "user", "parts": [{"text": prompt}, {"text": "نص الوحدة:\n" + unit_text}]}]
            txt = m.gemini_text(m.TEXT_MODEL, convo, {"responseMimeType": "application/json", "temperature": 0.7})
            s = json.loads(txt)
            for _ in range(2):   # توسعة النص القصير من مادة الوحدة نفسها
                n = sum(len(l.get("t", "").split()) for sc in s["scenes"] for l in sc.get("lines", [])
                        if l.get("s") in ids)
                if n >= b["words"][0]:
                    break
                print(f"  expanding lesson ({n} words)")
                convo += [{"role": "model", "parts": [{"text": txt}]}, {"role": "user", "parts": [{"text":
                    f"الدرس قصير ({n} كلمة) والمطلوب بين {b['words'][0]} و{b['words'][1]} كلمة لكلام المذيعين. "
                    "أعد كتابة الدرس كاملًا بنفس الشكل (JSON) ونفس القواعد والأنشطة، ووسّع الشرح بأمثلة إضافية "
                    "وحوار أطول وأسئلة تفكير ومراجعة بعد كل نشاط، من مادة الوحدة نفسها فقط."}]}]
                txt = m.gemini_text(m.TEXT_MODEL, convo, {"responseMimeType": "application/json", "temperature": 0.6})
                s = json.loads(txt)
            assert all("lines" in sc for sc in s["scenes"]), "scene without lines"
            lines = [l for sc in s["scenes"] for l in sc["lines"]]
            assert all(l["s"] in ok_speakers for l in lines), "bad speaker"
            for l in lines:
                if l["s"] == "quran":
                    assert m.verify_ayah(l), f"ayah mismatch {l.get('ref')}"
            acts = [sc for sc in s["scenes"] if "activity" in sc]
            assert 2 <= len(acts) <= 3, f"activities={len(acts)}"
            for sc in acts:
                if sc["lines"][-1]["s"] != "pause":
                    sc["lines"].append({"s": "pause", "sec": 6})
            words = sum(len(l["t"].split()) for l in lines if l["s"] in ids)
            assert b["words"][0] - 100 <= words <= b["words"][1] + 400, f"words={words}"
            break
        except Exception as e:
            print("  script retry:", str(e)[:150])
    else:
        raise RuntimeError("تعذّر توليد سيناريو صالح")
    f.write_text(json.dumps(s, ensure_ascii=False, indent=1))
    print(f"  ✓ script: {len(s['scenes'])} scenes, {len(acts)} activities, {words} words")
    return s

# ───────────────────────── ورقة المعلّم ─────────────────────────

def mins_ar(n):
    n = int(n)
    return f"{n} دقائق" if 3 <= n <= 10 else f"{n} دقيقة"


def teacher_sheet(b, ls, s, d):
    t, times = 5.0, []
    for sc in s["scenes"]:
        if "activity" in sc:
            times.append(t)
        for l in sc["lines"]:
            t += l.get("dur", 0) + 0.35
    mmss = lambda x: f"{int(x // 60)}:{int(x % 60):02d}"
    out = [f"# ورقة المعلّم — {b['series']} ({b['ages']}) · الأسبوع {ls['week']}: {s['title']}",
           f"**الوحدة {ls['unit']}:** {ls['unit_title']} · **مدة الفيديو:** {mmss(t + 6)} دقيقة + وقت الأنشطة", "",
           "## شكل الحصّة المقترح", "| المرحلة | الزمن | ماذا يحدث؟ |", "|---|---|---|",
           *[f"| {x['stage']} | {mins_ar(x['minutes']) if x['minutes'].isdigit() else x['minutes'] + ' دقيقة'} | {x['what']} |" for x in SERIES.get("session", [])],
           SERIES.get("session_note", ""), "",
           "## قبل العرض", s.get("teacher_intro", ""), "",
           "## أهداف الدرس", *[f"- {o}" for o in ls["objectives"]], "",
           "## الأنشطة (أوقف الفيديو عند كل نشاط)"]
    for k, (sc, tm) in enumerate(zip([x for x in s["scenes"] if "activity" in x], times), 1):
        a = sc["activity"]
        out += [f"### {k}. {a['title']} — عند الدقيقة {mmss(tm)} · {mins_ar(a.get('minutes', 10))}",
                f"**الأدوات:** {'، '.join(a.get('materials', [])) or '—'}", "",
                *[f"{i}. {st}" for i, st in enumerate(a.get("steps", []), 1)], "",
                f"**إشراف المعلّم:** {a.get('teacher', '')}", ""]
    c, prev = CASES.get(ls["week"]), CASES.get(ls["week"] - 1)
    if prev:
        out += [f"## كشف قضية الأسبوع الماضي: {prev['title']}", prev["reveal"],
                "ناقش الحلول المختلفة: ما الأدلّة التي اعتمد عليها كل طالب؟ وما المعلومة الناقصة؟", ""]
    if c:
        out += [f"## ملفّ القضية الجديدة: {c['title']}" + (f" ({'، '.join(c['tags'])})" if c.get("tags") else ""),
                f"**القصة:** {c['story']}", "", "**الأدلّة:**", *[f"{i}. {e}" for i, e in enumerate(c["evidence"], 1)], "",
                "**القرار:**", *[f"- {'أبج'[i]}) {o}" for i, o in enumerate(c["options"])], "",
                f"**سؤال التفكير العميق:** {c['deep']}", "",
                "> يُكشف الحلّ في بداية الدرس القادم. لا تُعطِ الإجابة، واطلب من الطالب أن يعلّل قراره بالأدلّة.", ""]
        if c.get("mission"):
            out += ["## مهمّة من العالم الحقيقي", c["mission"] + " (تحت إشراف الأهل، ودون مشاركة بيانات شخصية)", ""]
        if c.get("project"):
            out += ["## خطوة «المشروع الذي يكبر معي»", c["project"], ""]
        out += ["## دفتر أخطائي الذكية", *[f"- {q}" for q in SERIES.get("journal", [])], SERIES.get("journal_note", ""), ""]
        stamp = SERIES.get("passport", {}).get(str(ls["unit"]))
        if stamp:
            out += ["## جواز سفر رائد الأعمال",
                    f"ختم هذه الوحدة: «{stamp}»، ويُمنح عند إتمام قضايا الوحدة ومهامّها.", ""]
    out += ["## أسئلة الفهم وإجاباتها", *[f"- **{q['q']}** — {q['a']}" for q in s.get("quiz", [])], "",
            "## التحدّي المنزلي", s.get("home_challenge", ""), "",
            "## خلاصة الدرس", *[f"- {x}" for x in s.get("takeaways", [])]]
    (d / "teacher.md").write_text("\n".join(out))

# ───────────────────────── main ─────────────────────────

def main():
    args = sys.argv[1:]
    if args and args[0] not in BANDS:
        args = ["m"] + args                     # الفئة الموحّدة ٨–١٣ افتراضيًا
    if len(args) < 2:
        sys.exit(__doc__)
    band = args[0]; b = configure(band)
    plan = lesson_plan(band)
    out = OUT_ROOT / band
    if args[1] == "--list":
        for l in plan:
            print(f"{l['id']:8} أسبوع {l['week']:>2} · {l['title']}")
        return
    if args[1] == "--next":
        ls = next((l for l in plan if not (out / l["id"] / "episode.mp4").exists()), None)
        if not ls:
            print("كل الدروس جاهزة ✓"); return
    else:
        ls = next((l for l in plan if l["id"] == args[1]), None) or sys.exit(f"لا يوجد درس {args[1]}")
    u = next(u for u in units() if u["n"] == ls["unit"])
    d = out / ls["id"]; d.mkdir(parents=True, exist_ok=True)
    print(f"▶ [{band}] {ls['id']} — الأسبوع {ls['week']}: {ls['title']}")
    s = make_lesson_script(b, ls, u["text"], d)
    m.make_audio(s, d)
    m.make_images(s, d)
    ep = {"index": ls["week"], "category": "منهج المال", "part": None,
          "subtitle": f"{b['ages']} سنة · الأسبوع {str(ls['week']).translate(AR)} · الوحدة {str(ls['unit']).translate(AR)}"}
    m.make_video(ep, s, d)
    teacher_sheet(b, ls, s, d)
    meta = {"id": ls["id"], "band": band, "title": f"{s['title']} | {b['series']} · الأسبوع {ls['week']}",
            "description": s.get("description", ""), "video": "episode.mp4", "teacher_sheet": "teacher.md"}
    (d / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1))
    print(d)


if __name__ == "__main__":
    main()
