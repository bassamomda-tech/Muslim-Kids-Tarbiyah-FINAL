#!/usr/bin/env python3
"""يولّد شخصيتَي البودكاست مرة واحدة (ثابتة لكل الحلقات):
   characters/<id>_closed.png, _open.png, _blink.png — شفافة الخلفية.
   الأسلوب يطابق mk-avatars.js في الموقع: الرجل بلحية وطاقية، والبنت بحجاب."""
import base64, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import make_episode as m
from PIL import Image
import numpy as np

D = Path(__file__).parent / "characters"; D.mkdir(exist_ok=True)
BASE = ("Flat 2D cartoon character for a children's Islamic podcast, friendly rounded style like a modern kids' "
        "TV show, clean bold outlines, soft cel shading, front three-quarter view, upper body from the waist up, "
        "hands relaxed, mouth gently closed in a warm smile, eyes open. Solid pure chroma green background "
        "(#00FF00) filling the whole image, no shadow on the background, no text, no props. Character: ")
CASTS = {}
CASTS["podcast"] = {
    "yusuf": "a kind young Arab uncle storyteller in his 30s with a neat short dark beard, a white kufi cap, "
             "a light sand-colored thobe and an olive vest, warm brown eyes.",
    "karma": "a cheerful 9-year-old Arab girl wearing a modest teal hijab fully covering her hair and neck, "
             "a long-sleeved soft yellow dress, big curious brown eyes, rosy cheeks.",
}
CASTS["money"] = {
    "amin": "a kind Arab market trader in his late 50s with a neat grey-white beard, a white kufi cap, "
            "a cream thobe with a brown merchant's vest and a small coin pouch at his belt, wise smiling eyes.",
    "salma": "an energetic 8-year-old Arab girl wearing a modest coral-pink hijab fully covering her hair and neck, "
             "a long-sleeved light-blue dress, holding nothing, bright curious eyes, rosy cheeks.",
}
CASTS["money_b"] = {
    "salim": "a friendly young Arab ship captain in his early 30s with a short neat black beard, a navy captain's "
             "cap with a small gold anchor, a white long-sleeved shirt and navy vest, confident kind smile.",
    "maryam": "a smart 11-year-old Arab girl wearing a modest navy-blue hijab fully covering her hair and neck, "
              "a long-sleeved mustard-yellow tunic over loose trousers, a small notebook in one hand, determined eyes.",
}
CASTS["money_c"] = {
    "khalid": "a thoughtful Arab teacher and economist in his 40s with a well-groomed beard with a few grey hairs, "
              "rectangular glasses, a white kufi cap, a smart grey thobe with a dark blazer, calm confident smile.",
    "omar": "a 15-year-old Arab teenage boy with short dark hair and a light first mustache shadow, a white kufi cap, "
            "a casual olive long-sleeved shirt, attentive and curious expression.",
}
# أسلوب أهدأ وأنضج للفئة ١٣+
BASE_TEEN = ("Clean modern flat 2D illustration in a mature educational explainer style (like a quality YouTube "
             "explainer for teenagers), refined proportions, not childish, soft shading, front three-quarter view, "
             "upper body from the waist up, hands relaxed, mouth closed, eyes open. Solid pure chroma green "
             "background (#00FF00) filling the whole image, no shadow on the background, no text, no props. Character: ")
CAST = sys.argv[1] if len(sys.argv) > 1 else "podcast"
if CAST == "money_c":
    BASE = BASE_TEEN
CHARS = CASTS[CAST]
VARIANTS = {
    "open": "Redraw exactly the same character, same pose, same colors, same framing and same green background; "
            "only change: the mouth is open as if speaking a vowel 'aa'.",
    "blink": "Redraw exactly the same character, same pose, same colors, same framing and same green background; "
             "only change: both eyes are closed in a natural blink, mouth closed.",
}

def gen(parts):
    r = m.gemini(m.IMAGE_MODEL, [{"role": "user", "parts": parts}],
                 {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": "3:4"}})
    p = next(x for x in r["candidates"][0]["content"]["parts"] if "inlineData" in x)
    return base64.b64decode(p["inlineData"]["data"])

def key_green(src, dst):
    im = np.asarray(Image.open(src).convert("RGB")).astype(int)
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    green = (g - np.maximum(r, b))
    alpha = np.clip(255 - (green - 40) * 4, 0, 255).astype(np.uint8)   # soft edge
    out = np.dstack([r, np.minimum(g, np.maximum(r, b) + 30), b]).clip(0, 255).astype(np.uint8)  # de-spill
    Image.fromarray(np.dstack([out, alpha]), "RGBA").save(dst)

def face_only(cid):
    """ثبّت الجسد: خذ من كل نسخة منطقة الوجه فقط (حيث الفرق الكثيف في النصف العلوي) فوق الإطار الأساسي."""
    from PIL import ImageFilter
    base = Image.open(D / f"{cid}_closed.png")
    b = np.asarray(base).astype(int)
    for v in ("open", "blink"):
        im = Image.open(D / f"{cid}_{v}.png")
        a = np.asarray(im).astype(int)
        diff = (np.abs(a[..., :3] - b[..., :3]).sum(-1) > 60)
        diff[int(diff.shape[0] * 0.45):] = False                 # الوجه في النصف العلوي
        dimg = Image.fromarray((diff * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(15))
        dimg = dimg.filter(ImageFilter.MinFilter(9))              # أزل النقاط المتفرقة
        box = dimg.getbbox()
        if not box:
            continue
        x0, y0, x1, y1 = box; pad = 20
        mask = Image.new("L", base.size, 0)
        mask.paste(255, (max(0, x0 - pad), max(0, y0 - pad), x1 + pad, y1 + pad))
        mask = mask.filter(ImageFilter.GaussianBlur(8))
        out = base.copy(); out.paste(im, (0, 0), mask)
        out.save(D / f"{cid}_{v}.png")


for cid, desc in CHARS.items():
    raw = D / f"{cid}_closed.raw.png"
    if not raw.exists():
        raw.write_bytes(gen([{"text": BASE + desc}]))
    b64 = base64.b64encode(raw.read_bytes()).decode()
    for v, instr in VARIANTS.items():
        f = D / f"{cid}_{v}.raw.png"
        if not f.exists():
            f.write_bytes(gen([{"inlineData": {"mimeType": "image/png", "data": b64}}, {"text": instr}]))
    for v in ("closed", "open", "blink"):
        key_green(D / f"{cid}_{v}.raw.png", D / f"{cid}_{v}.png")
    face_only(cid)
    print("✓", cid)
