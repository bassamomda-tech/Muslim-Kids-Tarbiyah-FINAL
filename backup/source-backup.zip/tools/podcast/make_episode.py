#!/usr/bin/env python3
"""
بودكاست «حكايات التربية» — توليد حلقة فيديو كاملة آليًا من محتوى الموقع.

الخطوات (كل خطوة تُحفَظ في out/<id>/ فإعادة التشغيل تكمل من حيث توقفت):
  1) script.json  — نص الحوار (Gemini) مبني حصريًا على حكايات الموقع
  2) audio/*.wav  — صوت كل سطر (Google Cloud TTS · Chirp3-HD عربي)
  3) img/*.png    — رسمة لكل مشهد (Gemini Image) بلا وجوه بشرية
  4) episode.mp4  — مونتاج: صور متحركة + صوت + ترجمة عربية + شارة بداية/نهاية
  5) meta.json + thumb.jpg — عنوان ووصف وصورة مصغّرة جاهزة للنشر

الاستخدام:
  python3 tools/podcast/make_episode.py prophets-yunus
  python3 tools/podcast/make_episode.py --next     # أول حلقة لم تُنتَج بعد

المفاتيح: GEMINI_API_KEY و GOOGLE_TTS_API_KEY (يمكن أن يكونا نفس مفتاح Google Cloud).
إن لم يوجدا يُرسَل الطلب بلا مفتاح (بيئات يحقن فيها وسيطٌ المفتاحَ تلقائيًا).
"""
import base64, shutil, json, os, re, subprocess, sys, time, urllib.request, urllib.error, wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
FONTS = HERE / "fonts"
OUT = Path(os.environ.get("PODCAST_OUT", HERE / "out"))
TEXT_MODEL = os.environ.get("PODCAST_TEXT_MODEL", "gemini-3.5-flash")
IMAGE_MODEL = os.environ.get("PODCAST_IMAGE_MODEL", "gemini-3.1-flash-image")
W, H = 1920, 1080
FPS = 25

SHOW = "حكايات التربية"
OUTRO_TEXT = "نلقاكم في الحلقة القادمة"
HOSTS = {
    # المذيع: صوت رجل دافئ — الضيفة: كارما بطلة ركن حفّاظ السنة في الموقع
    "yusuf": {"name": "عمّو يوسف", "voice": "Charon",
              "style": "In a warm, gentle, clear storyteller voice for young children.", "rgb": (255, 214, 120)},
    "karma": {"name": "كارما", "voice": "Leda",
              "style": "In the cheerful, curious, lively voice of a nine-year-old girl.", "rgb": (140, 220, 255)},
}

# ───────────────────────── HTTP helpers ─────────────────────────

def _post(url, body, key_env, tries=5):
    key = os.environ.get(key_env) or os.environ.get("GOOGLE_API_KEY")
    if key:
        url += ("&" if "?" in url else "?") + "key=" + key
    data = json.dumps(body).encode()
    for i in range(tries):
        try:
            req = urllib.request.Request(url, data, {"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=300) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            msg = e.read().decode(errors="ignore")[:500]
            if e.code in (429, 500, 502, 503, 504) and i < tries - 1:
                time.sleep(2 ** (i + 2)); continue
            raise RuntimeError(f"HTTP {e.code}: {msg}")
        except (urllib.error.URLError, TimeoutError):
            if i < tries - 1:
                time.sleep(2 ** (i + 2)); continue
            raise


def gemini(model, contents, config=None, system=None):
    body = {"contents": contents}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    if config:
        body["generationConfig"] = config
    return _post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                 body, "GEMINI_API_KEY")


def gemini_text(model, contents, config=None, tries=4):
    """توليد نص طويل بالبثّ (SSE) — يمنع انقطاع الاتصال في الطلبات الطويلة."""
    body = {"contents": contents, **({"generationConfig": config} if config else {})}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse"
    key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if key:
        url += "&key=" + key
    for i in range(tries):
        try:
            req = urllib.request.Request(url, json.dumps(body).encode(), {"Content-Type": "application/json"})
            out = []
            with urllib.request.urlopen(req, timeout=600) as r:
                for raw in r:
                    line = raw.decode().strip()
                    if not line.startswith("data:"):
                        continue
                    chunk = json.loads(line[5:])
                    for p in chunk.get("candidates", [{}])[0].get("content", {}).get("parts", []):
                        if not p.get("thought"):
                            out.append(p.get("text", ""))
            return "".join(out)
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            print("  text retry:", str(e)[:200])
            if i < tries - 1:
                time.sleep(2 ** (i + 2)); continue
            raise

# ───────────────────────── القرآن: نص عثماني + تلاوة الحصري ─────────────────────────

QCACHE = HERE / "cache" / "quran"
_DIAC = re.compile(r"[\u0610-\u061A\u064B-\u065F\u06D6-\u06ED\u0640]")


def _norm(t):
    t = t.replace("\u0670", "ا")                     # الألف الخنجرية
    t = _DIAC.sub("", t)
    for a, b in (("ٱ", "ا"), ("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ى", "ي"), ("ة", "ه"), ("ؤ", "و"), ("ئ", "ي")):
        t = t.replace(a, b)
    return re.sub(r"[^\u0621-\u064A]", "", t)


def _surahs():
    f = QCACHE / "surahs.json"
    if not f.exists():
        QCACHE.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen("https://api.alquran.cloud/v1/surah", timeout=60) as r:
            f.write_text(json.dumps({_norm(x["name"]).replace("سوره", ""): x["number"] for x in json.load(r)["data"]},
                                    ensure_ascii=False))
    return json.loads(f.read_text())


def norm_ref(ref):
    """يقبل «18:19» أو «الكهف:١٩» أو «سورة الكهف: 19» ويُعيد «18:19»."""
    ref = str(ref).translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")).replace("،", ":").strip()
    m_ = re.match(r"^(.*?)[\s:]+(\d+)\s*$", ref)
    if not m_:
        raise ValueError(ref)
    s_, a_ = m_.group(1).strip(), int(m_.group(2))
    if not s_.isdigit():
        key = _norm(s_).replace("سوره", "")
        names = _surahs()
        s_ = names.get(key) or next((v for k, v in names.items() if key and (key in k or k in key)), None)
        if not s_:
            raise ValueError(ref)
    return f"{int(s_)}:{a_}"


def ayah(ref):
    """يُعيد {'text','surah','num'} للآية «سورة:آية» من مصحف عثماني (alquran.cloud) مع تخزين محلي."""
    ref = norm_ref(ref)
    QCACHE.mkdir(parents=True, exist_ok=True)
    f = QCACHE / (ref.replace(":", "_") + ".json")
    if not f.exists():
        with urllib.request.urlopen(f"https://api.alquran.cloud/v1/ayah/{ref}/quran-uthmani", timeout=60) as r:
            d = json.load(r)["data"]
        f.write_text(json.dumps({"text": d["text"], "surah": d["surah"]["name"],
                                 "num": d["numberInSurah"], "s": d["surah"]["number"]}, ensure_ascii=False))
    return json.loads(f.read_text())


def verify_ayah(line):
    """الآية المذكورة يجب أن تطابق موضعها فعلًا (مطابقة تقريبية بعد حذف التشكيل)."""
    import difflib
    try:
        line["ref"] = norm_ref(line["ref"])
        a = ayah(line["ref"])
    except Exception:
        return False
    q, full = _norm(line["t"]), _norm(a["text"])
    if not q:
        return False
    m = difflib.SequenceMatcher(None, q, full, autojunk=False)
    return sum(b.size for b in m.get_matching_blocks()) / len(q) >= 0.8


def husary(ref, path):
    """تلاوة الشيخ محمود خليل الحصري (مرتّل) من everyayah.com → wav أحادي 24kHz."""
    if path.exists():
        return
    a = ayah(ref)
    mp3 = QCACHE / f"husary_{a['s']:03d}{a['num']:03d}.mp3"
    if not mp3.exists():
        with urllib.request.urlopen(f"https://everyayah.com/data/Husary_128kbps/{a['s']:03d}{a['num']:03d}.mp3",
                                    timeout=120) as r:
            mp3.write_bytes(r.read())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(mp3), "-ac", "1", "-ar", "24000",
                    "-af", "volume=1.4", str(path)], check=True)

# ───────────────────────── 1) السيناريو ─────────────────────────

SCRIPT_RULES = """
أنت كاتب بودكاست إسلامي للأطفال (٤–٩ سنوات) اسمه «{show}».
المذيعان: «عمّو يوسف» (راوٍ حنون، id=yusuf) و«كارما» (طفلة ذكية فضولية في التاسعة، id=karma).

اكتب حلقة صوتية مدتها نحو ١٠ دقائق (بين ١٣٠٠ و١٥٠٠ كلمة إجمالًا) عن: «{title}»{part}.
المصدر الوحيد للمعلومات هو حكايات الموقع المرفقة بصيغة JSON. التزم بها التزامًا تامًا:
- لا تُضِف أحداثًا أو أسماء أو أرقامًا أو تفاصيل غير موجودة في المصدر.
- لا تستشهد بأي آية أو حديث إلا إذا ورد نصُّه في المصدر، وانقله حرفيًا كما هو.
- الآيات القرآنية لا تُكتب أبدًا داخل كلام المذيعين. إذا ورد في المصدر نصُّ آية (أو دعاءٌ هو جزء من آية)،
  فليمهّد لها عمّو يوسف بجملة مثل «لِنَسْتَمِعْ مَعًا إِلَى قَوْلِ اللهِ تَعَالَى:» ثم ضع سطرًا مستقلًا
  {{"s": "quran", "ref": "رقم_السورة:رقم_الآية", "t": "نص الآية كما ورد في المصدر"}} — يُتلى بصوت الشيخ
  محمود خليل الحصري. لا تستعمل إلا آية تعرف موضعها يقينًا، ولا أكثر من ٣ آيات في الحلقة.
- اذكر ﷺ بعد اسم النبي محمد، و«عليه السلام» بعد الأنبياء، و«رضي الله عنه/عنها» بعد الصحابة.
- عربية فصحى سهلة جدًا، جمل قصيرة، دفء ومرح بلا سخرية، بلا موسيقى أو مؤثرات مذكورة.
- شكّل النص تشكيلًا كاملًا صحيحًا في كل كلمة ليُنطَق صحيحًا، وتجنّب الكلمات الغريبة أو صعبة النطق على الأطفال.

هيكل الحلقة:
1. ترحيب قصير: «السلام عليكم يا أصدقاء» + تقديم موضوع الحلقة بسؤال مشوّق.
2. لكل حكاية من حكايات المصدر بالترتيب: يحكيها عمّو يوسف، وتقاطعه كارما بأسئلة طفولية
   وتعليقات قصيرة، ثم يستخلصان العبرة (moral) ويردّدان الدعاء (dua) إن وُجد.
3. فقرة «سؤال الحلقة»: كارما تطرح سؤالًا من أسئلة المصدر، وتترك للأطفال لحظة للتفكير
   («فكّروا معي…»)، ثم تأتي الإجابة.
4. ختام: تلخيص في ٣ نقاط عملية يطبّقها الطفل اليوم + دعاء + «نلقاكم في الحلقة القادمة».

قسّم الحلقة إلى مشاهد (scenes) بين ١٠ و١٤ مشهدًا. لكل مشهد:
- "image": وصف بالإنجليزية لرسمة واحدة تناسب المشهد. ممنوع منعًا باتًا رسم الأنبياء أو الصحابة
  أو أي وجه بشري؛ صوّر المكان والطبيعة والأشياء والحيوانات والرموز فقط (مثل: سفينة في بحر هائج،
  صحراء عند الفجر، مصباح، كتاب مفتوح). إن وجد في المصدر حقل prompt فاستفد منه.
- "lines": أسطر الحوار، كل سطر {{"s": "yusuf" أو "karma", "t": "النص"}}، والسطر لا يتجاوز ٣٥ كلمة.

أعِد JSON فقط بهذا الشكل:
{{"title": "عنوان جذّاب للحلقة", "description": "وصف من سطرين للأهل",
  "takeaways": ["…","…","…"], "scenes": [{{"image": "...", "lines": [{{"s":"yusuf","t":"..."}}]}}]}}
"""


def make_script(ep, d):
    f = d / "script.json"
    if f.exists():
        return json.loads(f.read_text())
    part = f" (الجزء {ep['part']['n']} من {ep['part']['of']})" if ep.get("part") else ""
    prompt = SCRIPT_RULES.format(show=SHOW, title=ep["title"], part=part)
    src = json.dumps({"category": ep["category"], "title": ep["title"], "tag": ep["tag"],
                      "stories": ep["stories"]}, ensure_ascii=False)
    def check(s):
        words = sum(len(l["t"].split()) for sc in s["scenes"] for l in sc["lines"] if l["s"] != "quran")
        assert all(l["s"] in HOSTS or l["s"] == "quran" for sc in s["scenes"] for l in sc["lines"]), "bad speaker"
        for sc in s["scenes"]:
            for l in sc["lines"]:
                if l["s"] == "quran":
                    assert verify_ayah(l), f"ayah mismatch {l.get('ref')}"
        return words

    s = None
    for attempt in range(5):
        try:
            convo = [{"role": "user", "parts": [{"text": prompt}, {"text": "المصدر:\n" + src}]}]
            txt = gemini_text(TEXT_MODEL, convo, {"responseMimeType": "application/json", "temperature": 0.8})
            s = json.loads(txt); words = check(s)
            # الحكايات القصيرة تُنتج نصًا قصيرًا: نطلب توسعته (حتى مرتين) دون أي معلومة من خارج المصدر
            for _ in range(2):
                if words >= 1150:
                    break
                print(f"  expanding script ({words} words)")
                convo += [{"role": "model", "parts": [{"text": txt}]},
                          {"role": "user", "parts": [{"text":
                           f"الحلقة قصيرة ({words} كلمة) والمطلوب بين ١٣٠٠ و١٥٠٠ كلمة. أعد كتابة الحلقة كاملة "
                           "بنفس الشكل (JSON) وبنفس القواعد، ووسّعها بإطالة الحوار حول تفاصيل المصدر نفسه: "
                           "أسئلة كارما ومشاعر الشخصيات ووصف الأماكن المذكورة، وتكرار العبرة والدعاء مع الأطفال، "
                           "وأسئلة تفكير قصيرة، ولعبة «صحّ أم خطأ» من أحداث المصدر في الختام. "
                           "لا تضف أي حدث أو معلومة غير موجودة في المصدر."}]}]
                txt = gemini_text(TEXT_MODEL, convo, {"responseMimeType": "application/json", "temperature": 0.7})
                s = json.loads(txt); words = check(s)
            assert 1000 <= words <= 2300, f"words={words}"
            break
        except Exception as e:
            print("  script retry:", e)
    else:
        raise RuntimeError("تعذّر توليد سيناريو صالح")
    f.write_text(json.dumps(s, ensure_ascii=False, indent=1))
    print(f"  ✓ script: {len(s['scenes'])} scenes, {words} words")
    return s

# ───────────────────────── 2) الصوت ─────────────────────────

TTS_MODEL = os.environ.get("PODCAST_TTS_MODEL", "gemini-3.1-flash-tts-preview")
CHECK_MODEL = os.environ.get("PODCAST_CHECK_MODEL", "gemini-3.5-flash")


def _pcm_to_wav(raw, mime, path):
    if raw[:4] == b"RIFF":
        path.write_bytes(raw); return
    rate = int(re.search(r"rate=(\d+)", mime).group(1)) if "rate=" in mime else 24000
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(raw)


def tts(text, speaker, path, hint=""):
    """صوت Gemini: يلتزم بالتشكيل أدق بكثير من أصوات Cloud TTS العادية."""
    h = HOSTS[speaker]
    prompt = f"{h['style']}{hint} Read aloud in Fusha Arabic, exactly as voweled:\n{text}"
    r = gemini(TTS_MODEL, [{"role": "user", "parts": [{"text": prompt}]}],
               {"responseModalities": ["AUDIO"],
                "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": h["voice"]}}}})
    parts = (r.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
    part = next((x["inlineData"] for x in parts if "inlineData" in x), None)
    if not part:
        raise RuntimeError(f"no audio ({(r.get('candidates') or [{}])[0].get('finishReason')})")
    _pcm_to_wav(base64.b64decode(part["data"]), part.get("mimeType", ""), path)


def tts_safe(text, speaker, path, hint=""):
    """Gemini أولًا (حتى ٤ محاولات)، ثم صوت Cloud TTS احتياطيًا حتى لا تتوقف الحلقة."""
    for i in range(4):
        try:
            return tts(text, speaker, path, hint)
        except Exception as e:
            print(f"  tts retry {i+1}:", str(e)[:120]); time.sleep(3 * (i + 1))
    fallback = "ar-XA-Chirp3-HD-" + HOSTS[speaker]["voice"]
    r = _post("https://texttospeech.googleapis.com/v1/text:synthesize", {
        "input": {"text": text}, "voice": {"languageCode": "ar-XA", "name": fallback},
        "audioConfig": {"audioEncoding": "LINEAR16", "sampleRateHertz": 24000, "speakingRate": 0.95},
    }, "GOOGLE_TTS_API_KEY")
    path.write_bytes(base64.b64decode(r["audioContent"]))


def check_pronunciation(text, path):
    """مدقّق آلي: يفرّغ الصوت كما نُطق فعلًا ويقارنه بالنص المشكول. يُعيد قائمة الكلمات الخاطئة."""
    b = base64.b64encode(path.read_bytes()).decode()
    r = gemini(CHECK_MODEL, [{"role": "user", "parts": [
        {"inlineData": {"mimeType": "audio/wav", "data": b}},
        {"text": "You are a strict Arabic (Fusha) pronunciation checker for a children's podcast.\n"
                 "Expected text (with tashkeel):\n" + text + "\n\n"
                 "Listen carefully. Any extra speech not in the expected text is an error. Report every word that was mispronounced (wrong vowels, wrong letters, "
                 "skipped or added words, wrong shadda/tanween that changes the word). Ignore pause-form "
                 "endings (waqf) at the end of a sentence and tiny accent differences. "
                 'Return JSON: {"ok": true|false, "wrong": [{"expected": "...", "heard": "..."}]}'}]}],
        {"responseMimeType": "application/json", "temperature": 0})
    txt = "".join(p.get("text", "") for p in r["candidates"][0]["content"]["parts"] if not p.get("thought"))
    res = json.loads(txt)
    return [] if res.get("ok") else res.get("wrong", []) or [{"expected": "?", "heard": "?"}]


def voice_line(text, speaker, path, tries=3):
    if path.exists():
        return None
    hint, best = "", None
    for k in range(tries):
        tmp = path.with_suffix(f".try{k}.wav")
        tts_safe(text, speaker, tmp, hint)
        wrong = check_pronunciation(text, tmp)
        # حارس المدة: سطر أطول بكثير من المتوقع يعني كلامًا زائدًا
        if wav_dur(tmp) > 0.75 * len(text.split()) + 4:
            wrong = wrong + [{"expected": "(لا شيء)", "heard": "كلام زائد/مدة طويلة"}]
        if best is None or len(wrong) < best[1]:
            best = (tmp, len(wrong), wrong)
        if not wrong:
            break
        hint = (" Pay special attention to pronouncing these words exactly as voweled: "
                + "، ".join(w.get("expected", "") for w in wrong if w.get("expected") != "(لا شيء)") + ".")
    best[0].rename(path)
    for f in path.parent.glob(path.stem + ".try*.wav"):
        f.unlink()
    return best[2] or None


def silence_wav(sec, path):
    """توقّف مقصود (وقت النشاط) — يظهر فيه شعار «أوقف الفيديو» دون كلام."""
    if not path.exists():
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                        f"anullsrc=r=24000:cl=mono:d={sec}", str(path)], check=True)


def wav_dur(p):
    with wave.open(str(p)) as w:
        return w.getnframes() / w.getframerate()


def make_audio(script, d):
    from concurrent.futures import ThreadPoolExecutor
    a = d / "audio"; a.mkdir(exist_ok=True)
    jobs = [(i, j, l, a / f"{i:02d}_{j:02d}.wav")
            for i, sc in enumerate(script["scenes"]) for j, l in enumerate(sc["lines"])]
    with ThreadPoolExecutor(4) as ex:
        results = list(ex.map(lambda x: husary(x[2]["ref"], x[3]) if x[2]["s"] == "quran"
                              else silence_wav(x[2].get("sec", 6), x[3]) if x[2]["s"] == "pause"
                              else voice_line(x[2]["t"], x[2]["s"], x[3]), jobs))
    report = [{"line": f"{i:02d}_{j:02d}", "text": l["t"], "wrong": w}
              for (i, j, l, _), w in zip(jobs, results) if w]
    for i, j, l, p in jobs:
        l["dur"] = wav_dur(p)
    log = d / "pronunciation-report.json"
    if report or not log.exists():
        log.write_text(json.dumps(report, ensure_ascii=False, indent=1))
    print(f"  ✓ audio: {len(jobs)} lines · {len(report)} still flagged after retries (see {log.name})")

# ───────────────────────── 3) الصور ─────────────────────────

STYLE = ("Warm, gentle children's picture-book illustration, soft watercolor and gouache textures, "
         "rounded shapes, cozy pastel palette with golden light, 16:9 wide composition, calm and joyful. "
         "Setting: traditional Arab / Middle Eastern Islamic world (souqs, mud-brick and stone houses, arches, "
         "palm trees, deserts, Arabian coasts); never European-style houses or towns. "
         "STRICT RULES: absolutely no people, no human faces or figures, no silhouettes of prophets, "
         "no text, no letters, no logos, no crosses or idols in focus. Scene: ")


def image_problems(path):
    """مدقّق الصور: يرفض أي كتابة (بأي لغة) أو بشر أو وجوه بشرية أو رموز دينية لغير المسلمين."""
    b = base64.b64encode(path.read_bytes()).decode()
    r = gemini(CHECK_MODEL, [{"role": "user", "parts": [
        {"inlineData": {"mimeType": "image/png", "data": b}},
        {"text": "Inspect this children's illustration strictly. Return JSON "
                 '{"text": true|false, "people": true|false, "religious_symbols": true|false, "note": "..."} where '
                 "text = any letters, words, numbers, calligraphy, pseudo-writing, inscriptions on coins, or signage in any language; people = any human, human face, "
                 "silhouette or human-like figure; religious_symbols = crosses, idols in focus, temples, statues."}]}],
        {"responseMimeType": "application/json", "temperature": 0})
    txt = "".join(x.get("text", "") for x in r["candidates"][0]["content"]["parts"] if not x.get("thought"))
    res = json.loads(txt)
    return [k for k in ("text", "people", "religious_symbols") if res.get(k)]


def activity_card(path, a):
    """بطاقة النشاط: عنوان، مدة، خطوات مرقّمة، أدوات، وشعار «أوقف الفيديو» للمعلّم."""
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGB", (W, H), (250, 244, 228))
    dr = ImageDraw.Draw(im)
    kw = dict(direction="rtl", language="ar")
    def F(size, wt="Bold"):
        f = ImageFont.truetype(str(FONTS / "Cairo.ttf"), size); f.set_variation_by_name(wt); return f
    ar = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")
    # شريط علوي
    dr.rectangle((0, 0, W, 120), fill=(31, 110, 82))
    dr.rounded_rectangle((W - 108, 34, W - 92, 86), 4, fill="white")      # رمز الإيقاف المؤقت مرسوم
    dr.rounded_rectangle((W - 82, 34, W - 66, 86), 4, fill="white")
    dr.text((W - 130, 60), "أوقِف الفيديو · وقت النشاط", font=F(52), fill="white", anchor="rm", **kw)
    dr.text((70, 60), ("المدة: " + (lambda n: f"{n} دقائق" if 3 <= n <= 10 else f"{n} دقيقة")(int(a.get('minutes', 10)))).translate(ar), font=F(44, "SemiBold"),
            fill=(255, 230, 160), anchor="lm", **kw)
    x0, x1 = 380, W - 380
    y = 175
    dr.text(((x0 + x1) / 2, y), a.get("title", "نشاط"), font=F(60), fill=(31, 70, 55), anchor="mm", **kw)
    y += 80
    # يتّسع النص فوق منطقة الترجمة (تبدأ قرب ٦٩٠ بكسل): نصغّر الخط حتى تتّسع الخطوات والأدوات
    LIMIT = 680
    steps = [f"{str(k).translate(ar)}. {st}".translate(ar) for k, st in enumerate(a.get("steps", [])[:5], 1)]
    mt = ("الأدوات: " + "، ".join(a["materials"])) if a.get("materials") else ""
    for size in (40, 36, 32, 29, 26, 24):
        fs, fm, lh = F(size, "SemiBold"), F(max(22, size - 6), "Medium"), int(size * 1.4)
        wrapped = [_wrap(dr, st, fs, x1 - x0, kw) for st in steps]
        mlines = _wrap(dr, mt, fm, x1 - x0, kw)[:2] if mt else []
        need = sum(len(w) * lh + 6 for w in wrapped) + len(mlines) * int(lh * 0.9)
        if y + need <= LIMIT:
            break
    for w in wrapped:
        for ln in w:
            dr.text((x1, y), ln, font=fs, fill=(40, 40, 40), anchor="ra", **kw); y += lh
        y += 6
    for ln in mlines:
        dr.text((x1, y + 4), ln, font=fm, fill=(150, 100, 20), anchor="ra", **kw); y += int(lh * 0.9)
    im.save(path)


def make_images(script, d):
    g = d / "img"; g.mkdir(exist_ok=True)
    for i, sc in enumerate(script["scenes"]):
        p = g / f"{i:02d}.png"
        if "activity" in sc:
            activity_card(p, sc["activity"]); continue
        if p.exists() and not p.with_suffix(".bad").exists():
            continue
        extra = ""
        for attempt in range(4):
            try:
                r = gemini(IMAGE_MODEL, [{"role": "user", "parts": [{"text": STYLE + sc["image"] + extra}]}],
                           {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": "16:9"}})
                parts = r["candidates"][0]["content"]["parts"]
                img = next(x["inlineData"]["data"] for x in parts if "inlineData" in x)
                p.write_bytes(base64.b64decode(img))
                bad = image_problems(p)
                if not bad:
                    p.with_suffix(".bad").unlink(missing_ok=True); break
                print(f"  image {i} rejected: {bad}")
                p.with_suffix(".bad").write_text(",".join(bad))
                extra = (" ABSOLUTELY NO " + ", NO ".join({"text": "letters, words, calligraphy, inscriptions or signs anywhere (no names on "
                         "boats or buildings, no writing on coins)", "people": "people or figures", "religious_symbols":
                         "crosses, idols or statues"}[k] for k in bad) + ".")
            except Exception as e:
                print(f"  image {i} retry:", str(e)[:200]); time.sleep(5)
        else:
            # لا نُبقي صورة مرفوضة أبدًا: نستبدلها بأقرب صورة سليمة سابقة
            ok = [g / f"{j:02d}.png" for j in range(i - 1, -1, -1)
                  if "activity" not in script["scenes"][j] and not (g / f"{j:02d}.bad").exists()
                  and (g / f"{j:02d}.png").exists()]
            if ok:
                shutil.copy(ok[0], p); p.with_suffix(".bad").unlink(missing_ok=True)
                print(f"  ⚠ image {i}: still flagged → reused {ok[0].name}")
            else:
                print(f"  ⚠ image {i}: kept last attempt, still flagged")
    print(f"  ✓ images: {len(script['scenes'])}")

# ───────────────────────── 4) المونتاج ─────────────────────────

def card(path, title, subtitle, bg=None):
    """بطاقة نصية (بداية/نهاية/صورة مصغّرة) بخط عربي مُشكَّل صحيحًا عبر Pillow+raqm."""
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
    if bg and Path(bg).exists():
        im = Image.open(bg).convert("RGB").resize((W, H)).filter(ImageFilter.GaussianBlur(6))
        im = Image.blend(im, Image.new("RGB", (W, H), (20, 40, 60)), 0.45)
    else:
        im = Image.new("RGB", (W, H), (24, 58, 82))
    dr = ImageDraw.Draw(im)
    big = ImageFont.truetype(str(FONTS / "Amiri-Bold.ttf"), 120)
    mid = ImageFont.truetype(str(FONTS / "Cairo.ttf"), 64); mid.set_variation_by_name("Bold")
    small = ImageFont.truetype(str(FONTS / "Cairo.ttf"), 44); small.set_variation_by_name("SemiBold")
    kw = dict(direction="rtl", language="ar", anchor="mm")
    dr.text((W / 2, 200), SHOW, font=small, fill=(255, 214, 120), **kw)
    # لفّ العنوان إن طال
    words, lines, cur = title.split(), [], ""
    for w_ in words:
        t = (cur + " " + w_).strip()
        if dr.textlength(t, font=big, direction="rtl", language="ar") > W - 240 and cur:
            lines.append(cur); cur = w_
        else:
            cur = t
    lines.append(cur)
    y0 = H / 2 - (len(lines) - 1) * 80
    for k, ln in enumerate(lines):
        dr.text((W / 2, y0 + k * 160), ln, font=big, fill="white", stroke_width=4,
                stroke_fill=(10, 30, 45), **kw)
    if subtitle:
        dr.text((W / 2, H - 170), subtitle, font=mid, fill=(255, 240, 200), stroke_width=3,
                stroke_fill=(10, 30, 45), **kw)
    im.save(path, quality=92)


SUB_X0, SUB_X1 = 400, W - 400          # الترجمة بين الشخصيتين


def _wrap(dr, text, font, width, kw):
    lines, cur = [], ""
    for w_ in text.split():
        t = (cur + " " + w_).strip()
        if dr.textlength(t, font=font, **kw) > width and cur:
            lines.append(cur); cur = w_
        else:
            cur = t
    return lines + [cur]


def sub_png(path, speaker, line):
    """إطار ترجمة شفاف بحجم الفيديو. المذيعان: الاسم بلونه + النص. القرآن: رسم عثماني بإطار ذهبي."""
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if line:
        dr = ImageDraw.Draw(im)
        kw = dict(direction="rtl", language="ar")
        inner = SUB_X1 - SUB_X0 - 70
        if speaker == "quran":
            a = ayah(line["ref"])
            f = ImageFont.truetype(str(FONTS / "AmiriQuran.ttf"), 54)
            lab = ImageFont.truetype(str(FONTS / "Cairo.ttf"), 30); lab.set_variation_by_name("SemiBold")
            lines = _wrap(dr, a["text"] + " \u06DD" + f"{a['num']}".translate(str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")),
                          f, inner, kw)
            lh = 104; box_h = lh * len(lines) + 100; y0 = max(40, H - 50 - box_h)
            dr.rounded_rectangle((SUB_X0, y0, SUB_X1, H - 50), 30, fill=(28, 22, 10, 215),
                                 outline=(224, 178, 90), width=4)
            dr.text((W / 2, y0 + 38), f"{a['surah']} · بصوت الشيخ محمود خليل الحصري", font=lab,
                    fill=(224, 178, 90), anchor="mm", **kw)
            for k, ln in enumerate(lines):
                dr.text((W / 2, y0 + 80 + k * lh + lh / 2), ln, font=f, fill=(255, 246, 225), anchor="mm", **kw)
        else:
            f = ImageFont.truetype(str(FONTS / "Cairo.ttf"), 46); f.set_variation_by_name("Bold")
            name = HOSTS[speaker]["name"] + ":"
            lines = _wrap(dr, f"{name} {line['t']}", f, inner, kw)
            lh = 76; box_h = lh * len(lines) + 36; y0 = H - 50 - box_h
            dr.rounded_rectangle((SUB_X0, y0, SUB_X1, H - 50), 26, fill=(10, 25, 40, 180))
            for k, ln in enumerate(lines):
                y = y0 + 18 + k * lh + lh / 2
                if k == 0:  # لوّن اسم المتحدث في أول السطر (يمينًا)
                    rest = ln[len(name):].strip()
                    wn = dr.textlength(name, font=f, **kw); gap = 16
                    wr = dr.textlength(rest, font=f, **kw) if rest else 0
                    xr = W / 2 + (wn + gap + wr) / 2
                    dr.text((xr, y), name, font=f, fill=HOSTS[speaker]["rgb"], anchor="rm", **kw)
                    if rest:
                        dr.text((xr - wn - gap, y), rest, font=f, fill="white", anchor="rm", **kw)
                else:
                    dr.text((W / 2, y), ln, font=f, fill="white", anchor="mm", **kw)
    im.save(path)

# ───────────────────────── الشخصيتان (2D) ─────────────────────────

CHAR_DIR = HERE / "characters"
CHAR_H = 470
# المذيع الأول يمينًا (بداية السطر العربي) والثاني يسارًا
CHAR_POS = lambda cid: "right" if cid == list(HOSTS)[0] else "left"
STEP = 0.08                                        # دقة حركة الفم (ثانية)


def _envelope(wav_path):
    import numpy as np
    with wave.open(str(wav_path)) as w:
        a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(float); sr = w.getframerate()
    n = max(1, int(len(a) / (sr * STEP)))
    rms = np.array([np.sqrt(np.mean(a[int(i*sr*STEP):int((i+1)*sr*STEP)] ** 2) + 1e-9) for i in range(n)])
    return rms / (np.percentile(rms, 90) + 1e-9)


def char_frame(state, cache):
    """state = ((yusuf_mouth, yusuf_eyes), (karma_mouth, karma_eyes)) → إطار شفاف كامل الحجم (مخزّن)."""
    from PIL import Image
    f = cache / ("c_" + "_".join(f"{m}{e}" for m, e in state) + ".png")
    if f.exists():
        return f
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    for cid, (mouth, eyes) in zip(list(HOSTS), state):
        v = "blink" if eyes == "c" else ("open" if mouth == "o" else "closed")
        sp = Image.open(CHAR_DIR / f"{cid}_{v}.png")
        sp = sp.crop(sp.getbbox())
        sp = sp.resize((round(sp.width * CHAR_H / sp.height), CHAR_H))
        lift = 6 if mouth == "o" else 0                       # ارتفاع خفيف أثناء الكلام
        x = W - sp.width - 30 if CHAR_POS(cid) == "right" else 30
        im.alpha_composite(sp, (x, H - CHAR_H - lift + 10))
    im.save(f)
    return f


def char_track(events, total, tmp):
    """يبني مسار الشخصيتين: الفم يتبع شدة صوت المتكلم، والعيون ترمش كل ٢٫٥–٥ ثوانٍ."""
    import random
    cache = tmp / "chars"; cache.mkdir(exist_ok=True)
    n = int(total / STEP) + 1
    mouth = {c: ["c"] * n for c in HOSTS}
    for a, b, spk, line in events:
        if spk not in HOSTS:
            continue
        env = _envelope(line["wav"])
        k0 = int(a / STEP)
        for i, v in enumerate(env):
            if k0 + i < n:
                # افتح الفم مع المقاطع العالية، وأغلقه كل ثالث خطوة ليبدو الكلام طبيعيًا
                mouth[spk][k0 + i] = "o" if v > 0.35 and (k0 + i) % 3 != 2 else "c"
    rng = random.Random(7)
    eyes = {}
    for c in HOSTS:
        e = ["o"] * n; t = rng.uniform(1, 3)
        while t < total:
            for k in range(int(t / STEP), min(n, int(t / STEP) + 2)):
                e[k] = "c"
            t += rng.uniform(2.5, 5.0)
        eyes[c] = e
    timeline, prev, run = [], None, 0
    for k in range(n):
        st = tuple((mouth[c][k], eyes[c][k]) for c in HOSTS)
        if st == prev:
            run += 1
        else:
            if prev is not None:
                timeline.append((char_frame(prev, cache), run * STEP))
            prev, run = st, 1
    timeline.append((char_frame(prev, cache), run * STEP + 2))
    (tmp / "chars.txt").write_text("".join(f"file '{f}'\nduration {du:.3f}\n" for f, du in timeline)
                                   + f"file '{timeline[-1][0]}'\n")
    return tmp / "chars.txt"


def make_video(ep, script, d):
    out = d / "episode.mp4"
    if out.exists():
        return out
    tmp = d / "build"; tmp.mkdir(exist_ok=True)
    GAP, INTRO, OUTRO = 0.35, 5.0, 6.0
    sub = ep.get("subtitle") or f"الحلقة {ep['index']} · {ep['category']}" + (f" · الجزء {ep['part']['n']}" if ep.get("part") else "")
    card(tmp / "intro.png", script["title"], sub, d / "img" / "00.png")
    card(tmp / "outro.png", OUTRO_TEXT, "إن شاء الله · " + SHOW, d / "img" / f"{len(script['scenes'])-1:02d}.png")
    card(d / "thumb.jpg", script["title"], sub, d / "img" / "00.png")

    # 4أ) شريط الصوت الكامل + توقيت الترجمة
    silence = lambda s: f"anullsrc=r=24000:cl=mono:d={s}"
    seq, events, t = [], [], INTRO
    lst = tmp / "audio.txt"
    sil_gap = tmp / "gap.wav"; sil_in = tmp / "in.wav"; sil_out = tmp / "out.wav"
    for p, s in ((sil_gap, GAP), (sil_in, INTRO), (sil_out, OUTRO)):
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", silence(s), str(p)], check=True)
    seq.append(sil_in)
    scene_durs = []
    for i, sc in enumerate(script["scenes"]):
        st = t
        for j, l in enumerate(sc["lines"]):
            seq.append(d / "audio" / f"{i:02d}_{j:02d}.wav")
            l["wav"] = d / "audio" / f"{i:02d}_{j:02d}.wav"
            events.append((t, t + l["dur"], l["s"], l))
            t += l["dur"]; seq.append(sil_gap); t += GAP
        scene_durs.append(t - st)
    seq.append(sil_out)
    lst.write_text("".join(f"file '{p}'\n" for p in seq))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                    "-c:a", "pcm_s16le", str(tmp / "voice.wav")], check=True)

    # 4ب) الترجمة: صور شفافة يرسمها Pillow+raqm (تشكيل عربي صحيح)، ثم مسار واحد يُركَّب فوق الفيديو
    sd = tmp / "subs"; sd.mkdir(exist_ok=True)
    blank = sd / "blank.png"; sub_png(blank, None, None)
    timeline, cur = [], 0.0
    for k, (a, b, s, line) in enumerate(events):
        if a > cur:
            timeline.append((blank, a - cur))
        f = sd / f"{k:03d}.png"; sub_png(f, s, None if s == "pause" else line)
        timeline.append((f, b - a)); cur = b
    timeline.append((blank, OUTRO + 1))
    (tmp / "subs.txt").write_text("".join(f"file '{f}'\nduration {du:.3f}\n" for f, du in timeline)
                                  + f"file '{blank}'\n")

    chars = char_track(events, t + OUTRO, tmp)

    # 4ج) مقاطع الصور بحركة كين برنز خفيفة
    clips = [(tmp / "intro.png", INTRO, False)]
    clips += [(d / "img" / f"{i:02d}.png", dur, True) for i, dur in enumerate(scene_durs)]
    clips += [(tmp / "outro.png", OUTRO, False)]
    parts = []
    for k, (img, dur, move) in enumerate([] if (tmp / "silent.mp4").exists() else clips):
        frames = max(1, round(dur * FPS))
        p = tmp / f"clip{k:02d}.mp4"
        if move:
            zin = k % 2 == 0
            z = f"'min(1+0.08*on/{frames},1.08)'" if zin else f"'max(1.08-0.08*on/{frames},1.0)'"
            vf = (f"scale={W*2}:{H*2}:force_original_aspect_ratio=increase,crop={W*2}:{H*2},"
                  f"zoompan=z={z}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s={W}x{H}:fps={FPS}")
        else:
            vf = f"scale={W}:{H},fps={FPS}"
        vf += ",format=yuv420p,fade=t=in:st=0:d=0.5"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-framerate", str(FPS), "-i", str(img),
                        "-t", f"{frames / FPS:.3f}", "-vf", vf, "-c:v", "libx264", "-preset", "veryfast",
                        "-crf", "20", "-r", str(FPS), str(p)], check=True)
        parts.append(p)
    if parts:
      (tmp / "video.txt").write_text("".join(f"file '{p}'\n" for p in parts))
      subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(tmp / "video.txt"),
                      "-c", "copy", str(tmp / "silent.mp4")], check=True)

    # 4د) الدمج النهائي + حرق الترجمة
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(tmp / "silent.mp4"), "-i", str(tmp / "voice.wav"),
                    "-f", "concat", "-safe", "0", "-i", str(tmp / "subs.txt"),
                    "-f", "concat", "-safe", "0", "-i", str(chars),
                    "-filter_complex", f"[2:v]fps={FPS},format=rgba[s];[3:v]fps={FPS},format=rgba[c];"
                                       f"[0:v][c]overlay=0:0:eof_action=pass[vc];"
                                       f"[vc][s]overlay=0:0:eof_action=pass,format=yuv420p[v]",
                    "-map", "[v]", "-map", "1:a",
                    "-c:v", "libx264", "-preset", "medium", "-tune", "stillimage", "-crf", "24", "-c:a", "aac", "-b:a", "160k",
                    "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-shortest", "-movflags", "+faststart", str(out)],
                   check=True)
    print(f"  ✓ video: {t + OUTRO:.0f}s → {out}")
    return out

# ───────────────────────── 5) بيانات النشر ─────────────────────────

def make_meta(ep, script, d):
    pts = "\n".join(f"• {x}" for x in script.get("takeaways", []))
    desc = (f"{script.get('description','')}\n\n"
            f"ماذا نتعلّم في هذه الحلقة؟\n{pts}\n\n"
            f"الحلقة مبنيّة على حكايات «{ep['title']}» في منصة تربية الطفل المسلم.\n"
            f"بودكاست «{SHOW}» للأطفال من ٤ إلى ٩ سنوات · بدون موسيقى.\n"
            f"#قصص_للأطفال #تربية_إسلامية #{SHOW.replace(' ', '_')}")
    meta = {"id": ep["id"], "index": ep["index"], "title": f"{script['title']} | {SHOW} {ep['index']}",
            "description": desc, "tags": ["قصص أطفال", "قصص إسلامية", "تربية", ep["category"], ep["title"]],
            "video": "episode.mp4", "thumbnail": "thumb.jpg"}
    (d / "meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1))
    return meta

# ───────────────────────── main ─────────────────────────

def main():
    cat = json.loads((HERE / "catalog.json").read_text())
    for i, e in enumerate(cat, 1):
        e["index"] = i
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    if args[0] == "--next":
        ep = next((e for e in cat if not (OUT / e["id"] / "episode.mp4").exists()), None)
        if not ep:
            print("كل الحلقات جاهزة ✓"); return
    else:
        ep = next((e for e in cat if e["id"] == args[0]), None) or sys.exit(f"لا توجد حلقة بالمعرّف {args[0]}")
    d = OUT / ep["id"]; d.mkdir(parents=True, exist_ok=True)
    print(f"▶ الحلقة {ep['index']}: {ep['id']} — {ep['title']}")
    script = make_script(ep, d)
    make_audio(script, d)
    make_images(script, d)
    make_video(ep, script, d)
    make_meta(ep, script, d)
    print(d)


if __name__ == "__main__":
    main()
