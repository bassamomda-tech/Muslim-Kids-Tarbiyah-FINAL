/* tools/podcast/extract.js
   يقرأ بيانات قصص الصغار من corners/stories/* ويحوّلها إلى catalog.json:
   حلقة واحدة لكل «رحلة» (نبيّ / صحابي / محطة سيرة / عبادة / عقيدة). */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = path.resolve(__dirname, '../..');
const DIR = path.join(ROOT, 'corners/stories');
const CATS = [
  { dir:'prophets-little',   key:'PROPHET_LITTLE',    journeys:'PROPHET_JOURNEYS',    name:'قصص الأنبياء' },
  { dir:'seerah-little',     key:'SEERAH_LITTLE',     journeys:'SEERAH_JOURNEYS',     name:'السيرة النبوية' },
  { dir:'companions-little', key:'COMPANIONS_LITTLE', journeys:'COMPANIONS_JOURNEYS', name:'الصحابة الكرام' },
  { dir:'ibada-little',      key:'IBADA_LITTLE',      journeys:'IBADA_JOURNEYS',      name:'العبادات' },
  { dir:'minaret-little',    key:'MINARET_LITTLE',    journeys:'MINARET_JOURNEYS',    name:'العقيدة' },
];
const ctx = { window:{} }; vm.createContext(ctx);
for (const c of CATS) {
  const d = path.join(DIR, c.dir);
  for (const f of fs.readdirSync(d).filter(f => f.endsWith('.js')).sort())
    vm.runInContext(fs.readFileSync(path.join(d, f), 'utf8'), ctx, { filename:f });
}
const episodes = [];
for (const c of CATS) {
  const order = (ctx.window[c.journeys] || []).map(j => j.id);
  const all = ctx.window[c.key] || {};
  const ids = [...order.filter(id => all[id]), ...Object.keys(all).filter(id => !order.includes(id))];
  for (const id of ids) {
    const j = all[id];
    if (!j || !Array.isArray(j.stories) || !j.stories.length) continue;
    const stories = j.stories.map(s => ({
        title: s.title, tag: s.tag || '', moral: s.moral || '', dua: s.dua || '',
        question: s.act ? { q: s.act.q, answer: (s.act.opts || []).find(o => o.ok)?.t || '' } : null,
        pages: (s.pages || []).map(p => ({ text: p.text, prompt: p.prompt || '' })),
      }));
    // حلقة ≈ ١٠ دقائق ⇐ ٣–٥ حكايات؛ الرحلات الطويلة تُقسَم إلى أجزاء متساوية
    const parts = Math.ceil(stories.length / 5), size = Math.ceil(stories.length / parts);
    for (let k = 0; k < parts; k++) episodes.push({
      id: `${c.dir.replace('-little','')}-${id}` + (parts > 1 ? `-${k+1}` : ''),
      category: c.name, title: j.title, tag: j.tag || '',
      part: parts > 1 ? { n: k+1, of: parts } : null,
      stories: stories.slice(k*size, (k+1)*size),
    });
  }
}
const out = path.join(__dirname, 'catalog.json');
fs.writeFileSync(out, JSON.stringify(episodes, null, 1));
console.log(`${episodes.length} episodes → ${path.relative(ROOT, out)}`);
for (const e of episodes) console.log(' ', e.id, '·', e.stories.length, 'stories ·', e.stories.reduce((n,s)=>n+s.pages.length,0), 'pages');
