#!/usr/bin/env python3
"""
فيديو حلقة من مسلسلات «صانع المهارات» (نسخة واحدة لعمر واحد) من نصّ البودكاست المعتمد نفسه.

لا يكتب سيناريو جديدًا: يأخذ سطور البودكاست المراجَعة في notes/<series>/lessons/epNN.json كما هي
(المذيعان + آية بصوت الحصري + وقفتا النشاط)، ويقسمها إلى مشاهد، ويرسم لكل مشهد صورة، ويضع عند كل وقفة
بطاقة النشاط من class_activities (خطوات وأدوات ومدة) ليوقف المعلّم الفيديو ويدير النشاط.
ثم يبني الفيديو بمحرّك make_episode (صوت Gemini مع مدقّق النطق، شخصيتان متحرّكتان، ترجمة مشكولة).

الاستخدام:
  SERIES_DIR=money-curriculum python3 tools/podcast/make_series_video.py 6
الناتج: tools/podcast/out-series/<series>/epNN/{episode.mp4, thumb.jpg, teacher.md, script.json}
"""
import json, os, re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_episode as m

ROOT = HERE.parent.parent
SDIR = os.environ.get("SERIES_DIR", "money-curriculum")
NOTES = ROOT / "notes" / SDIR
SERIES = json.loads((NOTES / "series30.json").read_text())
OUT = Path(os.environ.get("SERIES_VIDEO_OUT", HERE / "out-series")) / SDIR
AR = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")
RGB = [(140, 210, 255), (255, 205, 120)]


def hosts():
    hs = SERIES["podcast"]["hosts"]
    return {k: {"name": v["name"], "voice": v["voice"],
                "style": v["style"], "rgb": RGB[i % 2]} for i, (k, v) in enumerate(hs.items())}


def split_scenes(L):
    """مشاهد من سطور البودكاست: مشهد نشاط = آخر سطرين قبل كل وقفة + الوقفة، والباقي مشاهد من ٣–٥ أسطر."""
    lines = [dict(x) for x in L["podcast"]["lines"]]
    acts = L.get("class_activities", [])
    pauses = [i for i, l in enumerate(lines) if l["s"] == "pause"]
    marks = {}
    prev = -1
    for k, p in enumerate(pauses):
        st = prev + 1 if p - prev <= 5 else p - 2   # بداية مشهد النشاط k (يضمّ سطر العودة إن كان قريبًا)
        marks[st] = k; prev = p
    scenes, cur, i = [], [], 0
    while i < len(lines):
        if i in marks:
            if cur: scenes.append({"lines": cur}); cur = []
            k = marks[i]; p = pauses[k]
            body = []
            for l in lines[i:p + 1]:
                body.append({"s": "pause", "sec": 6} if l["s"] == "pause" else l)
            a = acts[k] if k < len(acts) else {"title": lines[p].get("label", "نشاط")}
            scenes.append({"activity": {x: a.get(x) for x in ("title", "minutes", "materials", "steps", "teacher") if a.get(x)},
                           "lines": body})
            i = p + 1; continue
        l = lines[i]
        if l["s"] == "quran":
            a = m.ayah(l["ref"]); l["t"] = a["text"]
        cur.append(l)
        nxt = i + 1
        # نقطة قطع طبيعية: بعد ٤ أسطر (ولا نفصل الآية عمّا قبلها وبعدها مباشرة)
        if len(cur) >= 4 and l["s"] != "quran" and (nxt >= len(lines) or lines[nxt]["s"] != "quran") and nxt not in marks:
            scenes.append({"lines": cur}); cur = []
        i += 1
    if cur: scenes.append({"lines": cur})
    return scenes


def image_prompts(L, scenes):
    need = [k for k, sc in enumerate(scenes) if "activity" not in sc]
    txt = "\n\n".join(f"SCENE {k}:\n" + "\n".join(l.get("t", "")[:300] for l in scenes[k]["lines"]) for k in need)
    setting = SERIES.get("setting") or "the series' world"
    prompt = ("You design illustrations for a children's Arabic educational video (ages 8-13). "
              f"Series: {SERIES['title']}. Episode: {L['title']}. For each scene below, write ONE short English "
              "description (max 30 words) of a single illustration that fits what is being discussed: objects, places, "
              "animals, nature, ships, markets, coins, notebooks, jars, etc. STRICT: no people or human figures at all "
              "(show objects instead of characters), no text/letters/numbers/writing anywhere, Arab/Islamic-world setting. "
              'Return JSON {"prompts": {"<scene number>": "..."}}.\n\n' + txt)
    r = m.gemini_text(m.TEXT_MODEL, [{"role": "user", "parts": [{"text": prompt}]}],
                      {"responseMimeType": "application/json", "temperature": 0.5})
    pr = json.loads(r)["prompts"]
    for k in need:
        scenes[k]["image"] = pr.get(str(k)) or "a cozy wooden ship deck at sea with a treasure map and golden coins"


def teacher_sheet(n, L, s, d):
    t, times = 5.0, []
    for sc in s["scenes"]:
        if "activity" in sc: times.append(t)
        for l in sc["lines"]: t += l.get("dur", 0) + 0.35
    mmss = lambda x: f"{int(x // 60)}:{int(x % 60):02d}"
    ages = SERIES.get("ages", "")
    out = [f"# ورقة المعلّم — {SERIES['title']} · الحلقة {n}: {L['title']}",
           f"**العمر:** {ages} سنة · **مدة الفيديو:** {mmss(t + 6)} دقيقة + وقت الأنشطة", "",
           "## قبل العرض", L.get("hook", ""), "",
           "## أهداف الحلقة", *[f"- {o}" for o in L.get("objectives", [])], "",
           "## الأنشطة (أوقف الفيديو عند كل بطاقة نشاط)"]
    acts = [sc for sc in s["scenes"] if "activity" in sc]
    for k, (sc, tm) in enumerate(zip(acts, times), 1):
        a = sc["activity"]
        out += [f"### {k}. {a['title']} — عند الدقيقة {mmss(tm)} · {a.get('minutes', 10)} دقيقة",
                f"**الأدوات:** {'، '.join(a.get('materials', [])) or '—'}", "",
                *[f"{i}. {st}" for i, st in enumerate(a.get("steps", []), 1)], "",
                f"**إشراف المعلّم:** {a.get('teacher', '')}", ""]
    for a in L.get("class_activities", [])[len(acts):]:
        out += [f"### نشاط إضافي: {a['title']} · {a.get('minutes', 10)} دقيقة",
                *[f"{i}. {st}" for i, st in enumerate(a.get("steps", []), 1)], ""]
    c = L.get("case") or {}
    if c:
        out += [f"## ملفّ القضية: {c.get('title', '')}", c.get("story", ""), "", "**الأدلّة:**",
                *[f"{i}. {e}" for i, e in enumerate(c.get("evidence", []), 1)], "", "**القرار:**",
                *[f"- {'أبجد'[i]}) {o}" for i, o in enumerate(c.get("options", []))], "",
                f"**سؤال التفكير العميق:** {c.get('deep', '')}", "",
                "> يُكشف الحلّ في بداية الحلقة القادمة. لا تُعطِ الإجابة، واطلب من الطالب أن يعلّل قراره بالأدلّة.", ""]
    out += ["## أسئلة الفهم وإجاباتها",
            *[f"- **{q['q']}** — {q['o'][q['a']]}" + (f" ({q['why']})" if q.get("why") else "") for q in L.get("quiz", [])], ""]
    h = L.get("home") or {}
    if h:
        out += [f"## نشاط البيت: {h.get('title', '')}", h.get("goal", ""), *[f"{i}. {st}" for i, st in enumerate(h.get("steps", []), 1)],
                f"> {h.get('parent', '')}", ""]
    out += ["## خلاصة الحلقة", *[f"- {x}" for x in L.get("summary", [])]]
    (d / "teacher.md").write_text("\n".join(out))


def main():
    n = int(sys.argv[1])
    L = json.loads((NOTES / "lessons" / f"ep{n:02d}.json").read_text())
    d = OUT / f"ep{n:02d}"; d.mkdir(parents=True, exist_ok=True)
    m.HOSTS = hosts(); m.SHOW = SERIES["title"].split(":")[0]; m.OUTRO_TEXT = "نلقاكم في الحلقة القادمة"
    f = d / "script.json"
    if f.exists():
        s = json.loads(f.read_text())
    else:
        scenes = split_scenes(L); image_prompts(L, scenes)
        s = {"title": L["title"], "scenes": scenes}
        f.write_text(json.dumps(s, ensure_ascii=False, indent=1))
    print(f"▶ {SERIES['title']} · الحلقة {n}: {L['title']} — {len(s['scenes'])} مشاهد")
    m.make_audio(s, d)
    m.make_images(s, d)
    ep = {"index": n, "category": SERIES["title"], "part": None,
          "subtitle": f"الحلقة {str(n).translate(AR)} · {SERIES.get('ages', '').translate(AR)} سنة"}
    m.make_video(ep, s, d)
    teacher_sheet(n, L, s, d)
    print(d)


if __name__ == "__main__":
    main()
