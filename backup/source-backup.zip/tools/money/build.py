#!/usr/bin/env python3
"""
مولّد مواد مسلسل «رائد الأعمال الصغير» (٣٠ حلقة) — الجزء غير المرئي:
  لكل حلقة من notes/money-curriculum/lessons/epNN.json يُنتج:
    out/epNN/درس-NN.pdf      الدرس المكتوب (A4، للطالب والمعلّم)
    out/epNN/درس-NN.pptx     عرض الحصّة (16:9)
  ومرة واحدة للموقع:
    corners/skills/data/money-series.js   بيانات النشاط التفاعلي في «كوكب الإبداع»

الاستخدام:
  python3 tools/money/build.py            # كل الحلقات الموجودة
  python3 tools/money/build.py 1 2 3      # حلقات محدّدة
  python3 tools/money/build.py --site     # بيانات الموقع فقط
"""
import html, io, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
NOTES = ROOT / "notes" / __import__("os").environ.get("SERIES_DIR", "money-curriculum")
LESSONS = NOTES / "lessons"
OUT = Path(__import__("os").environ.get("MONEY_OUT", ROOT / "tools" / "money" / "out"))
FONTS = ROOT / "tools" / "podcast" / "fonts"
SITE = "https://tarbiyahkids.uk"
sys.path.insert(0, str(ROOT / "tools" / "podcast"))

SERIES = json.loads((NOTES / "series30.json").read_text())
SITE_CFG = SERIES["site"]
ONLINE_URL = SITE + "/corners/skills/" + SITE_CFG["page"] + "?ep={n}"
AGES = SERIES.get("ages", "8–13")
LB = {"case": "ملفّ القضية", "reveal": "كشف قضية الحلقة الماضية", "reveal_short": "كشف القضية", "pick": "قرارك", "options": "القرار",
      "note": "يُكشف الحلّ في بداية الحلقة القادمة. المهمّ: أدلّتك وطريقة تفكيرك."}
LB.update(SERIES.get("labels", {}))
_BOOK = None


def book():
    """كتاب «ما لا يسع…» من ملفّات ساحة المسابقات (للسلاسل التي فيها series.book)."""
    global _BOOK
    if _BOOK is None:
        import subprocess
        _BOOK = json.loads(subprocess.run(["node", str(Path(__file__).with_name("book.js"))], capture_output=True,
                                          text=True, check=True).stdout)
    return _BOOK


def book_qa(L):
    B = book()
    return [dict(B["qa"][str(i)], id=i) for i in L.get("qa", [])]


def episode_verses(n, L):
    """أبيات الحلقة من notes/<series>/texts/<id>.json حسب "text": [{"id","from","to"}]."""
    out = []
    for t in (L.get("text") or episode_meta(n).get("text") or []):
        d = json.loads((NOTES / SERIES.get("texts_dir", "texts") / f"{t['id']}.json").read_text())
        vv = d.get("verses_vocalized_proposed") or d["verses"]
        for k in range(t["from"], t["to"] + 1):
            v = vv[k - 1]
            out.append({"title": d["title"], "author": d.get("author", ""), "n": k,
                        "v": v if isinstance(v, list) else [v], "proposed": bool(d.get("verses_vocalized_proposed"))})
    return out


def book_dyk(L):
    return [book()["dyk"][i]["ar"] for i in L.get("dyk", [])]
AR = str.maketrans("0123456789%", "٠١٢٣٤٥٦٧٨٩٪")
ABJ = "أبجدهـوز"
NAVY, GOLD, CREAM, GREEN, INK = "22325A", "E7B84A", "FBF6EA", "1F6E52", "2B2B2B"


def A(x):
    return str(x).translate(AR)


def load(n):
    return json.loads((LESSONS / f"ep{n:02d}.json").read_text())


def episode_meta(n):
    return next(e for e in SERIES["episodes"] if e["n"] == n)


def season_of(n):
    return next(s for s in SERIES["seasons"] if s["episodes"][0] <= n <= s["episodes"][1])


def prev_reveal(n):
    p = LESSONS / f"ep{n - 1:02d}.json"
    if n > 1 and p.exists():
        c = json.loads(p.read_text()).get("case")
        return c and {"title": c["title"], "reveal": c["reveal"]}
    return None


BASMALA = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"


def ayah_text(ref):
    """نص الآية من المصحف العثماني؛ ويُحذف ما يسبق الآية الأولى من البسملة (غير الفاتحة)."""
    import make_episode as m
    rng = re.fullmatch(r"(\d+):(\d+)-(\d+)", ref)
    if rng:   # نطاق آيات «سورة:من-إلى»: تُضمّ الآيات مع أرقامها
        s, a1, a2 = map(int, rng.groups())
        parts = [ayah_text(f"{s}:{k}") for k in range(a1, a2 + 1)]
        text = " ".join(f"{p['text']} ({A(p['num'])})" for p in parts[:-1]) + " " + parts[-1]["text"]
        return {**parts[0], "text": text, "num": f"{a1}–{a2}"}
    a = dict(m.ayah(ref))
    w = a["text"].split()
    if a["num"] == 1 and a["s"] not in (1, 9) and len(w) > 4 and w[0].startswith("بِسْمِ"):
        a["text"] = " ".join(w[4:])
    return a


def strip(h):
    return re.sub(r"<[^>]+>", "", h)


def qr_png(url):
    import qrcode
    img = qrcode.make(url, box_size=8, border=1)
    b = io.BytesIO(); img.save(b, format="PNG"); return b.getvalue()

# ───────────────────────── PDF (HTML → Chromium) ─────────────────────────

CSS = """
@font-face{font-family:Cairo;src:url('file://%(F)s/Cairo.ttf')}
@font-face{font-family:AmiriQuran;src:url('file://%(F)s/AmiriQuran.ttf')}
@font-face{font-family:Amiri;src:url('file://%(F)s/Amiri-Bold.ttf')}
@page{size:A4;margin:14mm 13mm 16mm}
*{box-sizing:border-box}
body{font-family:Cairo;direction:rtl;color:#2b2b2b;font-size:11.5pt;line-height:1.75;margin:0}
.hd{background:linear-gradient(135deg,#22325a,#2f4f86);color:#fff;border-radius:16px;padding:16px 20px;display:flex;gap:16px;align-items:center}
.hd .num{flex:0 0 74px;height:74px;border-radius:50%;background:#e7b84a;color:#22325a;display:grid;place-items:center;font-weight:900;font-size:30pt;line-height:1}
.hd .ser{font-size:10pt;opacity:.85}
.hd h1{margin:2px 0 0;font-size:19pt;line-height:1.4}
.meta{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 4px}
.chip{background:#f3ead6;border-radius:99px;padding:1px 10px;font-size:9.5pt;font-weight:700}
h2{color:#22325a;font-size:14.5pt;margin:16px 0 6px;border-bottom:3px solid #e7b84a;display:inline-block;padding-bottom:1px}
.box{border-radius:14px;padding:10px 14px;margin:10px 0;break-inside:avoid}
.goal{background:#eef4fb;border:1.5px solid #bcd2ec}
.hook{background:#fff7e0;border:1.5px dashed #e7b84a;font-weight:700}
.board{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}
.board span{background:#22325a;color:#fff;border-radius:10px;padding:2px 12px;font-size:10pt;font-weight:700}
.quran{background:#fbf6ea;border:2px solid #c9a04a;text-align:center}
.quran .ay{font-family:AmiriQuran;font-size:17pt;line-height:2.3;color:#1a2b4a}
.quran .src{font-size:9.5pt;color:#7a5a20}
table{width:100%;border-collapse:collapse;font-size:10.5pt}
td,th{border:1px solid #e2d6bc;padding:4px 8px;text-align:right;vertical-align:top}
th{background:#f3ead6}
.act{background:#eaf6f0;border:1.5px solid #9cd0b8}
.act h3,.case h3,.home h3,.online h3{margin:0 0 4px;font-size:12.5pt}
.act .min{float:left;background:#1f6e52;color:#fff;border-radius:99px;padding:0 10px;font-size:9.5pt}
.case{background:#fff;border:2px solid #22325a;position:relative}
.case .tag{position:absolute;top:-11px;right:14px;background:#22325a;color:#e7b84a;border-radius:6px;padding:0 10px;font-size:9.5pt;font-weight:800}
.home{background:#fdf0ea;border:1.5px solid #f0b9a0}
.online{background:#f1ecfb;border:1.5px solid #c8b6ef;display:flex;gap:14px;align-items:center}
.online img{width:92px;height:92px}
.teacher{font-size:9.5pt;color:#555;background:#f6f6f6;border-radius:8px;padding:4px 8px;margin-top:6px}
ol,ul{margin:4px 0;padding-inline-start:22px}
ol{list-style-type:arabic-indic}
h2{break-after:avoid}
table,tr{break-inside:avoid}
.case,.online,.home,.act,.quran{break-inside:avoid;page-break-inside:avoid}
.quiz li{margin-bottom:4px}
.opts{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:10.5pt;color:#444}
.key{font-size:9pt;color:#666;border-top:1px dashed #bbb;margin-top:10px;padding-top:4px}
.reveal{background:#f4f0ff;border-right:5px solid #7a5ad0}
.ft{font-size:8.5pt;color:#888;text-align:center;margin-top:14px}
.dyk{background:#fff4d6;border:1.5px solid #f0c860}
.vt{border:2px solid #c9a04a;background:#fbf6ea;font-family:Amiri;font-size:15pt}.vt td{border:0;padding:4px 10px;text-align:center}.vt td.vn{font-family:Cairo;font-size:9pt;color:#7a5a20;width:24px}
.qa{background:#fff;border:1.5px solid #cfd9ea;break-inside:avoid}
.qq{font-weight:800;color:#22325a}.qn{display:inline-block;min-width:26px;text-align:center;background:#e7b84a;color:#22325a;border-radius:99px;margin-left:6px;font-size:9.5pt}
.qa-a{margin-top:3px}.qs{font-size:8.5pt;color:#999;text-align:left}.bk{font-size:9.5pt;color:#777;margin:-4px 0 6px}
"""


def pdf_html(n, L):
    e, s = episode_meta(n), season_of(n)
    goals = SERIES["goals"]
    esc = lambda x: html.escape(str(x))
    h = [f"<html><head><meta charset='utf-8'><style>{CSS.replace('%(F)s', str(FONTS))}</style></head><body>"]
    h.append(f"<div class='hd'><div class='num'>{A(n)}</div><div><div class='ser'>{esc(SERIES['title'])} · "
             f"{esc(s['title'])} · الأعمار {A(AGES)}</div><h1>{esc(L['title'])}</h1></div></div>")
    h.append("<div class='meta'>" + "".join(f"<span class='chip'>🎯 {esc(goals[g])}</span>" for g in L["goals"]) + "</div>")
    h.append("<div class='box goal'><b>أهداف الدرس</b><ol>" + "".join(f"<li>{esc(o)}</li>" for o in L["objectives"]) + "</ol></div>")
    pr = prev_reveal(n)
    if pr:
        h.append(f"<div class='box reveal'><b>🔍 {LB['reveal']}: {esc(pr['title'])}</b><br>{esc(A(pr['reveal']))}</div>")
    h.append(f"<div class='box hook'>🤔 {esc(A(L['hook']))}</div>")
    vs = episode_verses(n, L)
    if vs:
        h.append("<h2>📜 أبيات الحلقة</h2>")
        cur = None
        for v in vs:
            if v["title"] != cur:
                cur = v["title"]
                h.append(f"<div class='bk'>من «{esc(cur)}» — {esc(v['author'])}</div><table class='vt'>")
            row = "".join(f"<td>{esc(x)}</td>" for x in v["v"])
            h.append(f"<tr><td class='vn'>{A(v['n'])}</td>{row}</tr>")
            nxt = vs[vs.index(v) + 1]["title"] if vs.index(v) + 1 < len(vs) else None
            if nxt != cur:
                h.append("</table>")
        if any(v["proposed"] for v in vs):
            h.append("<div class='teacher'>ضبط الحركات في هذا النصّ مقترح، ويُراجَع قبل الحفظ.</div>")
    for sec in L["sections"]:
        h.append(f"<h2>{esc(sec['h'])}</h2>")
        h += [f"<p>{A(p)}</p>" for p in sec["p"]]
        if sec.get("board"):
            h.append("<div class='board'>" + "".join(f"<span>{esc(A(b))}</span>" for b in sec["board"]) + "</div>")
    for f in book_dyk(L):
        h.append(f"<div class='box dyk'><b>💡 هل تعلم؟</b> {esc(f)}</div>")
    qa = book_qa(L)
    if qa:
        h.append(f"<h2>📚 أسئلة الكتاب وأجوبته</h2><div class='bk'>من كتاب «{esc(SERIES['book']['title'])}»</div>")
        for q in qa:
            ans = esc(q["answer"]).replace("\n", "<br>")
            h.append(f"<div class='box qa'><div class='qq'><span class='qn'>{A(q['id'])}</span> {esc(q['q'])}</div><div class='qa-a'>{ans}</div>"
                     f"<div class='qs'>{esc(q.get('src', ''))}</div></div>")
    isl = L.get("islam")
    if isl:
        h.append("<h2>🌙 من نور الوحي</h2>")
        if isl.get("intro"):
            h.append(f"<p>{A(isl['intro'])}</p>")
        if isl.get("ayah"):
            a = ayah_text(isl["ayah"])
            h.append(f"<div class='box quran'><div class='ay'>﴿{esc(a['text'])}﴾</div>"
                     f"<div class='src'>{esc(a['surah'])}: {A(a['num'])}</div></div>")
        if isl.get("hadith"):
            hd = isl["hadith"]
            h.append(f"<div class='box quran'><div style='font-family:Amiri;font-size:14pt'>«{esc(hd['text'])}»</div>"
                     f"<div class='src'>{esc(hd['source'])}</div></div>")
        h.append(f"<p>{A(isl['text'])}</p>")
    if L.get("vocab"):
        h.append("<h2>📖 كلمات الدرس</h2><table><tr><th>الكلمة</th><th>معناها</th></tr>" +
                 "".join(f"<tr><td><b>{esc(w)}</b></td><td>{esc(A(d))}</td></tr>" for w, d in L["vocab"]) + "</table>")
    h.append("<h2>🧩 أنشطة الحصّة</h2>")
    for k, a in enumerate(L["class_activities"], 1):
        h.append(f"<div class='box act'><span class='min'>{A(a['minutes'])} دقيقة</span><h3>النشاط {A(k)}: {esc(a['title'])}</h3>"
                 + (f"<div><b>الأدوات:</b> {esc('، '.join(a['materials']))}</div>" if a.get("materials") else "")
                 + "<ol>" + "".join(f"<li>{esc(A(x))}</li>" for x in a["steps"]) + "</ol>"
                 + f"<div class='teacher'>👩‍🏫 للمعلّم: {esc(a.get('teacher', ''))}</div></div>")
    h.append("<h2>✅ خلاصة الدرس</h2><ul>" + "".join(f"<li>{esc(A(x))}</li>" for x in L["summary"]) + "</ul>")
    c = L["case"]
    h.append(f"<div class='box case'><span class='tag'>🕵️ {LB['case']} · الحلقة {A(n)}</span><h3 style='margin-top:6px'>{esc(A(c['title']))}</h3>"
             f"<p>{esc(A(c['story']))}</p><b>الأدلّة:</b><ol>" + "".join(f"<li>{esc(A(x))}</li>" for x in c["evidence"]) + "</ol>"
             f"<b>{LB['pick']}:</b><ul style='list-style:none;padding:0'>" +
             "".join(f"<li>☐ {ABJ[i]}) {esc(A(o))}</li>" for i, o in enumerate(c["options"])) + "</ul>"
             f"<b>سؤال التفكير العميق:</b> {esc(A(c['deep']))}"
             "<p style='margin:6px 0 0'><b>دليلي الذي اعتمدتُ عليه:</b> ..........................................................................</p>"
             f"<div class='teacher'>{LB['note']}</div></div>")
    hm = L["home"]
    h.append(f"<div class='box home'><h3>🏠 نشاط البيت: {esc(hm['title'])}</h3><div>{esc(A(hm['goal']))}</div>"
             + (f"<div><b>تحتاج:</b> {esc('، '.join(hm['materials']))}</div>" if hm.get("materials") else "")
             + "<ol>" + "".join(f"<li>{esc(A(x))}</li>" for x in hm["steps"]) + "</ol>"
             + f"<div class='teacher'>👨‍👩‍👧 للأهل: {esc(hm['parent'])}</div></div>")
    on = L["online"]; url = ONLINE_URL.format(n=n)
    import base64
    qr = base64.b64encode(qr_png(url)).decode()
    h.append(f"<div class='box online'><img src='data:image/png;base64,{qr}'><div><h3>🎮 النشاط التفاعلي: {esc(on['title'])}</h3>"
             f"<div>{esc(on['intro'])}</div><div style='direction:ltr;text-align:right;font-size:9pt;color:#555'>{url}</div>"
             f"<div style='font-size:9.5pt'>على موقع التربية · {SITE_CFG['path']}</div></div></div>")
    h.append("<h2>📝 اختبر نفسك</h2><ol class='quiz'>")
    for q in L["quiz"]:
        h.append(f"<li><b>{esc(A(q['q']))}</b><div class='opts'>" +
                 "".join(f"<span>☐ {ABJ[i]}) {esc(A(o))}</span>" for i, o in enumerate(q["o"])) + "</div></li>")
    h.append("</ol><div class='key'>الإجابات: " + " · ".join(f"{A(i + 1)}) {ABJ[q['a']]}" for i, q in enumerate(L["quiz"])) + "</div>")
    h.append(f"<div class='ft'>{esc(SERIES['title'])} · أكاديمية التربية · tarbiyahkids.uk</div></body></html>")
    return "".join(h)


def make_pdf(n, L, d):
    import subprocess
    page_html = d / "lesson.html"; page_html.write_text(pdf_html(n, L))
    out = d / f"درس-{n:02d}.pdf"
    subprocess.run(["node", str(Path(__file__).with_name("topdf.js")), str(page_html), str(out)], check=True,
                   cwd="/tmp")
    return out

# ───────────────────────── PPTX ─────────────────────────

def make_pptx(n, L, d):
    from pptx import Presentation
    from pptx.util import Emu, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.oxml.ns import qn

    prs = Presentation(); prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)
    SW, SH = prs.slide_width, prs.slide_height
    blank = prs.slide_layouts[6]
    rgb = lambda h: RGBColor.from_string(h)
    BODY, QF = "Arial", "Traditional Arabic"

    def rtl_par(p, size, color=INK, bold=False, font=BODY, align=PP_ALIGN.RIGHT):
        p.alignment = align
        p._pPr if p._p.pPr is not None else p._p.get_or_add_pPr()
        p._p.get_or_add_pPr().set("rtl", "1")
        for r in p.runs:
            r.font.size = Pt(size); r.font.color.rgb = rgb(color); r.font.name = font
            if bold: r.font.bold = True
            rPr = r._r.get_or_add_rPr(); rPr.set("lang", "ar-SA")
            cs = rPr.find(qn("a:cs"))
            if cs is None:
                cs = rPr.makeelement(qn("a:cs"), {}); rPr.append(cs)
            cs.set("typeface", font)

    def add_runs(p, text):
        """نص فيه <b>…</b> → مقاطع عريضة وعادية."""
        for k, part in enumerate(re.split(r"</?b>", text)):
            if part:
                r = p.add_run(); r.text = A(part); r.font.bold = (k % 2 == 1)

    def textbox(sl, x, y, w, h, paras, size=20, color=INK, bold=False, font=BODY, align=PP_ALIGN.RIGHT,
                anchor=MSO_ANCHOR.TOP, bullets=False):
        tb = sl.shapes.add_textbox(x, y, w, h); tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
        for i, t in enumerate(paras):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            add_runs(p, ("• " if bullets else "") + t)
            keep = [r.font.bold for r in p.runs]
            rtl_par(p, size, color, bold, font, align)
            for r, kb in zip(p.runs, keep):
                r.font.bold = bold or kb
            p.space_after = Pt(size * .45)
        return tb

    def slide(title, accent=NAVY, icon=""):
        sl = prs.slides.add_slide(blank)
        bg = sl.background.fill; bg.solid(); bg.fore_color.rgb = rgb(CREAM)
        bar = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SW, Emu(1000000))
        bar.fill.solid(); bar.fill.fore_color.rgb = rgb(accent); bar.line.fill.background()
        textbox(sl, Emu(500000), Emu(140000), SW - Emu(1000000), Emu(760000), [title],
                size=30, color="FFFFFF", bold=True, anchor=MSO_ANCHOR.MIDDLE)
        tag = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Emu(380000), Emu(6280000), Emu(2600000), Emu(380000))
        tag.fill.solid(); tag.fill.fore_color.rgb = rgb(GOLD); tag.line.fill.background()
        tf = tag.text_frame; tf.paragraphs[0].text = f"الحلقة {A(n)} · {SITE_CFG['short']}"
        rtl_par(tf.paragraphs[0], 11, NAVY, True, align=PP_ALIGN.CENTER)
        return sl

    CX, CY, CW, CH = Emu(600000), Emu(1250000), SW - Emu(1200000), Emu(4900000)
    s = season_of(n)
    # 1) الغلاف
    sl = prs.slides.add_slide(blank)
    bg = sl.background.fill; bg.solid(); bg.fore_color.rgb = rgb(NAVY)
    c = sl.shapes.add_shape(MSO_SHAPE.OVAL, SW - Emu(2700000), Emu(900000), Emu(1700000), Emu(1700000))
    c.fill.solid(); c.fill.fore_color.rgb = rgb(GOLD); c.line.fill.background()
    tf = c.text_frame; tf.paragraphs[0].text = A(n); rtl_par(tf.paragraphs[0], 66, NAVY, True, align=PP_ALIGN.CENTER)
    textbox(sl, Emu(600000), Emu(2900000), SW - Emu(1200000), Emu(1800000), [L["title"]], 40, "FFFFFF", True)
    textbox(sl, Emu(600000), Emu(4800000), SW - Emu(1200000), Emu(1200000),
            [SERIES["title"], f"{s['title']} · الأعمار {A(AGES)}"], 20, GOLD)
    # 2) الأهداف
    sl = slide("أهداف الدرس"); textbox(sl, CX, CY, CW, CH, L["objectives"], 24, bullets=True)
    # 3) كشف القضية السابقة + لغز البداية
    pr = prev_reveal(n)
    if pr:
        sl = slide(f"{LB['reveal_short']}: {pr['title']}", "5B3FA8", "🔍"); textbox(sl, CX, CY, CW, CH, [pr["reveal"]], 24)
    sl = slide("لغز البداية", "B8860B", "🤔"); textbox(sl, CX, CY + Emu(600000), CW, CH, [L["hook"]], 30, NAVY, True,
                                                   align=PP_ALIGN.CENTER)
    # 4أ) الأبيات: بيتان في كل شريحة
    vs = episode_verses(n, L)
    for k in range(0, len(vs), 2):
        grp = vs[k:k + 2]
        sl = slide(f"{grp[0]['title']} · الأبيات {A(grp[0]['n'])}–{A(grp[-1]['n'])}", "7A5A20")
        textbox(sl, CX, CY + Emu(400000), CW, CH, [" ⁂ ".join(v["v"]) for v in grp], 30, "1A2B4A", True,
                font=QF, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    # 4) الأقسام
    for sec in L["sections"]:
        sl = slide(sec["h"])
        hh = CH - (Emu(900000) if sec.get("board") else 0)
        ln = sum(len(strip(p)) for p in sec["p"])
        size = 26 if ln < 260 else 22 if ln < 450 else 19 if ln < 650 else 17
        textbox(sl, CX, CY, CW, hh, sec["p"], size, bullets=True)
        if sec.get("board"):
            k = len(sec["board"]); gap = Emu(120000); bw = int((CW - gap * (k - 1)) / k)
            for i, b in enumerate(sec["board"]):
                ch = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, CX + CW - (i + 1) * bw - i * gap,
                                         CY + CH - Emu(800000), bw, Emu(700000))
                ch.fill.solid(); ch.fill.fore_color.rgb = rgb(NAVY); ch.line.fill.background()
                tf = ch.text_frame; tf.word_wrap = True; tf.paragraphs[0].text = A(b)
                rtl_par(tf.paragraphs[0], 15 if k > 3 else 18, "FFFFFF", True, align=PP_ALIGN.CENTER)
    # 4ب) هل تعلم؟ وأسئلة الكتاب
    for f in book_dyk(L):
        sl = slide("هل تعلم؟", "B8860B"); textbox(sl, CX, CY + Emu(500000), CW, CH, [f], 28, NAVY, True, align=PP_ALIGN.CENTER)
    for q in book_qa(L):
        sl = slide(f"سؤال الكتاب ({A(q['id'])})", "5B3FA8")
        textbox(sl, CX, CY + Emu(900000), CW, CH, [q["q"]], 36, NAVY, True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        sl = slide(f"الجواب ({A(q['id'])})", GREEN)
        ln = len(q["answer"])
        textbox(sl, CX, CY, CW, CH, [x for x in q["answer"].split("\n") if x.strip()], 26 if ln < 200 else 21 if ln < 400 else 17 if ln < 650 else 14)
    # 5) الوحي
    isl = L.get("islam")
    if isl:
        sl = slide("من نور الوحي", "7A5A20", "🌙")
        y = CY
        if isl.get("ayah"):
            a = ayah_text(isl["ayah"])
            textbox(sl, CX, y, CW, Emu(2700000), [f"﴿{a['text']}﴾", f"{a['surah']}: {A(a['num'])}"], 24, "1A2B4A",
                    font=QF, align=PP_ALIGN.CENTER); y += Emu(2800000)
        if isl.get("hadith"):
            textbox(sl, CX, y, CW, Emu(1300000), [f"«{isl['hadith']['text']}»", isl["hadith"]["source"]], 22, "1A2B4A",
                    font=QF, align=PP_ALIGN.CENTER); y += Emu(1400000)
        textbox(sl, CX, y, CW, CY + CH - y, [isl["text"]], 18)
    # 6) الكلمات
    if L.get("vocab"):
        sl = slide("كلمات الدرس", icon="📖")
        rows = len(L["vocab"]) + 1
        tbl = sl.shapes.add_table(rows, 2, CX, CY, CW, Emu(min(4800000, 620000 * rows))).table
        tbl.columns[0].width = int(CW * .68); tbl.columns[1].width = CW - int(CW * .68)
        for r, (w, dsc) in enumerate([("المعنى", "الكلمة")] + [(dd, ww) for ww, dd in L["vocab"]]):
            for ci, val in enumerate((w, dsc)):
                cell = tbl.cell(r, ci); cell.text = A(val)
                rtl_par(cell.text_frame.paragraphs[0], 18, "FFFFFF" if r == 0 else INK, r == 0 or ci == 1)
                cell.fill.solid(); cell.fill.fore_color.rgb = rgb(NAVY if r == 0 else ("FFFFFF" if r % 2 else "F3EAD6"))
    # 7) الأنشطة
    for k, a in enumerate(L["class_activities"], 1):
        sl = slide(f"النشاط {A(k)}: {a['title']} · {A(a['minutes'])} دقيقة", GREEN, "⏸")
        paras = [f"{A(i + 1)}. {x}" for i, x in enumerate(a["steps"])]
        if a.get("materials"):
            paras = ["<b>الأدوات:</b> " + "، ".join(a["materials"])] + paras
        textbox(sl, CX, CY, CW, CH, paras, 20)
        sl.notes_slide.notes_text_frame.text = "للمعلّم: " + a.get("teacher", "")
    # 8) القضية
    c = L["case"]
    sl = slide(f"{LB['case']}: {c['title']}", "5B3FA8", "🕵️")
    paras = [c["story"], "<b>الأدلّة:</b>"] + [f"{A(i + 1)}. {x}" for i, x in enumerate(c["evidence"])] + \
            [f"<b>{LB['options']}:</b> " + " · ".join(f"{ABJ[i]}) {o}" for i, o in enumerate(c["options"]))]
    textbox(sl, CX, CY, CW, CH - Emu(700000), paras, 18)
    textbox(sl, CX, CY + CH - Emu(700000), CW, Emu(700000), ["سؤال التفكير: " + c["deep"]], 18, "5B3FA8", True)
    sl.notes_slide.notes_text_frame.text = "لا تكشف الحلّ. يُكشف في الحلقة القادمة: " + c["reveal"]
    # 9) الخلاصة
    sl = slide("خلاصة الدرس"); textbox(sl, CX, CY, CW, CH, L["summary"], 26, bullets=True)
    # 10) الاختبار
    for i, q in enumerate(L["quiz"], 1):
        sl = slide(f"اختبر نفسك ({A(i)}/{A(len(L['quiz']))})", "B8860B", "📝")
        textbox(sl, CX, CY, CW, Emu(1300000), [q["q"]], 26, NAVY, True)
        textbox(sl, CX, CY + Emu(1400000), CW, Emu(3000000), [f"{ABJ[j]}) {o}" for j, o in enumerate(q["o"])], 22)
        sl.notes_slide.notes_text_frame.text = f"الإجابة: {ABJ[q['a']]}) {q['o'][q['a']]} — {q.get('why', '')}"
    # 11) البيت والموقع
    hm = L["home"]
    sl = slide(f"نشاط البيت: {hm['title']}", "C0563A", "🏠")
    textbox(sl, CX, CY, CW, CH, [hm["goal"]] + [f"{A(i + 1)}. {x}" for i, x in enumerate(hm["steps"])], 22)
    on = L["online"]; url = ONLINE_URL.format(n=n)
    sl = slide(f"النشاط التفاعلي: {on['title']}", "7A3FB0", "🎮")
    qp = d / "qr.png"; qp.write_bytes(qr_png(url))
    sl.shapes.add_picture(str(qp), CX, CY + Emu(300000), Emu(2600000), Emu(2600000))
    textbox(sl, CX + Emu(3000000), CY + Emu(300000), CW - Emu(3000000), CH,
            [on["intro"], "على موقع التربية: " + SITE_CFG["path"], url], 20)
    out = d / f"درس-{n:02d}.pptx"; prs.save(out)
    return out

# ───────────────────────── بيانات الموقع ─────────────────────────

def site_podcast(n, L):
    """أسطر البودكاست للموقع: نصّ الآية العثماني للتلاوة، وأبيات الإنشاد."""
    if not L.get("podcast"):
        return None
    out = []
    for l in L["podcast"]["lines"]:
        l = dict(l)
        if l.get("s") == "quran":
            l["t"] = ayah_text(l["ref"])["text"]
        if l.get("s") == "sing":
            d = json.loads((NOTES / SERIES.get("texts_dir", "texts") / f"{l['id']}.json").read_text())
            vv = d.get("verses_vocalized_proposed") or d["verses"]
            l["verses"] = [(" ".join(v) if isinstance(v, list) else v) for v in vv[l["from"] - 1:l["to"]]]
        out.append(l)
    return {"lines": out}


def site_data():
    eps = []
    for f in sorted(LESSONS.glob("ep*.json")):
        L = json.loads(f.read_text()); n = L["n"]
        isl = L.get("islam") or {}
        ay = None
        if isl.get("ayah"):
            a = ayah_text(isl["ayah"]); ay = {"text": a["text"], "src": f"{a['surah']}: {A(a['num'])}"}
        eps.append({"n": n, "title": L["title"], "season": season_of(n)["n"], "goals": L["goals"],
                    "hook": L["hook"], "sections": L["sections"], "summary": L["summary"],
                    "islam": {"intro": isl.get("intro", ""), "text": isl.get("text", ""), "ayah": ay,
                              "hadith": isl.get("hadith")},
                    "home": L["home"], "online": L["online"], "case": L["case"], "quiz": L["quiz"][:1],
                    "qa": [{"id": q["id"], "q": q["q"], "a": q["answer"]} for q in book_qa(L)], "dyk": book_dyk(L),
                    "verses": episode_verses(n, L), "singer": episode_meta(n).get("singer"),
                    "podcast": site_podcast(n, L)})
    js = ("/* money-series.js — مُولَّد تلقائيًّا من notes/money-curriculum/lessons/*.json عبر tools/money/build.py.\n"
          "   لا تعدّله يدويًّا؛ عدّل ملفّات الدروس ثم أعد البناء. */\n"
          "window." + SITE_CFG["var"] + " = " + json.dumps({"title": SERIES["title"], "seasons": SERIES["seasons"],
                                                 "goals": SERIES["goals"], "episodes": eps,
                                                 "podcast_hosts": {k: {"name": v["name"], "g": v.get("g", "female"), "icon": v.get("icon", "🎙️")}
                                                                   for k, v in (SERIES.get("podcast") or {}).get("hosts", {}).items()}}, ensure_ascii=False) + ";\n")
    p = ROOT / "corners" / "skills" / "data" / SITE_CFG["data"]; p.write_text(js)
    print(f"✓ site data: {len(eps)} episodes → {p.relative_to(ROOT)}")


def main():
    args = sys.argv[1:]
    if args != ["--site"]:
        ns = [int(a) for a in args] or sorted(int(f.stem[2:]) for f in LESSONS.glob("ep*.json"))
        for n in ns:
            L = load(n); d = OUT / f"ep{n:02d}"; d.mkdir(parents=True, exist_ok=True)
            print(f"▶ {n}: {L['title']}")
            print("  ✓", make_pdf(n, L, d).name); print("  ✓", make_pptx(n, L, d).name)
    site_data()


if __name__ == "__main__":
    main()
