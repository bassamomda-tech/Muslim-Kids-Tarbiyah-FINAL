// node tools/money/topdf.js in.html out.pdf — طباعة صفحة HTML إلى PDF بحجم A4 مع ترقيم الصفحات
const { chromium } = require('playwright');
(async () => {
  const [inp, out] = process.argv.slice(2);
  const b = await chromium.launch(); const pg = await b.newPage();
  await pg.goto('file://' + require('path').resolve(inp)); await pg.waitForTimeout(400);
  await pg.pdf({ path: out, format: 'A4', printBackground: true, preferCSSPageSize: true, displayHeaderFooter: true,
    headerTemplate: '<span></span>',
    footerTemplate: "<div style='font-size:8px;width:100%;text-align:center;color:#999'><span class='pageNumber'></span></div>" });
  await b.close();
})();
