// node tools/money/book.js — يطبع كتاب «ما لا يسع أطفال المسلمين جهله» من ملفّات ساحة المسابقات بصيغة JSON:
// {qa: {id: {topic, q, answer, src}}, whoami: {id: {q, answer}}, dyk: [{cat, ar}]}
const path = require('path'); const C = path.join(__dirname, '..', '..', 'corners', 'competitions');
global.window = {};
require(path.join(C, 'bank.js')); const base = window.COMP_BANK.questions.length;
require(path.join(C, 'bank-whoami.js')); require(path.join(C, 'didyouknow.js'));
const Q = window.COMP_BANK.questions, out = { topics: window.COMP_BANK.topics, qa: {}, whoami: {}, dyk: window.DYK.map(d => ({ cat: d.cat, ar: d.ar })) };
Q.forEach((q, i) => {
  const clean = { topic: q.topic, q: q.q.replace(/^\(س [^)]*\)\s*/, ''), answer: q.answer, src: q.src || '' };
  if (q.topic === 'whoami') out.whoami[q.id] = { q: q.q.replace(/^🎭\s*/, ''), answer: q.answer };
  else if (i < base) out.qa[q.id] = clean;
});
process.stdout.write(JSON.stringify(out));
