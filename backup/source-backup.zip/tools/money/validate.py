#!/usr/bin/env python3
"""يتحقّق من ملفّات الدروس notes/money-curriculum/lessons/epNN.json قبل البناء.
الاستخدام: python3 tools/money/validate.py [أرقام الحلقات]   (بلا أرقام = كل الموجود)"""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
NOTES = ROOT / "notes" / __import__("os").environ.get("SERIES_DIR", "money-curriculum")
SERIES = json.loads((NOTES / "series30.json").read_text())
TYPES = {"sort", "match", "quiz", "order", "decision", "budget", "calc"}


def check(n):
    errs = []
    E = errs.append
    f = NOTES / "lessons" / f"ep{n:02d}.json"
    if not f.exists():
        return [f"ep{n:02d}.json غير موجود"]
    try:
        L = json.loads(f.read_text())
    except Exception as e:
        return [f"JSON غير صالح: {e}"]
    meta = next(e for e in SERIES["episodes"] if e["n"] == n)
    if L.get("n") != n: E("n لا يطابق رقم الملف")
    if sorted(L.get("goals", [])) != sorted(meta["goals"]): E(f"goals يجب أن تكون {meta['goals']}")
    for k in ("title", "hook"):
        if not isinstance(L.get(k), str) or len(L[k]) < 10: E(f"{k} ناقص")
    if not (3 <= len(L.get("objectives", [])) <= 5): E("objectives: من ٣ إلى ٥")
    secs = L.get("sections", [])
    if not (3 <= len(secs) <= 5): E("sections: من ٣ إلى ٥")
    for s in secs:
        if not s.get("h") or not s.get("p") or not all(isinstance(p, str) for p in s["p"]): E("قسم ناقص h أو p")
        if re.search(r"<(?!/?b>)[^>]+>", " ".join(s.get("p", []))): E(f"وسوم غير <b> في القسم «{s.get('h')}»")
    words = sum(len(re.sub(r"<[^>]+>", "", p).split()) for s in secs for p in s.get("p", []))
    mw = SERIES.get("min_section_words", 220)
    if words < mw: E(f"نص الأقسام قصير ({words} كلمة؛ المطلوب {mw} فأكثر)")
    isl = L.get("islam")
    if not isl or not isl.get("text"): E("islam.text ناقص")
    elif isl.get("ayah") and not re.fullmatch(r"\d{1,3}:\d{1,3}(-\d{1,3})?", isl["ayah"]): E("islam.ayah بصيغة «سورة:آية» بالأرقام")
    if isl and isl.get("hadith") and not (isl["hadith"].get("text") and isl["hadith"].get("source")): E("hadith يحتاج text وsource")
    if not (4 <= len(L.get("vocab", [])) <= 7) or not all(len(v) == 2 for v in L.get("vocab", [])): E("vocab: ٤–٧ أزواج [كلمة، معنى]")
    acts = L.get("class_activities", [])
    if len(acts) < 2: E("class_activities: نشاطان على الأقل")
    if not any(a.get("decision") for a in acts): E("أحد الأنشطة يجب أن يكون مختبر قرار (decision: true)")
    for a in acts:
        for k in ("title", "minutes", "steps", "teacher"):
            if not a.get(k): E(f"نشاط «{a.get('title')}» ينقصه {k}")
        if not (3 <= len(a.get("steps", [])) <= 6): E(f"نشاط «{a.get('title')}»: ٣–٦ خطوات")
    if len(L.get("summary", [])) != 3: E("summary: ثلاث نقاط بالضبط")
    qz = L.get("quiz", [])
    if len(qz) != 5: E("quiz: خمسة أسئلة بالضبط")
    for q in qz:
        if not (3 <= len(q.get("o", [])) <= 4) or not isinstance(q.get("a"), int) or not 0 <= q["a"] < len(q["o"]): E(f"سؤال غير صالح: {q.get('q')}")
    if qz and len({q["a"] for q in qz}) == 1: E("نوّع مواضع الإجابات الصحيحة في الاختبار")
    c = L.get("case", {})
    for k in ("title", "story", "deep", "reveal"):
        if not c.get(k): E(f"case.{k} ناقص")
    if len(c.get("evidence", [])) != 3 or len(c.get("options", [])) != 3: E("case: ٣ أدلّة و٣ خيارات")
    h = L.get("home", {})
    for k in ("title", "goal", "steps", "parent"):
        if not h.get(k): E(f"home.{k} ناقص")
    on = L.get("online", {})
    if not on.get("title") or not on.get("intro"): E("online.title/intro ناقص")
    st = on.get("steps", [])
    if not (2 <= len(st) <= 3): E("online.steps: خطوتان أو ثلاث")
    for s in st:
        t = s.get("type")
        if t not in TYPES: E(f"نوع نشاط غير معروف: {t}"); continue
        if t == "sort":
            nb = len(s.get("bins", []))
            if nb < 2 or len(s.get("items", [])) < 5: E("sort: صندوقان و٥ بطاقات على الأقل")
            if any(not isinstance(x.get("bin"), int) or not 0 <= x["bin"] < nb or not x.get("why") for x in s.get("items", [])): E("sort: كل بطاقة تحتاج bin صحيحًا وwhy")
        if t == "match" and (len(s.get("pairs", [])) < 3 or any(len(p) != 2 for p in s["pairs"])): E("match: ٣ أزواج على الأقل")
        if t == "quiz" and (not s.get("items") or any(not 0 <= q.get("a", -1) < len(q.get("o", [])) for q in s["items"])): E("quiz: أسئلة غير صالحة")
        if t == "order" and len(s.get("items", [])) < 3: E("order: ٣ عناصر على الأقل")
        if t == "decision":
            ops = s.get("options", [])
            if not s.get("scenario") or len(ops) < 3 or sum(1 for o in ops if o.get("best")) != 1 or any(not o.get("result") for o in ops):
                E("decision: scenario و٣ خيارات لكلٍّ result، وواحد فقط best")
        if t == "budget":
            cats, tot = s.get("cats", []), s.get("total")
            if not isinstance(tot, (int, float)) or len(cats) < 2: E("budget: total وفئتان على الأقل")
            elif sum(c.get("min") or 0 for c in cats) > tot: E("budget: مجموع الحدود الدنيا أكبر من المبلغ")
            elif any(c.get("max") is not None and c.get("min") is not None and c["max"] < c["min"] for c in cats): E("budget: max < min")
            elif s.get("step") and any(((c.get("min") or 0) % s["step"]) for c in cats): E("budget: الحدود يجب أن تكون من مضاعفات step")
        if t == "calc" and (not s.get("items") or any(not isinstance(q.get("answer"), (int, float)) for q in s["items"])): E("calc: answer رقم")
    pc = SERIES.get("podcast")
    if pc and L.get("podcast") is not None:
        lines = L["podcast"].get("lines", [])
        hosts = set(pc["hosts"])
        bad = [l for l in lines if l.get("s") not in hosts | {"quran", "pause", "sing"}]
        if bad: E(f"podcast: متحدّث غير معروف {bad[0].get('s')}")
        words = sum(len(l.get("t", "").split()) for l in lines if l.get("s") in hosts)
        if not pc["words"][0] <= words <= pc["words"][1]: E(f"podcast: {words} كلمة، المطلوب {pc['words'][0]}–{pc['words'][1]}")
        if sum(1 for l in lines if l.get("s") == "pause") < 2: E("podcast: موضعا نشاط (pause) على الأقل")
        q = [l for l in lines if l.get("s") == "quran"]
        if len(q) > 1 or any(not re.fullmatch(r"\d{1,3}:\d{1,3}", l.get("ref", "")) for l in q): E("podcast: آية واحدة على الأكثر بصيغة ref «سورة:آية»")
        if any(len(l.get("t", "").split()) > 45 for l in lines if l.get("s") in hosts): E("podcast: سطر أطول من ٤٥ كلمة")
        if meta.get("text"):
            want = {(t["id"], k) for t in meta["text"] for k in range(t["from"], t["to"] + 1)}
            got = {(l["id"], k) for l in lines if l.get("s") == "sing" for k in range(l["from"], l["to"] + 1)}
            if want - got: E(f"podcast: أبيات لم تُنشد: {len(want - got)}")
    if SERIES.get("book"):
        q = meta.get("qa")
        if q and L.get("qa") != list(range(q[0], q[1] + 1)): E(f"qa يجب أن تكون الأسئلة {q[0]}–{q[1]} بالترتيب")
        if meta.get("qa_ids") and L.get("qa") != meta["qa_ids"]: E(f"qa يجب أن تكون {meta['qa_ids']}")
        if not (1 <= len(L.get("dyk", [])) <= 3) or any(not isinstance(i, int) or not 0 <= i < 100 for i in L.get("dyk", [])): E("dyk: ١–٣ أرقام معلومات من 0 إلى 99")
    return errs


def podcast_minutes():
    pc = SERIES.get("podcast")
    if not pc:
        return None
    mins = []
    for p in sorted((NOTES / "lessons").glob("ep*.json")):
        L = json.loads(p.read_text())
        if L.get("podcast"):
            w = sum(len(l.get("t", "").split()) for l in L["podcast"]["lines"] if l.get("s") in pc["hosts"])
            q = sum(1 for l in L["podcast"]["lines"] if l.get("s") == "quran")
            sung = sum(l["to"] - l["from"] + 1 for l in L["podcast"]["lines"] if l.get("s") == "sing")
            mins.append(w / pc["wpm"] + q * 0.6 + sung * 4.5 / 60 + len(L["podcast"]["lines"]) * 0.35 / 60 + 0.4)
    return mins


def series_checks():
    """تحقّق على مستوى السلسلة: لا تتكرّر معلومة «هل تعلم؟» بين الحلقات."""
    if not SERIES.get("book"):
        return []
    seen, out = {}, []
    for p in sorted((NOTES / "lessons").glob("ep*.json")):
        for i in json.loads(p.read_text()).get("dyk", []):
            if i in seen: out.append(f"معلومة هل تعلم رقم {i} مكرّرة في {seen[i]} و{p.stem}")
            seen[i] = p.stem
    return out


def main():
    ns = [int(a) for a in sys.argv[1:]] or sorted(int(p.stem[2:]) for p in (NOTES / "lessons").glob("ep*.json"))
    bad = 0
    for n in ns:
        e = check(n)
        print(f"ep{n:02d}: " + ("✓" if not e else "✗ " + " | ".join(e)))
        bad += bool(e)
    for e in series_checks():
        print("✗", e); bad += 1
    m = podcast_minutes()
    if m:
        print(f"🎧 البودكاست: {len(m)} حلقة · المتوسط {sum(m)/len(m):.1f} دقيقة · من {min(m):.1f} إلى {max(m):.1f}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
