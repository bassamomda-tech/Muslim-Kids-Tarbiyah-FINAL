#!/usr/bin/env python3
"""
بودكاست صوتي لكل حلقة من نصّ "podcast" في notes/<series>/lessons/epNN.json:
  مذيعان بصوتين (Gemini TTS مع مدقّق النطق، أو Chirp3 احتياطيًّا)، وتلاوة الحصري للآية،
  ثم توحيد مستوى الصوت (‎-16 LUFS) وترميز MP3 مع وسوم الحلقة وصورة الغلاف.

الاستخدام:
  SERIES_DIR=anos-series python3 tools/money/podcast.py 1 2 3
  PODCAST_TTS=chirp …     # تخطّي Gemini واستعمال Chirp3 مباشرة (حين لا يوجد رصيد)
الإخراج: tools/money/out-podcast/<series>/epNN.mp3 + cover.jpg
"""
import base64, json, os, subprocess, sys, wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SDIR = os.environ.get("SERIES_DIR", "money-curriculum")
NOTES = ROOT / "notes" / SDIR
OUT = ROOT / "tools" / "money" / "out-podcast" / SDIR
sys.path.insert(0, str(ROOT / "tools" / "podcast"))
import make_episode as m  # noqa: E402

SERIES = json.loads((NOTES / "series30.json").read_text())
PC = SERIES["podcast"]
_PR = (" " + PC["pronounce"]) if PC.get("pronounce") else ""
m.HOSTS = {k: {"name": v["name"], "voice": v["voice"], "style": v["style"] + _PR, "rgb": (255, 255, 255)} for k, v in PC["hosts"].items()}
REPORT = []
SR, GAP = 24000, 0.35
AR = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")


def chirp(text, voice, path):
    r = m._post("https://texttospeech.googleapis.com/v1/text:synthesize", {
        "input": {"text": text}, "voice": {"languageCode": "ar-XA", "name": "ar-XA-Chirp3-HD-" + voice},
        "audioConfig": {"audioEncoding": "LINEAR16", "sampleRateHertz": SR, "speakingRate": 0.95}}, "GOOGLE_TTS_API_KEY")
    path.write_bytes(base64.b64decode(r["audioContent"]))


def to_wav24(src, dst):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-ar", str(SR), "-ac", "1", "-sample_fmt", "s16", str(dst)], check=True)


def voice(line, path):
    if path.exists():
        return
    if os.environ.get("PODCAST_TTS") == "chirp":
        chirp(line["t"], PC["hosts"][line["s"]]["voice"], path)
    else:
        wrong = m.voice_line(line["t"], line["s"], path)       # Gemini + مدقّق النطق + بديل Chirp3
        if wrong:
            REPORT.append({"line": path.stem, "text": line["t"], "wrong": wrong})


def sing(L, n, line, path):
    """إنشاد أبيات من متن بصوت طفل/طفلة الحلقة، بلا موسيقى، على دفعات قصيرة ثم تُوصل."""
    if path.exists():
        return
    import time
    d = json.loads((NOTES / SERIES.get("texts_dir", "texts") / f"{line['id']}.json").read_text())
    vv = d.get("verses_vocalized_proposed") or d["verses"]
    verses = [(" ".join(v) if isinstance(v, list) else v) for v in vv[line["from"] - 1:line["to"]]]
    meta = next(e for e in SERIES["episodes"] if e["n"] == n)
    who = meta.get("singer", "boy")
    styles = [PC["sing_style"].format(who=who),
              f"In the cheerful voice of a ten-year-old {who}, chant this poem rhythmically and melodically at a lively quick pace, like a happy school song."]
    chunks = []
    for k in range(0, len(verses), 5):
        cp = path.with_suffix(f".s{k}.wav")
        if not cp.exists():
            for st in styles * 2:
                m.HOSTS["_sing"] = {"name": "sing", "voice": PC["hosts"][who]["voice"], "style": st, "rgb": (0, 0, 0)}
                try:
                    m.tts("\n".join(verses[k:k + 5]), "_sing", cp); break
                except Exception as e:
                    print("  sing retry:", str(e)[:80]); time.sleep(3)
        q = cp.with_suffix(".24.wav"); to_wav24(cp, q); chunks.append(q)
    lst = path.with_suffix(".txt"); lst.write_text("".join(f"file '{c}'\n" for c in chunks))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                    "-af", "aecho=0.8:0.6:40:0.12", str(path)], check=True)


def cover(path):
    """غلاف مربّع 3000×3000 (متطلّب Apple Podcasts)."""
    from PIL import Image, ImageDraw, ImageFont
    S = 3000
    im = Image.new("RGB", (S, S), (34, 50, 90)); dr = ImageDraw.Draw(im)
    for k in range(10):
        dr.ellipse((S * .55 - k * 60, -S * .25 - k * 60, S * 1.3 + k * 60, S * .5 + k * 60), outline=(231, 184, 74), width=6)
    kw = dict(direction="rtl", language="ar")
    def F(sz, wt="Bold"):
        f = ImageFont.truetype(str(m.FONTS / "Cairo.ttf"), sz); f.set_variation_by_name(wt); return f
    t = SERIES["site"]["short"]
    dr.text((S / 2, S * .40), t, font=F(300), fill=(255, 255, 255), anchor="mm", **kw)
    sub = SERIES["title"].split(":", 1)[-1].strip() if ":" in SERIES["title"] else ""
    if sub:
        dr.text((S / 2, S * .53), sub, font=F(150, "SemiBold"), fill=(231, 184, 74), anchor="mm", **kw)
    dr.text((S / 2, S * .66), f"مع {SERIES['hosts']}", font=F(130, "SemiBold"), fill=(230, 236, 245), anchor="mm", **kw)
    dr.text((S / 2, S * .86), "بودكاست أكاديمية التربية للأطفال · tarbiyahkids.uk", font=F(95, "Medium"), fill=(200, 210, 230), anchor="mm", **kw)
    im.save(path, quality=92)


def build(n):
    L = json.loads((NOTES / "lessons" / f"ep{n:02d}.json").read_text())
    lines = L["podcast"]["lines"]
    d = OUT / f"ep{n:02d}"; d.mkdir(parents=True, exist_ok=True)
    parts = []
    for i, l in enumerate(lines):
        p = d / f"{i:03d}.wav"
        if l["s"] == "quran":
            m.husary(l["ref"], p)
        elif l["s"] == "pause":
            m.silence_wav(1.5, p)
        elif l["s"] == "sing":
            sing(L, n, l, p)
        else:
            voice(l, p)
            q = d / f"{i:03d}.24.wav"
            if not q.exists():
                to_wav24(p, q)
            p = q
        parts.append(p)
    gap = d / "gap.wav"; m.silence_wav(GAP, gap)
    lst = d / "list.txt"
    lst.write_text("".join(f"file '{p}'\nfile '{gap}'\n" for p in parts))
    out = OUT / f"ep{n:02d}.mp3"
    cv = OUT / "cover.jpg"
    if not cv.exists():
        cover(cv)
    title = f"الحلقة {str(n).translate(AR)}: {L['title']}"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-i", str(cv),
                    "-map", "0:a", "-map", "1:v", "-af", (f"atempo={PC['tempo']}," if PC.get("tempo", 1) != 1 else "") + "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "44100", "-ac", "1",
                    "-c:a", "libmp3lame", "-b:a", "96k", "-c:v", "mjpeg", "-disposition:v", "attached_pic",
                    "-id3v2_version", "3", "-metadata", f"title={title}", "-metadata", f"album={SERIES['title']}",
                    "-metadata", "artist=أكاديمية التربية للأطفال", "-metadata", f"track={n}", "-metadata", "genre=Kids & Family",
                    str(out)], check=True)
    dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(out)],
                               capture_output=True, text=True).stdout)
    if REPORT:
        (d / "pronunciation-report.json").write_text(json.dumps(REPORT, ensure_ascii=False, indent=1))
    print(f"✓ {out.relative_to(ROOT)} · {dur / 60:.1f} دقيقة · كلمات مشكوك في نطقها: {sum(len(r['wrong']) for r in REPORT)}")
    REPORT.clear()
    return dur


if __name__ == "__main__":
    ns = [int(a) for a in sys.argv[1:]] or sorted(int(p.stem[2:]) for p in (NOTES / "lessons").glob("ep*.json"))
    durs = [build(n) for n in ns]
    print(f"المتوسط: {sum(durs) / len(durs) / 60:.1f} دقيقة")
