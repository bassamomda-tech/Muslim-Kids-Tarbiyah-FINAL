#!/usr/bin/env python3
"""يولّد وثيقة خطة المسلسل (PDF + Word) من series30.json وcases.json.
الاستخدام: python3 tools/money/plan.py [مجلد الإخراج]"""
import json, re, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]; N = ROOT / "notes" / __import__("os").environ.get("SERIES_DIR", "money-curriculum")
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "tools" / "money" / "out"; OUT.mkdir(parents=True, exist_ok=True)
S = json.loads((N / "series30.json").read_text()); C = {c["week"]: c for c in json.loads((N / "cases.json").read_text())["cases"]} if (N / "cases.json").exists() else {}
AR = str.maketrans("0123456789%", "٠١٢٣٤٥٦٧٨٩٪"); A = lambda x: str(x).translate(AR)
GL = lambda g: ("م" + A(g[1:])) if g.startswith("+") else A(g)
ON = {"sort": "تصنيف", "timeline": "ترتيب زمني", "decision": "مختبر القرار", "budget": "توزيع ميزانية", "savings": "حساب الادّخار",
      "jars": "تقسيم الجِرار", "zakat": "حساب الزكاة", "quiz": "اختبار", "match": "توصيل", "market": "محاكاة السوق", "order": "ترتيب المراحل",
      "mindmap": "خريطة ذهنية", "survey": "استبيان", "plan": "خطة العمل", "pricing": "حساب السعر", "problem": "نموذج حلّ المشكلات"}
BK = json.loads(subprocess.run(["node", str(Path(__file__).with_name("book.js"))], capture_output=True, text=True).stdout) if S.get("book") else None
ON["flash"] = "أسئلة وأجوبة"


def case_title(e):
    f = N / "lessons" / f"ep{e['n']:02d}.json"
    if f.exists(): return json.loads(f.read_text())["case"]["title"]
    return (e.get("case") or C.get(e.get("case_week"), {})).get("title", "")
L = [f"# خطة مسلسل «{S['site']['short']}»: ٣٠ حلقة\n", f"**{S['title']}** · الأعمار {A(S.get('ages', '8–13'))} · المذيعان: {S.get('hosts', '')}\n",
     "## مكوّنات كل حلقة\n"]
L += [f"- {x}" for x in ["فيديو بمتوسط ١٠ دقائق، فيه نشاطان على الأقل يوقف المعلّم الفيديو عندهما، أحدهما «مختبر القرار».",
      "درس مكتوب بصيغتي PDF (للطالب والمعلّم) وPPT (عرض الحصّة).", "نشاط منزلي مع الأهل.",
      f"نشاط تفاعلي على موقع التربية: {S['site']['path']} (رمز QR في الدرس).",
      "ملفّ قضية يحلّه الطالب في البيت، ويُكشف حلّه في بداية الحلقة التالية."]]
L += ["\n## شكل الحصّة الثابت (٤٠–٤٥ دقيقة)\n", "| المرحلة | الزمن |", "|---|---|"]
L += [f"| {a} | {b} |" for a, b in [("لغز البداية", "٣ د"), ("كشف قضية الحلقة الماضية", "٥ د"), ("الفيديو التفاعلي ونشاطاه", "١٠–١٣ د + وقت النشاطين"),
      ("تحدّي الفريق / التطبيق العملي", "١٠–٢٠ د"), ("مهمّة الأسبوع: ملفّ القضية ونشاط البيت والنشاط التفاعلي", "٢ د")]]
if S.get("highlights"):
    L += ["\n## محاور بارزة\n", "| المحور | الحلقات |", "|---|---|"] + [f"| {h[0]} | {A(h[1])} |" for h in S["highlights"]]
for s in S["seasons"]:
    L += [f"\n## {s['title']}\n", f"| # | الحلقة | {'الباب والأسئلة' if S.get('book') else 'الأهداف'} | {S.get('labels', {}).get('case', 'ملفّ القضية')} | النشاط التفاعلي | عناصر خاصة |", "|---|---|---|---|---|---|"]
    for e in S["episodes"]:
        if not s["episodes"][0] <= e["n"] <= s["episodes"][1]: continue
        sp = [x for k, x in (("mystery", "عميل غامض"), ("shock", "صدمة السوق"), ("shura", S.get("labels", {}).get("shura", "مجلس الشورى")), ("project", "بداية المشروع الذي يكبر معي")) if e.get(k)]
        if e.get("island_round"): sp.append(f"جزر الأعمال ج{A(e['island_round'])}")
        if e.get("imam"): sp.append(f"حكاية الإمام {e['imam']}")
        if e.get("game"): sp.append(f"لعبة «رحلة المذاهب» ج{A(e['game'])}")
        gl, ct = '، '.join(GL(g) for g in e['goals']), case_title(e)
        if S.get("book") and e.get("qa_ids"):
            gl += " · أسئلة الكتاب: " + "، ".join("س" + A(i) for i in e["qa_ids"])
        elif S.get("book"):
            gl = f"{S['goals'][e['goals'][0]]}: س{A(e['qa'][0])}–س{A(e['qa'][1])}"
        if S.get("book") and e.get("whoami"):
            ct = "مَن أنا؟ " + BK["whoami"][str(e["whoami"])]["answer"].split("—")[0].replace("أنا ", "", 1).strip(" .")
        L.append(f"| {A(e['n'])} | {e['title']} | {gl} | {ct} | {ON.get(e['online'], e['online'])} | {'، '.join(sp)} |")
cov = {}
for e in S["episodes"]:
    for g in e["goals"]: cov.setdefault(g, []).append(e["n"])
L += [f"\n## مصفوفة تغطية الأهداف ({S.get('goals_note') or A(len(S['goals'])) + ' هدفًا'})\n", "| # | الهدف | الحلقات |", "|---|---|---|"]
L += [f"| {GL(g)} | {t} | {'، '.join(A(n) for n in cov.get(g, []))} |" for g, t in S["goals"].items()]
miss = [g for g in S["goals"] if g not in cov]
L.append("\n**النتيجة: كل الأهداف مغطّاة.**" if not miss else f"\n**أهداف غير مغطّاة: {miss}**")
md = OUT / "plan.md"; md.write_text("\n".join(L))
F = ROOT / "tools" / "podcast" / "fonts"
css = OUT / "plan.css"; css.write_text(f"""@font-face{{font-family:Cairo;src:url('file://{F}/Cairo.ttf')}}
@page{{size:A4 landscape;margin:12mm}} body{{font-family:Cairo;direction:rtl;font-size:10.5pt;line-height:1.6;color:#2b2b2b}}
h1{{background:#22325a;color:#fff;border-radius:12px;padding:10px 16px;font-size:18pt}} h2{{color:#22325a;border-bottom:3px solid #e7b84a;display:inline-block;margin-top:18px}}
table{{width:100%;border-collapse:collapse;margin:6px 0}} th{{background:#22325a;color:#fff}} td,th{{border:1px solid #d9ccb0;padding:4px 7px;text-align:right;vertical-align:top}}
tr:nth-child(even) td{{background:#faf6ec}} tr{{break-inside:avoid}} blockquote{{color:#666;margin:0}}""")
html = OUT / "plan.html"
subprocess.run(["pandoc", str(md), "-s", "-o", str(html), "--metadata", "title= ", "-c", str(css)], check=True, stderr=subprocess.DEVNULL)
html.write_text(html.read_text().replace("<html ", '<html dir="rtl" ', 1))
pdf, docx = OUT / "خطة-المسلسل-30-حلقة.pdf", OUT / "خطة-المسلسل-30-حلقة.docx"
subprocess.run(["node", str(Path(__file__).with_name("topdf.js")), str(html), str(pdf)], check=True, cwd="/tmp")
subprocess.run(["pandoc", str(md), "-o", str(docx), "-M", "dir=rtl", "-M", "lang=ar"], check=True)
print("✓", pdf, "\n✓", docx, "| missing goals:", miss)
